import React, { useEffect, useState } from "react";
import {
    SafeAreaView,
    View,
    Text,
    StyleSheet,
    TouchableOpacity,
    ScrollView,
    ActivityIndicator,
} from "react-native";
import { useNavigation } from "@react-navigation/native";
import { MaterialCommunityIcons } from "@expo/vector-icons";

import {
    getProfile,
    logoutCustomer,
    CustomerProfile,
} from "../../services/customerApi";

import DashboardSidebar from "../../components/Web/Dashboard/DashboardSidebar";
import DashboardQuickMenu from "../../components/Web/Dashboard/DashboardQuickMenu";
import ProfileHeader from "../../components/Web/Profile/ProfileHearder";
import ProfileForm from "../../components/Web/Profile/ProfileForm";

function getInitials(name?: string) {
    const cleanName = (name || "").trim();
    if (!cleanName) return "KH";
    const words = cleanName.split(/\s+/).filter(Boolean);
    if (words.length >= 2) return `${words[0][0]}${words[1][0]}`.toUpperCase();
    return cleanName.slice(0, 2).toUpperCase();
}

export default function ProfileScreen() {
    const navigation = useNavigation<any>();

    const [profile, setProfile]           = useState<CustomerProfile | null>(null);
    const [loading, setLoading]           = useState(true);
    const [showQuickMenu, setShowQuickMenu] = useState(false);

    useEffect(() => {
        loadProfile();
    }, []);

    const loadProfile = async () => {
        setLoading(true);
        try {
            const data = await getProfile();
            if (!data) {
                navigation.replace("Login");
                return;
            }
            setProfile(data);
        } catch {
            navigation.replace("Login");
        } finally {
            setLoading(false);
        }
    };

    const handleLogout = async () => {
        await logoutCustomer();
        navigation.replace("Home");
    };

    const initials = getInitials(profile?.full_name);

    return (
        <SafeAreaView style={styles.safeArea}>
            <View style={styles.container}>
                {/* Sidebar */}
                <DashboardSidebar
                    initials={initials}
                    activePage="overview"
                    onToggleQuickMenu={() => setShowQuickMenu((v) => !v)}
                    onPressOverview={() => navigation.navigate("Dashboard")}
                    onPressOrders={() => navigation.navigate("OrderList")}
                />

                {/* Quick Menu overlay */}
                {showQuickMenu && (
                    <DashboardQuickMenu
                        name={profile?.full_name || ""}
                        role={(profile as any)?.role || "customer"}
                        onPressProfile={() => setShowQuickMenu(false)}
                        onPressLogout={handleLogout}
                        onClose={() => setShowQuickMenu(false)}
                    />
                )}

                {/* Main content */}
                <View style={styles.main}>
                    <ProfileHeader isEditing={false} />

                    {loading ? (
                        <View style={styles.loadingBox}>
                            <ActivityIndicator size="large" color="#4E9858" />
                            <Text style={styles.loadingText}>Đang tải thông tin...</Text>
                        </View>
                    ) : profile ? (
                        <ScrollView
                            contentContainerStyle={styles.scrollContent}
                            showsVerticalScrollIndicator={false}
                        >
                            {/* Breadcrumb */}
                            <View style={styles.breadcrumb}>
                                <TouchableOpacity onPress={() => navigation.navigate("Dashboard")}>
                                    <Text style={styles.breadcrumbLink}>Tổng quan</Text>
                                </TouchableOpacity>
                                <MaterialCommunityIcons
                                    name="chevron-right"
                                    size={16}
                                    color="#AAAAAA"
                                />
                                <Text style={styles.breadcrumbCurrent}>Tài khoản</Text>
                            </View>

                            <Text style={styles.pageTitle}>Thông tin tài khoản</Text>
                            <Text style={styles.pageSubtitle}>
                                Xem và cập nhật thông tin cá nhân của bạn
                            </Text>

                            <ProfileForm
                                profile={profile}
                                onUpdated={(updated) => setProfile(updated)}
                            />
                        </ScrollView>
                    ) : null}
                </View>
            </View>
        </SafeAreaView>
    );
}

const styles = StyleSheet.create({
    safeArea: {
        flex: 1,
        backgroundColor: "#F5F5F5",
    },
    container: {
        flex: 1,
        flexDirection: "row",
    },
    main: {
        flex: 1,
        flexDirection: "column",
    },
    loadingBox: {
        flex: 1,
        justifyContent: "center",
        alignItems: "center",
        gap: 12,
    },
    loadingText: {
        color: "#888888",
        fontSize: 14,
    },
    scrollContent: {
        padding: 28,
        paddingBottom: 60,
    },
    breadcrumb: {
        flexDirection: "row",
        alignItems: "center",
        gap: 4,
        marginBottom: 16,
    },
    breadcrumbLink: {
        fontSize: 13,
        color: "#4E9858",
        fontWeight: "500",
    },
    breadcrumbCurrent: {
        fontSize: 13,
        color: "#AAAAAA",
    },
    pageTitle: {
        fontSize: 22,
        fontWeight: "700",
        color: "#111111",
        marginBottom: 4,
    },
    pageSubtitle: {
        fontSize: 14,
        color: "#888888",
        marginBottom: 24,
    },
});
