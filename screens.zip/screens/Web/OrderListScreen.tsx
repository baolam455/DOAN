import React, { useEffect, useState, useCallback } from "react";
import {
    SafeAreaView,
    View,
    Text,
    StyleSheet,
    TouchableOpacity,
    ScrollView,
    ActivityIndicator,
    Platform,
} from "react-native";
import { useNavigation } from "@react-navigation/native";
import { MaterialCommunityIcons } from "@expo/vector-icons";

import { getCurrentCustomer, logoutCustomer } from "../../services/customerApi";
import {
    getOrders,
    Order,
    OrderStatus,
    statusLabel,
    statusColor,
} from "../../services/orderApi";
import DashboardSidebar from "../../components/Web/Dashboard/DashboardSidebar";
import DashboardQuickMenu from "../../components/Web/Dashboard/DashboardQuickMenu";

const webNoOutline =
    Platform.OS === "web"
        ? ({ outlineStyle: "none", outlineWidth: 0, outlineColor: "transparent" } as any)
        : null;

type FilterTab = "all" | OrderStatus;

const TABS: { key: FilterTab; label: string }[] = [
    { key: "all", label: "Tất cả" },
    { key: "pending", label: "Chờ lấy hàng" },
    { key: "delivering", label: "Đang giao" },
    { key: "delivered", label: "Thành công" },
    { key: "returned", label: "Hoàn hàng" },
    { key: "cancelled", label: "Đã hủy" },
];

function getInitials(name?: string) {
    const cleanName = (name || "").trim();
    if (!cleanName) return "KH";
    const words = cleanName.split(/\s+/).filter(Boolean);
    if (words.length >= 2) return `${words[0][0]}${words[1][0]}`.toUpperCase();
    return cleanName.slice(0, 2).toUpperCase();
}

function formatDate(dateStr: string) {
    const d = new Date(dateStr);
    const day = String(d.getDate()).padStart(2, "0");
    const month = String(d.getMonth() + 1).padStart(2, "0");
    const year = d.getFullYear();
    const hours = String(d.getHours()).padStart(2, "0");
    const minutes = String(d.getMinutes()).padStart(2, "0");
    return `${day}/${month}/${year} ${hours}:${minutes}`;
}

function formatMoney(amount: number) {
    return amount.toLocaleString("vi-VN") + "đ";
}

function StatusBadge({ status }: { status: string }) {
    const color = statusColor(status);
    return (
        <View style={[styles.badge, { backgroundColor: color + "22", borderColor: color + "55" }]}>
            <Text style={[styles.badgeText, { color }]}>{statusLabel(status)}</Text>
        </View>
    );
}

function isDelivering(status: string) {
    return ["picked_up", "in_transit", "delivering"].includes(status);
}

export default function OrderListScreen() {
    const navigation = useNavigation<any>();

    const [quickMenuVisible, setQuickMenuVisible] = useState(false);
    const [customer, setCustomer] = useState<{ store_name?: string } | null>(null);
    const [orders, setOrders] = useState<Order[]>([]);
    const [loading, setLoading] = useState(true);
    const [activeTab, setActiveTab] = useState<FilterTab>("all");

    useEffect(() => {
        getCurrentCustomer()
            .then((p) => p && setCustomer(p))
            .catch(() => {});
    }, []);

    const loadOrders = useCallback(async () => {
        setLoading(true);
        try {
            const data = await getOrders();
            setOrders(data);
        } catch (e) {
            console.log("Lỗi tải đơn hàng:", e);
        } finally {
            setLoading(false);
        }
    }, []);

    useEffect(() => {
        loadOrders();
    }, [loadOrders]);

    const handleLogout = async () => {
        try {
            await logoutCustomer();
        } catch {}
        navigation.reset({ index: 0, routes: [{ name: "Login" }] });
    };

    const filteredOrders =
        activeTab === "all"
            ? orders
            : activeTab === "delivering"
            ? orders.filter((o) => isDelivering(o.status))
            : orders.filter((o) => o.status === activeTab);

    const customerInitials = getInitials(customer?.store_name);

    return (
        <SafeAreaView style={styles.safeArea}>
            <View style={styles.root}>
                {quickMenuVisible && (
                    <TouchableOpacity
                        activeOpacity={1}
                        style={styles.backdrop}
                        onPress={() => setQuickMenuVisible(false)}
                    />
                )}
                {quickMenuVisible && <DashboardQuickMenu onLogout={handleLogout} />}

                <DashboardSidebar
                    initials={customerInitials}
                    activePage="orders"
                    onToggleQuickMenu={() => setQuickMenuVisible((p) => !p)}
                    onPressOverview={() => navigation.navigate("Dashboard")}
                    onPressOrders={() => {}}
                    onPressReport={() => navigation.navigate("Feature", { title: "Báo cáo thống kê", description: "Chức năng đang phát triển." })}
                    onPressMoney={() => navigation.navigate("Feature", { title: "COD và đối soát", description: "Chức năng đang phát triển." })}
                    onPressChat={() => navigation.navigate("Feature", { title: "Hỗ trợ khách hàng", description: "Chức năng đang phát triển." })}
                    onPressWallet={() => navigation.navigate("Feature", { title: "Ví thanh toán", description: "Chức năng đang phát triển." })}
                    onPressHelp={() => navigation.navigate("Feature", { title: "Trung tâm hỗ trợ", description: "Chức năng đang phát triển." })}
                />

                <View style={styles.mainArea}>
                    {/* Header */}
                    <View style={styles.header}>
                        <Text style={styles.pageTitle}>Danh sách đơn hàng</Text>

                        <TouchableOpacity
                            activeOpacity={0.85}
                            style={[styles.createBtn, webNoOutline]}
                            onPress={() => navigation.navigate("CreateOrder")}
                        >
                            <MaterialCommunityIcons name="plus" size={20} color="#FFFFFF" />
                            <Text style={styles.createBtnText}>Tạo đơn hàng</Text>
                        </TouchableOpacity>
                    </View>

                    {/* Filter tabs */}
                    <View style={styles.tabBar}>
                        <ScrollView horizontal showsHorizontalScrollIndicator={false}>
                            {TABS.map((tab) => (
                                <TouchableOpacity
                                    key={tab.key}
                                    activeOpacity={0.8}
                                    style={[styles.tab, activeTab === tab.key && styles.tabActive, webNoOutline]}
                                    onPress={() => setActiveTab(tab.key)}
                                >
                                    <Text style={[styles.tabText, activeTab === tab.key && styles.tabTextActive]}>
                                        {tab.label}
                                    </Text>
                                </TouchableOpacity>
                            ))}
                        </ScrollView>

                        <TouchableOpacity
                            activeOpacity={0.8}
                            style={[styles.refreshBtn, webNoOutline]}
                            onPress={loadOrders}
                        >
                            <MaterialCommunityIcons name="refresh" size={20} color="#4D9858" />
                        </TouchableOpacity>
                    </View>

                    {/* Table */}
                    <ScrollView style={styles.scrollArea} showsVerticalScrollIndicator>
                        {/* Table header */}
                        <View style={styles.tableHeader}>
                            <Text style={[styles.colHeader, styles.colCode]}>Mã vận đơn</Text>
                            <Text style={[styles.colHeader, styles.colReceiver]}>Người nhận</Text>
                            <Text style={[styles.colHeader, styles.colProduct]}>Sản phẩm</Text>
                            <Text style={[styles.colHeader, styles.colCod]}>Thu hộ</Text>
                            <Text style={[styles.colHeader, styles.colStatus]}>Trạng thái</Text>
                            <Text style={[styles.colHeader, styles.colDate]}>Ngày tạo</Text>
                        </View>

                        {loading ? (
                            <View style={styles.centerBox}>
                                <ActivityIndicator size="large" color="#4D9858" />
                                <Text style={styles.centerText}>Đang tải...</Text>
                            </View>
                        ) : filteredOrders.length === 0 ? (
                            <View style={styles.centerBox}>
                                <MaterialCommunityIcons name="package-variant" size={56} color="#DDDDDD" />
                                <Text style={styles.emptyTitle}>Chưa có đơn hàng nào</Text>
                                <Text style={styles.emptyDesc}>
                                    {activeTab === "all"
                                        ? "Bấm \"Tạo đơn hàng\" để tạo đơn đầu tiên"
                                        : "Không có đơn nào trong trạng thái này"}
                                </Text>
                            </View>
                        ) : (
                            filteredOrders.map((order, index) => (
                                <TouchableOpacity
                                    key={order.id}
                                    activeOpacity={0.85}
                                    style={[styles.tableRow, index % 2 === 1 && styles.tableRowAlt, webNoOutline]}
                                    onPress={() => navigation.navigate("OrderDetail", { orderId: order.id })}
                                >
                                    <View style={styles.colCode}>
                                        <Text style={styles.orderCode}>{order.order_code}</Text>
                                        {order.shop_order_code ? (
                                            <Text style={styles.shopCode}>{order.shop_order_code}</Text>
                                        ) : null}
                                    </View>

                                    <View style={styles.colReceiver}>
                                        <Text style={styles.receiverName} numberOfLines={1}>
                                            {order.receiver_name}
                                        </Text>
                                        <Text style={styles.receiverPhone}>{order.receiver_phone}</Text>
                                        {order.receiver_province ? (
                                            <Text style={styles.receiverAddr} numberOfLines={1}>
                                                {order.receiver_province}
                                            </Text>
                                        ) : null}
                                    </View>

                                    <View style={styles.colProduct}>
                                        <Text style={styles.productName} numberOfLines={2}>
                                            {order.product_name || "—"}
                                        </Text>
                                        <Text style={styles.productDetail}>
                                            {order.total_weight} kg · {order.quantity} SP
                                        </Text>
                                    </View>

                                    <View style={styles.colCod}>
                                        <Text style={styles.codAmount}>{formatMoney(order.cod_amount)}</Text>
                                    </View>

                                    <View style={styles.colStatus}>
                                        <StatusBadge status={order.status} />
                                    </View>

                                    <View style={styles.colDate}>
                                        <Text style={styles.dateText}>{formatDate(order.created_at)}</Text>
                                    </View>
                                </TouchableOpacity>
                            ))
                        )}
                    </ScrollView>

                    {/* Footer count */}
                    {!loading && filteredOrders.length > 0 && (
                        <View style={styles.footer}>
                            <Text style={styles.footerText}>
                                Hiển thị {filteredOrders.length} / {orders.length} đơn hàng
                            </Text>
                        </View>
                    )}
                </View>
            </View>
        </SafeAreaView>
    );
}

const styles = StyleSheet.create({
    safeArea: { flex: 1, backgroundColor: "#F2F2F2" },

    root: { flex: 1, flexDirection: "row", backgroundColor: "#F2F2F2" },

    backdrop: {
        position: "absolute", top: 0, left: 0, right: 0, bottom: 0, zIndex: 20,
    },

    mainArea: { flex: 1, backgroundColor: "#F2F2F2" },

    header: {
        height: 72,
        backgroundColor: "#FFFFFF",
        borderBottomWidth: 1,
        borderBottomColor: "#E6E6E6",
        paddingLeft: 26,
        paddingRight: 28,
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "space-between",
    },

    pageTitle: { fontSize: 24, fontWeight: "700", color: "#111111" },

    createBtn: {
        height: 42,
        borderRadius: 6,
        backgroundColor: "#4D9858",
        paddingHorizontal: 18,
        flexDirection: "row",
        alignItems: "center",
    },

    createBtnText: { fontSize: 15, fontWeight: "600", color: "#FFFFFF", marginLeft: 8 },

    tabBar: {
        height: 52,
        backgroundColor: "#FFFFFF",
        borderBottomWidth: 1,
        borderBottomColor: "#EEEEEE",
        paddingHorizontal: 20,
        flexDirection: "row",
        alignItems: "center",
    },

    tab: {
        height: 52,
        paddingHorizontal: 16,
        alignItems: "center",
        justifyContent: "center",
        borderBottomWidth: 2,
        borderBottomColor: "transparent",
        marginRight: 4,
    },

    tabActive: { borderBottomColor: "#4D9858" },

    tabText: { fontSize: 14, fontWeight: "500", color: "#666666" },

    tabTextActive: { color: "#4D9858", fontWeight: "700" },

    refreshBtn: {
        width: 38,
        height: 38,
        borderRadius: 6,
        backgroundColor: "#EAF6EC",
        alignItems: "center",
        justifyContent: "center",
        marginLeft: 8,
    },

    scrollArea: { flex: 1 },

    tableHeader: {
        flexDirection: "row",
        alignItems: "center",
        height: 44,
        backgroundColor: "#F7F7F7",
        borderBottomWidth: 1,
        borderBottomColor: "#EEEEEE",
        paddingHorizontal: 20,
    },

    tableRow: {
        flexDirection: "row",
        alignItems: "center",
        minHeight: 70,
        backgroundColor: "#FFFFFF",
        borderBottomWidth: 1,
        borderBottomColor: "#F0F0F0",
        paddingHorizontal: 20,
        paddingVertical: 10,
    },

    tableRowAlt: { backgroundColor: "#FAFAFA" },

    colHeader: { fontSize: 13, fontWeight: "600", color: "#888888" },

    colCode: { width: 160, marginRight: 8 },
    colReceiver: { flex: 1, marginRight: 8 },
    colProduct: { width: 160, marginRight: 8 },
    colCod: { width: 110, marginRight: 8, alignItems: "flex-end" },
    colStatus: { width: 140, marginRight: 8 },
    colDate: { width: 130 },

    orderCode: { fontSize: 14, fontWeight: "700", color: "#4D9858" },
    shopCode: { fontSize: 12, color: "#999999", marginTop: 2 },

    receiverName: { fontSize: 14, fontWeight: "600", color: "#111111" },
    receiverPhone: { fontSize: 13, color: "#555555", marginTop: 2 },
    receiverAddr: { fontSize: 12, color: "#999999", marginTop: 2 },

    productName: { fontSize: 14, color: "#111111" },
    productDetail: { fontSize: 12, color: "#999999", marginTop: 2 },

    codAmount: { fontSize: 14, fontWeight: "700", color: "#111111" },

    dateText: { fontSize: 13, color: "#666666" },

    badge: {
        paddingHorizontal: 10,
        paddingVertical: 4,
        borderRadius: 12,
        borderWidth: 1,
        alignSelf: "flex-start",
    },

    badgeText: { fontSize: 12, fontWeight: "600" },

    centerBox: {
        alignItems: "center",
        justifyContent: "center",
        paddingVertical: 80,
    },

    centerText: { marginTop: 12, fontSize: 15, color: "#888888" },

    emptyTitle: { fontSize: 18, fontWeight: "700", color: "#333333", marginTop: 16 },

    emptyDesc: { fontSize: 14, color: "#999999", marginTop: 8, textAlign: "center" },

    footer: {
        height: 44,
        backgroundColor: "#FFFFFF",
        borderTopWidth: 1,
        borderTopColor: "#EEEEEE",
        alignItems: "center",
        justifyContent: "center",
    },

    footerText: { fontSize: 13, color: "#888888" },
});
