import React, { useEffect, useState, useCallback } from "react";
import {
    SafeAreaView,
    View,
    Text,
    StyleSheet,
    TouchableOpacity,
    ScrollView,
    ActivityIndicator,
    Platform,
} from "react-native";
import { useNavigation } from "@react-navigation/native";
import { MaterialCommunityIcons } from "@expo/vector-icons";

import { getCurrentCustomer, logoutCustomer } from "../../services/customerApi";
import {
    getDashboardStats,
    DashboardStats,
    getOrders,
    Order,
    statusLabel,
    statusColor,
} from "../../services/orderApi";
import { DateFilter } from "../../components/Web/Dashboard/DashboardFilterBar";

import DashboardSidebar from "../../components/Web/Dashboard/DashboardSidebar";
import DashboardQuickMenu from "../../components/Web/Dashboard/DashboardQuickMenu";
import DashboardFilterBar from "../../components/Web/Dashboard/DashboardFilterBar";
import DashboardMetricGrid from "../../components/Web/Dashboard/DashboardMetricGrid";
import DashboardReturnCard from "../../components/Web/Dashboard/DashboardReturnCard";
import DashboardTrendChart from "../../components/Web/Dashboard/DashboardTrendChart";
import DashboardRightCard from "../../components/Web/Dashboard/DashboardRightCard";

// Thứ tự ưu tiên sắp xếp theo trạng thái
const STATUS_ORDER: Record<string, number> = {
    delivering:  1,
    in_transit:  2,
    picked_up:   3,
    pending:     4,
    delivered:   5,
    returned:    6,
    cancelled:   7,
};

type CustomerProfile = {
    store_name?: string;
    email?: string;
    phone?: string;
};

const webNoOutline =
    Platform.OS === "web"
        ? ({ outlineStyle: "none", outlineWidth: 0, outlineColor: "transparent" } as any)
        : null;

function getInitials(name?: string) {
    const cleanName = (name || "").trim();
    if (!cleanName) return "KH";
    const words = cleanName.split(/\s+/).filter(Boolean);
    if (words.length >= 2) return `${words[0][0]}${words[1][0]}`.toUpperCase();
    return cleanName.slice(0, 2).toUpperCase();
}

function getDateRange(filter: DateFilter): { from?: string; to?: string } {
    const now = new Date();
    const todayStr = now.toISOString().split("T")[0];
    if (filter === "today")  return { from: `${todayStr}T00:00:00.000Z`, to: `${todayStr}T23:59:59.999Z` };
    if (filter === "7days")  return { from: new Date(now.getTime() - 7  * 86400000).toISOString() };
    if (filter === "30days") return { from: new Date(now.getTime() - 30 * 86400000).toISOString() };
    return {};
}

function formatDate(dateStr: string) {
    const d = new Date(dateStr);
    return `${String(d.getDate()).padStart(2,"0")}/${String(d.getMonth()+1).padStart(2,"0")}/${d.getFullYear()} ${String(d.getHours()).padStart(2,"0")}:${String(d.getMinutes()).padStart(2,"0")}`;
}

function formatMoney(amount: number) {
    return amount.toLocaleString("vi-VN") + "đ";
}

function StatusBadge({ status }: { status: string }) {
    const color = statusColor(status);
    return (
        <View style={[styles.badge, { backgroundColor: color + "22", borderColor: color + "55" }]}>
            <Text style={[styles.badgeText, { color }]}>{statusLabel(status)}</Text>
        </View>
    );
}

export default function DashboardScreen() {
    const navigation = useNavigation<any>();

    const [quickMenuVisible, setQuickMenuVisible] = useState(false);
    const [customer, setCustomer]   = useState<CustomerProfile | null>(null);
    const [stats, setStats]         = useState<DashboardStats | undefined>(undefined);
    const [dateFilter, setDateFilter] = useState<DateFilter>("all");
    const [orders, setOrders]       = useState<Order[]>([]);
    const [ordersLoading, setOrdersLoading] = useState(true);

    useEffect(() => {
        getCurrentCustomer()
            .then((profile) => { if (profile) setCustomer(profile); })
            .catch(() => {});
    }, []);

    const loadStats = useCallback(async (filter: DateFilter) => {
        try {
            const range = getDateRange(filter);
            const data = await getDashboardStats(range.from, range.to);
            setStats(data);
        } catch (e) {
            console.log("Lỗi tải thống kê:", e);
        }
    }, []);

    const loadOrders = useCallback(async () => {
        setOrdersLoading(true);
        try {
            const data = await getOrders();
            // Sắp xếp theo thứ tự trạng thái, sau đó theo ngày tạo mới nhất
            const sorted = [...data].sort((a, b) => {
                const sa = STATUS_ORDER[a.status] ?? 99;
                const sb = STATUS_ORDER[b.status] ?? 99;
                if (sa !== sb) return sa - sb;
                return new Date(b.created_at).getTime() - new Date(a.created_at).getTime();
            });
            setOrders(sorted);
        } catch (e) {
            console.log("Lỗi tải đơn hàng:", e);
        } finally {
            setOrdersLoading(false);
        }
    }, []);

    useEffect(() => { loadStats(dateFilter); }, [dateFilter, loadStats]);
    useEffect(() => { loadOrders(); }, [loadOrders]);

    const customerName     = customer?.store_name || "Khách hàng";
    const customerInitials = getInitials(customerName);

    const goFeature = (title: string, description: string) => {
        navigation.navigate("Feature", { title, description });
    };

    const handleLogout = async () => {
        try { await logoutCustomer(); } catch {}
        navigation.reset({ index: 0, routes: [{ name: "Login" }] });
    };

    return (
        <SafeAreaView style={styles.safeArea}>
            <View style={styles.root}>
                {quickMenuVisible && (
                    <TouchableOpacity
                        activeOpacity={1}
                        style={styles.menuBackdrop}
                        onPress={() => setQuickMenuVisible(false)}
                    />
                )}

                {quickMenuVisible && (
                    <DashboardQuickMenu
                        name={customerName}
                        role="customer"
                        onPressProfile={() => {
                            setQuickMenuVisible(false);
                            navigation.navigate("Profile");
                        }}
                        onPressLogout={handleLogout}
                        onClose={() => setQuickMenuVisible(false)}
                    />
                )}

                <DashboardSidebar
                    initials={customerInitials}
                    activePage="overview"
                    onToggleQuickMenu={() => setQuickMenuVisible((prev) => !prev)}
                    onPressOverview={() => navigation.navigate("Dashboard")}
                    onPressOrders={() => navigation.navigate("OrderList")}
                    onPressReport={() => goFeature("Báo cáo thống kê", "Màn này sẽ hiển thị hiệu suất giao hàng, doanh thu, số đơn hoàn thành và thời gian giao trung bình.")}
                    onPressMoney={() => goFeature("COD và đối soát", "Màn này sẽ quản lý tiền thu hộ, phí vận chuyển, doanh thu và lịch sử đối soát.")}
                    onPressChat={() => goFeature("Hỗ trợ khách hàng", "Màn này sẽ dùng cho chat, khiếu nại và hỗ trợ xử lý đơn hàng.")}
                    onPressWallet={() => goFeature("Ví thanh toán", "Màn này sẽ quản lý ví, thanh toán, nhận COD và liên kết ngân hàng.")}
                    onPressHelp={() => goFeature("Trung tâm hỗ trợ", "Màn này sẽ chứa hướng dẫn sử dụng, câu hỏi thường gặp và liên hệ hỗ trợ.")}
                />

                <View style={styles.mainArea}>
                    {/* Header */}
                    <View style={styles.header}>
                        <Text style={styles.pageTitle}>Tổng quan</Text>
                        <TouchableOpacity
                            activeOpacity={0.85}
                            style={[styles.createButton, webNoOutline]}
                            onPress={() => navigation.navigate("CreateOrder")}
                        >
                            <MaterialCommunityIcons name="plus" size={21} color="#FFFFFF" />
                            <Text style={styles.createButtonText}>Tạo đơn hàng</Text>
                        </TouchableOpacity>
                    </View>

                    <ScrollView
                        style={styles.scrollArea}
                        contentContainerStyle={styles.scrollContent}
                        showsVerticalScrollIndicator
                    >
                        <DashboardFilterBar
                            activeFilter={dateFilter}
                            onPressToday={() => setDateFilter("today")}
                            onPressSevenDays={() => setDateFilter("7days")}
                            onPressThirtyDays={() => setDateFilter("30days")}
                            onPressCustom={() => setDateFilter("all")}
                            onPressNotice={() => goFeature("Thông báo", "Màn này sẽ hiển thị thông báo liên quan đến đơn hàng và vận hành.")}
                        />

                        <View style={styles.contentRow}>
                            <View style={styles.leftColumn}>
                                <DashboardMetricGrid
                                    stats={stats}
                                    onPressGenerated={() => navigation.navigate("OrderList")}
                                    onPressSuccess={() => navigation.navigate("OrderList")}
                                    onPressDelivering={() => navigation.navigate("OrderList")}
                                    onPressShippingFee={() => goFeature("Phí vận chuyển", "Màn này sẽ thống kê phí giao hàng, phí hoàn và các chi phí vận chuyển.")}
                                />
                                <DashboardReturnCard
                                    onPressReason={(reason) => goFeature(reason, `Danh sách đơn hoàn theo lý do: ${reason}.`)}
                                />
                                <DashboardTrendChart
                                    onPress={() => goFeature("Xu hướng hàng - tiền", "Màn này sẽ hiển thị biểu đồ đơn hàng, sản phẩm, doanh thu và tỷ lệ hoàn theo thời gian.")}
                                />
                            </View>

                            <View style={styles.rightColumn}>
                                <DashboardRightCard
                                    title="Top sản phẩm"
                                    onPress={() => goFeature("Top sản phẩm", "Màn này sẽ hiển thị các sản phẩm bán chạy và sản phẩm có tỷ lệ hoàn cao.")}
                                />
                                <DashboardRightCard
                                    title="Top khu vực"
                                    onPress={() => goFeature("Top khu vực", "Màn này sẽ thống kê khu vực bán chạy, khu vực hoàn cao và hiệu suất giao hàng theo khu vực.")}
                                />
                            </View>
                        </View>

                        {/* ─── Danh sách đơn hàng gần đây ─── */}
                        <View style={styles.orderSection}>
                            {/* Section header */}
                            <View style={styles.orderSectionHeader}>
                                <View style={styles.orderSectionLeft}>
                                    <MaterialCommunityIcons name="package-variant-closed" size={20} color="#4D9858" />
                                    <Text style={styles.orderSectionTitle}>Đơn hàng của bạn</Text>
                                    {!ordersLoading && (
                                        <View style={styles.countBadge}>
                                            <Text style={styles.countBadgeText}>{orders.length}</Text>
                                        </View>
                                    )}
                                </View>
                                <View style={styles.orderSectionRight}>
                                    <TouchableOpacity
                                        activeOpacity={0.8}
                                        style={[styles.refreshBtn, webNoOutline]}
                                        onPress={loadOrders}
                                    >
                                        <MaterialCommunityIcons name="refresh" size={18} color="#4D9858" />
                                    </TouchableOpacity>
                                    <TouchableOpacity
                                        activeOpacity={0.8}
                                        style={[styles.viewAllBtn, webNoOutline]}
                                        onPress={() => navigation.navigate("OrderList")}
                                    >
                                        <Text style={styles.viewAllText}>Xem tất cả</Text>
                                        <MaterialCommunityIcons name="arrow-right" size={16} color="#4D9858" />
                                    </TouchableOpacity>
                                </View>
                            </View>

                            {/* Table header */}
                            <View style={styles.tableWrap}>
                                <View style={styles.tableHeader}>
                                    <Text style={[styles.colH, styles.colCode]}>Mã vận đơn</Text>
                                    <Text style={[styles.colH, styles.colReceiver]}>Người nhận</Text>
                                    <Text style={[styles.colH, styles.colProduct]}>Sản phẩm</Text>
                                    <Text style={[styles.colH, styles.colCod]}>Thu hộ (COD)</Text>
                                    <Text style={[styles.colH, styles.colStatus]}>Trạng thái</Text>
                                    <Text style={[styles.colH, styles.colDate]}>Ngày tạo</Text>
                                </View>

                                {/* Rows */}
                                {ordersLoading ? (
                                    <View style={styles.centerBox}>
                                        <ActivityIndicator size="large" color="#4D9858" />
                                        <Text style={styles.centerText}>Đang tải đơn hàng...</Text>
                                    </View>
                                ) : orders.length === 0 ? (
                                    <View style={styles.centerBox}>
                                        <MaterialCommunityIcons name="package-variant" size={48} color="#DDDDDD" />
                                        <Text style={styles.emptyTitle}>Chưa có đơn hàng nào</Text>
                                        <TouchableOpacity
                                            activeOpacity={0.85}
                                            style={[styles.createOrderBtn, webNoOutline]}
                                            onPress={() => navigation.navigate("CreateOrder")}
                                        >
                                            <MaterialCommunityIcons name="plus" size={16} color="#fff" />
                                            <Text style={styles.createOrderBtnText}>Tạo đơn hàng đầu tiên</Text>
                                        </TouchableOpacity>
                                    </View>
                                ) : (
                                    orders.slice(0, 10).map((order, index) => (
                                        <TouchableOpacity
                                            key={order.id}
                                            activeOpacity={0.85}
                                            style={[styles.tableRow, index % 2 === 1 && styles.tableRowAlt, webNoOutline]}
                                            onPress={() => navigation.navigate("OrderDetail", { orderId: order.id })}
                                        >
                                            <View style={styles.colCode}>
                                                <Text style={styles.orderCode}>{order.order_code}</Text>
                                                {order.shop_order_code ? (
                                                    <Text style={styles.shopCode}>{order.shop_order_code}</Text>
                                                ) : null}
                                            </View>
                                            <View style={styles.colReceiver}>
                                                <Text style={styles.receiverName} numberOfLines={1}>{order.receiver_name}</Text>
                                                <Text style={styles.receiverPhone}>{order.receiver_phone}</Text>
                                                {order.receiver_province ? (
                                                    <Text style={styles.receiverAddr} numberOfLines={1}>{order.receiver_province}</Text>
                                                ) : null}
                                            </View>
                                            <View style={styles.colProduct}>
                                                <Text style={styles.productName} numberOfLines={2}>{order.product_name || "—"}</Text>
                                                <Text style={styles.productDetail}>{order.total_weight} kg · {order.quantity} SP</Text>
                                            </View>
                                            <View style={styles.colCod}>
                                                <Text style={styles.codAmount}>{formatMoney(order.cod_amount)}</Text>
                                            </View>
                                            <View style={styles.colStatus}>
                                                <StatusBadge status={order.status} />
                                            </View>
                                            <View style={styles.colDate}>
                                                <Text style={styles.dateText}>{formatDate(order.created_at)}</Text>
                                            </View>
                                        </TouchableOpacity>
                                    ))
                                )}

                                {/* Footer */}
                                {!ordersLoading && orders.length > 10 && (
                                    <TouchableOpacity
                                        activeOpacity={0.8}
                                        style={[styles.tableFooter, webNoOutline]}
                                        onPress={() => navigation.navigate("OrderList")}
                                    >
                                        <Text style={styles.tableFooterText}>
                                            Đang hiển thị 10/{orders.length} đơn — Xem tất cả
                                        </Text>
                                        <MaterialCommunityIcons name="arrow-right" size={16} color="#4D9858" />
                                    </TouchableOpacity>
                                )}
                            </View>
                        </View>

                    </ScrollView>
                </View>
            </View>
        </SafeAreaView>
    );
}

const styles = StyleSheet.create({
    safeArea: { flex: 1, backgroundColor: "#F2F2F2" },
    root: { flex: 1, flexDirection: "row", backgroundColor: "#F2F2F2" },
    menuBackdrop: { position: "absolute", top: 0, left: 0, right: 0, bottom: 0, zIndex: 20 },
    mainArea: { flex: 1, backgroundColor: "#F2F2F2" },
    header: {
        height: 72,
        backgroundColor: "#FFFFFF",
        borderBottomWidth: 1,
        borderBottomColor: "#E6E6E6",
        paddingLeft: 26,
        paddingRight: 28,
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "space-between",
    },
    pageTitle: { fontSize: 24, fontWeight: "700", color: "#111111" },
    createButton: {
        height: 42,
        borderRadius: 6,
        backgroundColor: "#4D9858",
        paddingHorizontal: 18,
        flexDirection: "row",
        alignItems: "center",
    },
    createButtonText: { fontSize: 16, fontWeight: "600", color: "#FFFFFF", marginLeft: 8 },
    scrollArea: { flex: 1 },
    scrollContent: { paddingLeft: 24, paddingRight: 24, paddingTop: 24, paddingBottom: 40 },
    contentRow: { flexDirection: "row", alignItems: "flex-start" },
    leftColumn: { flex: 1, marginRight: 20 },
    rightColumn: { width: 455 },

    // ─── Order section ─────────────────────────────
    orderSection: {
        marginTop: 24,
    },
    orderSectionHeader: {
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "space-between",
        marginBottom: 12,
    },
    orderSectionLeft: {
        flexDirection: "row",
        alignItems: "center",
        gap: 8,
    },
    orderSectionTitle: {
        fontSize: 17,
        fontWeight: "700",
        color: "#111111",
    },
    countBadge: {
        backgroundColor: "#E8F6EA",
        borderRadius: 10,
        paddingHorizontal: 8,
        paddingVertical: 2,
    },
    countBadgeText: {
        fontSize: 12,
        fontWeight: "700",
        color: "#4D9858",
    },
    orderSectionRight: {
        flexDirection: "row",
        alignItems: "center",
        gap: 8,
    },
    refreshBtn: {
        width: 34,
        height: 34,
        borderRadius: 6,
        backgroundColor: "#EAF6EC",
        alignItems: "center",
        justifyContent: "center",
    },
    viewAllBtn: {
        flexDirection: "row",
        alignItems: "center",
        gap: 4,
        paddingHorizontal: 12,
        paddingVertical: 7,
        borderRadius: 6,
        borderWidth: 1,
        borderColor: "#4D9858",
    },
    viewAllText: { fontSize: 13, fontWeight: "600", color: "#4D9858" },

    // ─── Table ────────────────────────────────────
    tableWrap: {
        backgroundColor: "#FFFFFF",
        borderRadius: 12,
        overflow: "hidden",
        borderWidth: 1,
        borderColor: "#EEEEEE",
    },
    tableHeader: {
        flexDirection: "row",
        alignItems: "center",
        height: 44,
        backgroundColor: "#F7F7F7",
        borderBottomWidth: 1,
        borderBottomColor: "#EEEEEE",
        paddingHorizontal: 20,
    },
    colH: { fontSize: 12, fontWeight: "600", color: "#888888", textTransform: "uppercase" },
    tableRow: {
        flexDirection: "row",
        alignItems: "center",
        minHeight: 68,
        backgroundColor: "#FFFFFF",
        borderBottomWidth: 1,
        borderBottomColor: "#F5F5F5",
        paddingHorizontal: 20,
        paddingVertical: 10,
    },
    tableRowAlt: { backgroundColor: "#FAFAFA" },

    colCode:     { width: 150, marginRight: 8 },
    colReceiver: { flex: 1,    marginRight: 8 },
    colProduct:  { width: 150, marginRight: 8 },
    colCod:      { width: 110, marginRight: 8, alignItems: "flex-end" },
    colStatus:   { width: 145, marginRight: 8 },
    colDate:     { width: 125 },

    orderCode:    { fontSize: 13, fontWeight: "700", color: "#4D9858" },
    shopCode:     { fontSize: 11, color: "#AAAAAA", marginTop: 2 },
    receiverName: { fontSize: 14, fontWeight: "600", color: "#111111" },
    receiverPhone:{ fontSize: 12, color: "#555555", marginTop: 2 },
    receiverAddr: { fontSize: 11, color: "#AAAAAA", marginTop: 2 },
    productName:  { fontSize: 13, color: "#111111" },
    productDetail:{ fontSize: 11, color: "#AAAAAA", marginTop: 2 },
    codAmount:    { fontSize: 14, fontWeight: "700", color: "#111111" },
    dateText:     { fontSize: 12, color: "#777777" },

    badge: {
        paddingHorizontal: 9,
        paddingVertical: 4,
        borderRadius: 12,
        borderWidth: 1,
        alignSelf: "flex-start",
    },
    badgeText: { fontSize: 11, fontWeight: "600" },

    centerBox: {
        alignItems: "center",
        justifyContent: "center",
        paddingVertical: 52,
        gap: 12,
    },
    centerText: { fontSize: 14, color: "#888888" },
    emptyTitle: { fontSize: 16, fontWeight: "600", color: "#555555" },

    createOrderBtn: {
        flexDirection: "row",
        alignItems: "center",
        gap: 6,
        backgroundColor: "#4D9858",
        borderRadius: 8,
        paddingHorizontal: 16,
        paddingVertical: 10,
        marginTop: 4,
    },
    createOrderBtnText: { fontSize: 14, fontWeight: "600", color: "#fff" },

    tableFooter: {
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "center",
        gap: 6,
        paddingVertical: 14,
        borderTopWidth: 1,
        borderTopColor: "#F0F0F0",
    },
    tableFooterText: { fontSize: 13, color: "#4D9858", fontWeight: "600" },
});
