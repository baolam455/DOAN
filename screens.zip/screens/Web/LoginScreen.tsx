import React, { useEffect, useMemo, useRef, useState } from "react";
import { Animated, SafeAreaView, View, StyleSheet, Alert } from "react-native";
import { useNavigation } from "@react-navigation/native";
import { loginCustomer, getErrorMessage } from "../../services/customerApi";

import LoginPageHeader from "../../components/Web/Login/LoginPageHeader";
import SlideLeft from "../../components/Web/Login/SlideLeft";
import LoginHeaderBlock from "../../components/Web/Login/LoginHeaderBlock";
import LoginForm from "../../components/Web/Login/LoginForm";

export default function LoginScreen() {
  const navigation = useNavigation<any>();

  const slides = useMemo(
    () => [
      {
        image: {
          uri: "https://images.unsplash.com/photo-1586528116311-ad8dd3c8310d?auto=format&fit=crop&w=1600&q=80",
        },
        top: "Nền tảng giao hàng - vận hành - đối soát",
        title:
          "Giải pháp giao nhận hàng toàn diện cho shop online và doanh nghiệp",
        desc: "Kết nối lấy hàng, giao hàng, quản lý đơn, theo dõi hành trình và nâng hiệu suất xử lý ở mọi giai đoạn vận hành",
      },
      {
        image: {
          uri: "https://images.unsplash.com/photo-1553413077-190dd305871c?auto=format&fit=crop&w=1600&q=80",
        },
        top: "Nền tảng giao hàng - vận hành - đối soát",
        title: "Quy trình giao nhận hàng chuyên nghiệp",
        desc: "Đảm bảo đơn hàng được xử lý và giao đúng thời gian",
      },
      {
        image: {
          uri: "https://images.unsplash.com/photo-1587293852726-70cdb56c2866?auto=format&fit=crop&w=1600&q=80",
        },
        top: "Nền tảng giao hàng - vận hành - đối soát",
        title: "Đòn bẩy tăng trưởng dành riêng cho doanh nghiệp",
        desc: "Quản lý hàng hóa, phân loại và xử lý đơn hàng nhanh chóng",
      },
    ],
    [],
  );

  const [slideIndex, setSlideIndex] = useState(0);
  const fadeAnim = useRef(new Animated.Value(1)).current;

  const [account, setAccount] = useState("");
  const [password, setPassword] = useState("");

  const [loading, setLoading] = useState(false);

  const [errors, setErrors] = useState({
    account: "",
    password: "",
  });

  useEffect(() => {
    const timer = setInterval(() => {
      Animated.timing(fadeAnim, {
        toValue: 0,
        duration: 350,
        useNativeDriver: true,
      }).start(() => {
        setSlideIndex((prev) => (prev + 1) % slides.length);

        Animated.timing(fadeAnim, {
          toValue: 1,
          duration: 350,
          useNativeDriver: true,
        }).start();
      });
    }, 2800);

    return () => clearInterval(timer);
  }, [fadeAnim, slides.length]);

  const current = slides[slideIndex];

  const validateLoginForm = () => {
    const accountValue = account.trim();
    const phoneDigits = accountValue.replace(/\D/g, "");

    const nextErrors = {
      account: "",
      password: "",
    };

    if (!accountValue) {
      nextErrors.account = "Vui lòng nhập số điện thoại hoặc email";
    } else if (accountValue.includes("@")) {
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(accountValue)) {
        nextErrors.account = "Email không hợp lệ";
      }
    } else if (!/^\d{10}$/.test(phoneDigits)) {
      nextErrors.account = "Số điện thoại phải đủ 10 số hoặc nhập email hợp lệ";
    }

    if (!password) {
      nextErrors.password = "Vui lòng nhập mật khẩu";
    }

    setErrors(nextErrors);

    return !Object.values(nextErrors).some(Boolean);
  };

  const handleLogin = async () => {
    const isValid = validateLoginForm();

    if (!isValid) {
      return;
    }

    try {
      setLoading(true);

      const accountValue = account.trim();
      const loginAccount = accountValue.includes("@")
        ? accountValue.toLowerCase()
        : accountValue.replace(/\D/g, "");

      await loginCustomer({
        account: loginAccount,
        password,
      });

      navigation.reset({
        index: 0,
        routes: [{ name: "Dashboard" }],
      });
    } catch (error) {
      Alert.alert("Đăng nhập thất bại", getErrorMessage(error));
    } finally {
      setLoading(false);
    }
  };

  return (
    <SafeAreaView style={styles.safeArea}>
      <View style={styles.container}>
        <LoginPageHeader onHomePress={() => navigation.navigate("Home")} />

        <View style={styles.body}>
          <SlideLeft slide={current} fadeAnim={fadeAnim} />

          <View style={styles.rightSection}>
            <View style={styles.contentWrap}>
              <LoginHeaderBlock
                onRegisterPress={() => navigation.navigate("Register")}
              />

              <LoginForm
                account={account}
                password={password}
                errors={errors}
                loading={loading}
                onChangeAccount={setAccount}
                onChangePassword={setPassword}
                onLoginPress={handleLogin}
              />
            </View>
          </View>
        </View>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: "#F5F5F5",
  },

  container: {
    flex: 1,
    backgroundColor: "#FFFFFF",
  },

  body: {
    flex: 1,
    flexDirection: "row",
    backgroundColor: "#FFFFFF",
  },

  rightSection: {
    flex: 1,
    backgroundColor: "#FFFFFF",
    justifyContent: "center",
  },

  contentWrap: {
    marginLeft: 56,
    transform: [{ translateX: 0 }, { translateY: 0 }],
  },
});
