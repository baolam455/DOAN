import React, { useEffect, useState } from "react";
import {
    SafeAreaView,
    View,
    Text,
    StyleSheet,
    TouchableOpacity,
    ScrollView,
    ActivityIndicator,
    Alert,
    Platform,
} from "react-native";
import { useNavigation, useRoute } from "@react-navigation/native";
import { MaterialCommunityIcons } from "@expo/vector-icons";

import { getCurrentCustomer, logoutCustomer } from "../../services/customerApi";
import {
    getOrderById,
    getOrderTracking,
    cancelOrder,
    Order,
    OrderTracking,
    statusLabel,
    statusColor,
    statusIcon,
} from "../../services/orderApi";
import DashboardSidebar from "../../components/Web/Dashboard/DashboardSidebar";
import DashboardQuickMenu from "../../components/Web/Dashboard/DashboardQuickMenu";

const webNoOutline =
    Platform.OS === "web"
        ? ({ outlineStyle: "none", outlineWidth: 0, outlineColor: "transparent" } as any)
        : null;

function getInitials(name?: string) {
    const cleanName = (name || "").trim();
    if (!cleanName) return "KH";
    const words = cleanName.split(/\s+/).filter(Boolean);
    if (words.length >= 2) return `${words[0][0]}${words[1][0]}`.toUpperCase();
    return cleanName.slice(0, 2).toUpperCase();
}

function formatDate(dateStr: string) {
    const d = new Date(dateStr);
    return `${String(d.getDate()).padStart(2, "0")}/${String(d.getMonth() + 1).padStart(2, "0")}/${d.getFullYear()} ${String(d.getHours()).padStart(2, "0")}:${String(d.getMinutes()).padStart(2, "0")}`;
}

function formatMoney(amount: number) {
    return amount.toLocaleString("vi-VN") + "đ";
}

function InfoRow({ label, value, accent }: { label: string; value: string; accent?: boolean }) {
    return (
        <View style={styles.infoRow}>
            <Text style={styles.infoLabel}>{label}</Text>
            <Text style={[styles.infoValue, accent && styles.infoValueAccent]}>{value}</Text>
        </View>
    );
}

function TrackingEvent({ event, isLast }: { event: OrderTracking; isLast: boolean }) {
    const color = statusColor(event.status);
    return (
        <View style={styles.trackingEvent}>
            <View style={styles.trackingLeft}>
                <View style={[styles.trackingDot, { backgroundColor: color }]}>
                    <MaterialCommunityIcons
                        name={statusIcon(event.status) as any}
                        size={14}
                        color="#FFFFFF"
                    />
                </View>
                {!isLast && <View style={styles.trackingLine} />}
            </View>

            <View style={styles.trackingContent}>
                <Text style={[styles.trackingStatus, { color }]}>{statusLabel(event.status)}</Text>
                {event.note ? <Text style={styles.trackingNote}>{event.note}</Text> : null}
                {event.location ? (
                    <View style={styles.trackingLocRow}>
                        <MaterialCommunityIcons name="map-marker-outline" size={13} color="#999999" />
                        <Text style={styles.trackingLoc}>{event.location}</Text>
                    </View>
                ) : null}
                <Text style={styles.trackingDate}>{formatDate(event.created_at)}</Text>
            </View>
        </View>
    );
}

export default function OrderDetailScreen() {
    const navigation = useNavigation<any>();
    const route = useRoute<any>();
    const orderId = route.params?.orderId as string;

    const [quickMenuVisible, setQuickMenuVisible] = useState(false);
    const [customer, setCustomer] = useState<{ store_name?: string } | null>(null);
    const [order, setOrder] = useState<Order | null>(null);
    const [tracking, setTracking] = useState<OrderTracking[]>([]);
    const [loading, setLoading] = useState(true);
    const [cancelling, setCancelling] = useState(false);

    useEffect(() => {
        getCurrentCustomer()
            .then((p) => p && setCustomer(p))
            .catch(() => {});
    }, []);

    useEffect(() => {
        if (!orderId) return;

        const loadData = async () => {
            setLoading(true);
            try {
                const [ord, trk] = await Promise.all([
                    getOrderById(orderId),
                    getOrderTracking(orderId),
                ]);
                setOrder(ord);
                setTracking(trk);
            } catch (e) {
                console.log("Lỗi tải chi tiết đơn:", e);
            } finally {
                setLoading(false);
            }
        };

        loadData();
    }, [orderId]);

    const handleLogout = async () => {
        try {
            await logoutCustomer();
        } catch {}
        navigation.reset({ index: 0, routes: [{ name: "Login" }] });
    };

    const handleCancel = () => {
        if (Platform.OS === "web") {
            const confirmed = (globalThis as any).confirm(
                "Bạn có chắc muốn hủy đơn hàng này không?"
            );
            if (!confirmed) return;
            doCancel();
        } else {
            Alert.alert("Xác nhận hủy", "Bạn có chắc muốn hủy đơn hàng này?", [
                { text: "Không", style: "cancel" },
                { text: "Hủy đơn", style: "destructive", onPress: doCancel },
            ]);
        }
    };

    const doCancel = async () => {
        if (!orderId) return;
        setCancelling(true);
        try {
            await cancelOrder(orderId);
            const [ord, trk] = await Promise.all([
                getOrderById(orderId),
                getOrderTracking(orderId),
            ]);
            setOrder(ord);
            setTracking(trk);
        } catch (e: any) {
            if (Platform.OS === "web") {
                (globalThis as any).alert("Hủy đơn thất bại: " + e?.message);
            } else {
                Alert.alert("Lỗi", e?.message || "Không thể hủy đơn hàng");
            }
        } finally {
            setCancelling(false);
        }
    };

    const customerInitials = getInitials(customer?.store_name);
    const canCancel = order?.status === "pending";

    const shippingTypeLabel = order?.shipping_type === "express" ? "EXPRESS (< 20kg)" : "BBS (≥ 20kg)";
    const transportTypeLabel = order?.transport_type === "road" ? "Đường bộ" : "Đường bay";
    const pickupMethodLabel = order?.pickup_method === "home" ? "Lấy hàng tận nơi" : "Gửi hàng bưu cục";
    const shipPayerLabel = order?.ship_payer === "customer" ? "Khách trả ship" : "Shop trả ship";

    return (
        <SafeAreaView style={styles.safeArea}>
            <View style={styles.root}>
                {quickMenuVisible && (
                    <TouchableOpacity
                        activeOpacity={1}
                        style={styles.backdrop}
                        onPress={() => setQuickMenuVisible(false)}
                    />
                )}
                {quickMenuVisible && <DashboardQuickMenu onLogout={handleLogout} />}

                <DashboardSidebar
                    initials={customerInitials}
                    activePage="orders"
                    onToggleQuickMenu={() => setQuickMenuVisible((p) => !p)}
                    onPressOverview={() => navigation.navigate("Dashboard")}
                    onPressOrders={() => navigation.navigate("OrderList")}
                    onPressReport={() => navigation.navigate("Feature", { title: "Báo cáo thống kê", description: "Chức năng đang phát triển." })}
                    onPressMoney={() => navigation.navigate("Feature", { title: "COD và đối soát", description: "Chức năng đang phát triển." })}
                    onPressChat={() => navigation.navigate("Feature", { title: "Hỗ trợ khách hàng", description: "Chức năng đang phát triển." })}
                    onPressWallet={() => navigation.navigate("Feature", { title: "Ví thanh toán", description: "Chức năng đang phát triển." })}
                    onPressHelp={() => navigation.navigate("Feature", { title: "Trung tâm hỗ trợ", description: "Chức năng đang phát triển." })}
                />

                <View style={styles.mainArea}>
                    {/* Header */}
                    <View style={styles.header}>
                        <View style={styles.headerLeft}>
                            <TouchableOpacity
                                activeOpacity={0.8}
                                style={[styles.backBtn, webNoOutline]}
                                onPress={() => navigation.navigate("OrderList")}
                            >
                                <MaterialCommunityIcons name="chevron-left" size={26} color="#111111" />
                            </TouchableOpacity>

                            <Text style={styles.pageTitle}>Chi tiết đơn hàng</Text>

                            {order && (
                                <Text style={styles.orderCodeHeader}>{order.order_code}</Text>
                            )}
                        </View>

                        {order && (
                            <View style={[styles.statusBadge, { backgroundColor: statusColor(order.status) + "22", borderColor: statusColor(order.status) + "55" }]}>
                                <Text style={[styles.statusBadgeText, { color: statusColor(order.status) }]}>
                                    {statusLabel(order.status)}
                                </Text>
                            </View>
                        )}
                    </View>

                    {loading ? (
                        <View style={styles.centerBox}>
                            <ActivityIndicator size="large" color="#4D9858" />
                            <Text style={styles.centerText}>Đang tải...</Text>
                        </View>
                    ) : !order ? (
                        <View style={styles.centerBox}>
                            <MaterialCommunityIcons name="alert-circle-outline" size={54} color="#DDDDDD" />
                            <Text style={styles.emptyTitle}>Không tìm thấy đơn hàng</Text>
                        </View>
                    ) : (
                        <ScrollView style={styles.scrollArea} contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator>
                            <View style={styles.contentRow}>
                                {/* Left: Order Info */}
                                <View style={styles.leftCol}>
                                    {/* Receiver info */}
                                    <View style={styles.card}>
                                        <Text style={styles.cardTitle}>Thông tin người nhận</Text>
                                        <InfoRow label="Tên" value={order.receiver_name} />
                                        <InfoRow label="Số điện thoại" value={order.receiver_phone} />
                                        <InfoRow label="Địa chỉ" value={order.receiver_address} />
                                        {order.receiver_ward && (
                                            <InfoRow label="Phường/Xã" value={order.receiver_ward} />
                                        )}
                                        {order.receiver_province && (
                                            <InfoRow label="Tỉnh/TP" value={order.receiver_province} />
                                        )}
                                    </View>

                                    {/* Product info */}
                                    <View style={styles.card}>
                                        <Text style={styles.cardTitle}>Thông tin sản phẩm</Text>
                                        <InfoRow label="Tên sản phẩm" value={order.product_name || "—"} />
                                        <InfoRow label="Số lượng" value={`${order.quantity} sản phẩm`} />
                                        <InfoRow label="Khối lượng" value={`${order.total_weight} kg`} />
                                    </View>

                                    {/* Shipping info */}
                                    <View style={styles.card}>
                                        <Text style={styles.cardTitle}>Dịch vụ vận chuyển</Text>
                                        <InfoRow label="Loại dịch vụ" value={shippingTypeLabel} />
                                        <InfoRow label="Phương tiện" value={transportTypeLabel} />
                                        <InfoRow label="Hình thức lấy" value={pickupMethodLabel} />
                                        <InfoRow label="Người trả ship" value={shipPayerLabel} />
                                    </View>

                                    {/* Pricing */}
                                    <View style={styles.card}>
                                        <Text style={styles.cardTitle}>Thanh toán</Text>
                                        <InfoRow label="Tiền thu hộ (COD)" value={formatMoney(order.cod_amount)} accent />
                                        <InfoRow label="Giá trị hàng" value={formatMoney(order.product_value)} />
                                        <InfoRow label="Phí vận chuyển" value={formatMoney(order.shipping_fee)} />
                                        <View style={[styles.infoRow, styles.totalRow]}>
                                            <Text style={styles.totalLabel}>Tổng thu</Text>
                                            <Text style={styles.totalValue}>
                                                {formatMoney(order.cod_amount + order.shipping_fee)}
                                            </Text>
                                        </View>
                                    </View>

                                    {/* Dates */}
                                    <View style={styles.card}>
                                        <Text style={styles.cardTitle}>Thời gian</Text>
                                        <InfoRow label="Ngày tạo" value={formatDate(order.created_at)} />
                                        {order.pickup_at && (
                                            <InfoRow label="Đã lấy hàng" value={formatDate(order.pickup_at)} />
                                        )}
                                        {order.delivered_at && (
                                            <InfoRow label="Giao thành công" value={formatDate(order.delivered_at)} />
                                        )}
                                    </View>

                                    {order.shop_order_code && (
                                        <View style={styles.card}>
                                            <Text style={styles.cardTitle}>Mã đơn riêng của shop</Text>
                                            <Text style={styles.shopCode}>{order.shop_order_code}</Text>
                                        </View>
                                    )}

                                    {/* Cancel button */}
                                    {canCancel && (
                                        <TouchableOpacity
                                            activeOpacity={0.85}
                                            style={[styles.cancelBtn, cancelling && styles.cancelBtnDisabled, webNoOutline]}
                                            onPress={handleCancel}
                                            disabled={cancelling}
                                        >
                                            {cancelling ? (
                                                <ActivityIndicator size="small" color="#EF4444" />
                                            ) : (
                                                <MaterialCommunityIcons name="close-circle-outline" size={18} color="#EF4444" />
                                            )}
                                            <Text style={styles.cancelBtnText}>
                                                {cancelling ? "Đang hủy..." : "Hủy đơn hàng"}
                                            </Text>
                                        </TouchableOpacity>
                                    )}
                                </View>

                                {/* Right: Tracking */}
                                <View style={styles.rightCol}>
                                    <View style={styles.card}>
                                        <Text style={styles.cardTitle}>Lịch sử vận chuyển</Text>

                                        {tracking.length === 0 ? (
                                            <Text style={styles.noTracking}>Chưa có lịch sử vận chuyển</Text>
                                        ) : (
                                            <View style={styles.trackingList}>
                                                {[...tracking].reverse().map((event, index) => (
                                                    <TrackingEvent
                                                        key={event.id}
                                                        event={event}
                                                        isLast={index === tracking.length - 1}
                                                    />
                                                ))}
                                            </View>
                                        )}
                                    </View>
                                </View>
                            </View>
                        </ScrollView>
                    )}
                </View>
            </View>
        </SafeAreaView>
    );
}

const styles = StyleSheet.create({
    safeArea: { flex: 1, backgroundColor: "#F2F2F2" },

    root: { flex: 1, flexDirection: "row", backgroundColor: "#F2F2F2" },

    backdrop: {
        position: "absolute", top: 0, left: 0, right: 0, bottom: 0, zIndex: 20,
    },

    mainArea: { flex: 1, backgroundColor: "#F2F2F2" },

    header: {
        height: 72,
        backgroundColor: "#FFFFFF",
        borderBottomWidth: 1,
        borderBottomColor: "#E6E6E6",
        paddingLeft: 16,
        paddingRight: 28,
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "space-between",
    },

    headerLeft: { flexDirection: "row", alignItems: "center" },

    backBtn: {
        width: 40,
        height: 40,
        borderRadius: 20,
        alignItems: "center",
        justifyContent: "center",
        marginRight: 8,
    },

    pageTitle: { fontSize: 22, fontWeight: "700", color: "#111111", marginRight: 12 },

    orderCodeHeader: {
        fontSize: 15,
        fontWeight: "600",
        color: "#4D9858",
        backgroundColor: "#EAF6EC",
        paddingHorizontal: 10,
        paddingVertical: 4,
        borderRadius: 6,
    },

    statusBadge: {
        paddingHorizontal: 14,
        paddingVertical: 6,
        borderRadius: 14,
        borderWidth: 1,
    },

    statusBadgeText: { fontSize: 14, fontWeight: "700" },

    scrollArea: { flex: 1 },

    scrollContent: {
        paddingHorizontal: 24,
        paddingTop: 24,
        paddingBottom: 40,
    },

    contentRow: { flexDirection: "row", alignItems: "flex-start" },

    leftCol: { flex: 1, marginRight: 20 },

    rightCol: { width: 380 },

    card: {
        backgroundColor: "#FFFFFF",
        borderRadius: 8,
        padding: 20,
        marginBottom: 16,
    },

    cardTitle: {
        fontSize: 16,
        fontWeight: "700",
        color: "#111111",
        marginBottom: 16,
        paddingBottom: 12,
        borderBottomWidth: 1,
        borderBottomColor: "#F0F0F0",
    },

    infoRow: {
        flexDirection: "row",
        alignItems: "flex-start",
        justifyContent: "space-between",
        paddingVertical: 8,
        borderBottomWidth: 1,
        borderBottomColor: "#F8F8F8",
    },

    infoLabel: { fontSize: 14, color: "#666666", flex: 1 },

    infoValue: { fontSize: 14, color: "#111111", fontWeight: "500", flex: 2, textAlign: "right" },

    infoValueAccent: { color: "#E53935", fontWeight: "700" },

    totalRow: {
        borderBottomWidth: 0,
        paddingTop: 12,
        marginTop: 4,
    },

    totalLabel: { fontSize: 15, fontWeight: "700", color: "#111111", flex: 1 },

    totalValue: { fontSize: 16, fontWeight: "800", color: "#111111" },

    shopCode: { fontSize: 15, fontWeight: "600", color: "#4D9858" },

    cancelBtn: {
        height: 46,
        borderRadius: 8,
        borderWidth: 1,
        borderColor: "#EF4444",
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "center",
        backgroundColor: "#FFF5F5",
        marginBottom: 16,
    },

    cancelBtnDisabled: { opacity: 0.6 },

    cancelBtnText: {
        fontSize: 15,
        fontWeight: "600",
        color: "#EF4444",
        marginLeft: 8,
    },

    trackingList: { paddingTop: 8 },

    trackingEvent: {
        flexDirection: "row",
        marginBottom: 20,
    },

    trackingLeft: {
        width: 32,
        alignItems: "center",
    },

    trackingDot: {
        width: 28,
        height: 28,
        borderRadius: 14,
        alignItems: "center",
        justifyContent: "center",
    },

    trackingLine: {
        width: 2,
        flex: 1,
        backgroundColor: "#E5E7EB",
        marginTop: 4,
        minHeight: 24,
    },

    trackingContent: { flex: 1, marginLeft: 12, paddingBottom: 4 },

    trackingStatus: { fontSize: 14, fontWeight: "700", marginBottom: 4 },

    trackingNote: { fontSize: 13, color: "#444444", marginBottom: 4 },

    trackingLocRow: { flexDirection: "row", alignItems: "center", marginBottom: 4 },

    trackingLoc: { fontSize: 12, color: "#999999", marginLeft: 4 },

    trackingDate: { fontSize: 12, color: "#AAAAAA" },

    noTracking: { fontSize: 14, color: "#999999", textAlign: "center", paddingVertical: 20 },

    centerBox: {
        flex: 1,
        alignItems: "center",
        justifyContent: "center",
        paddingVertical: 80,
    },

    centerText: { marginTop: 12, fontSize: 15, color: "#888888" },

    emptyTitle: { fontSize: 18, fontWeight: "700", color: "#333333", marginTop: 16 },
});
