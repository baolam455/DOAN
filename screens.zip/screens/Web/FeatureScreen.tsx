import React from "react";
import { SafeAreaView, View, Text, TouchableOpacity, StyleSheet } from "react-native";
import { useNavigation, useRoute } from "@react-navigation/native";
import { MaterialCommunityIcons } from "@expo/vector-icons";

type RouteParams = {
    title?: string;
    description?: string;
};

export default function FeatureScreen() {
    const navigation = useNavigation<any>();
    const route = useRoute<any>();

    const params = (route.params || {}) as RouteParams;

    const title = params.title || "Chức năng";
    const description =
        params.description ||
        "Màn hình này đang được xây dựng. Sau này sẽ nối API và dữ liệu thật.";

    return (
        <SafeAreaView style={styles.safeArea}>
            <View style={styles.header}>
                <TouchableOpacity
                    activeOpacity={0.8}
                    style={styles.backButton}
                    onPress={() => navigation.goBack()}
                >
                    <MaterialCommunityIcons name="chevron-left" size={28} color="#111111" />
                </TouchableOpacity>

                <Text style={styles.headerTitle}>{title}</Text>
            </View>

            <View style={styles.content}>
                <View style={styles.card}>
                    <MaterialCommunityIcons name="tools" size={54} color="#4D9858" />
                    <Text style={styles.title}>{title}</Text>
                    <Text style={styles.desc}>{description}</Text>

                    <TouchableOpacity
                        activeOpacity={0.85}
                        style={styles.button}
                        onPress={() => navigation.navigate("Dashboard")}
                    >
                        <Text style={styles.buttonText}>Quay về tổng quan</Text>
                    </TouchableOpacity>
                </View>
            </View>
        </SafeAreaView>
    );
}

const styles = StyleSheet.create({
    safeArea: {
        flex: 1,
        backgroundColor: "#F2F2F2",
    },

    header: {
        height: 72,
        backgroundColor: "#FFFFFF",
        borderBottomWidth: 1,
        borderBottomColor: "#E6E6E6",
        flexDirection: "row",
        alignItems: "center",
        paddingHorizontal: 24,
    },

    backButton: {
        width: 42,
        height: 42,
        borderRadius: 21,
        alignItems: "center",
        justifyContent: "center",
        marginRight: 12,
    },

    headerTitle: {
        fontSize: 24,
        fontWeight: "700",
        color: "#111111",
    },

    content: {
        flex: 1,
        alignItems: "center",
        justifyContent: "center",
        padding: 24,
    },

    card: {
        width: 520,
        minHeight: 260,
        backgroundColor: "#FFFFFF",
        borderRadius: 12,
        alignItems: "center",
        justifyContent: "center",
        padding: 32,
    },

    title: {
        fontSize: 24,
        fontWeight: "800",
        color: "#111111",
        marginTop: 16,
        marginBottom: 8,
    },

    desc: {
        fontSize: 15,
        color: "#777777",
        textAlign: "center",
        lineHeight: 22,
        marginBottom: 22,
    },

    button: {
        height: 42,
        borderRadius: 6,
        backgroundColor: "#4D9858",
        paddingHorizontal: 22,
        alignItems: "center",
        justifyContent: "center",
    },

    buttonText: {
        fontSize: 15,
        fontWeight: "700",
        color: "#FFFFFF",
    },
});