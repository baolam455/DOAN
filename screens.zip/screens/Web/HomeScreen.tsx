import React from "react";
import { SafeAreaView, View, StyleSheet } from "react-native";
import { useNavigation } from "@react-navigation/native";

import HomeHeader from "../../components/Web/Home/HomeHeader";
import HomeHeroBanner from "../../components/Web/Home/HomeHeroBanner";
import HomeActionBar from "../../components/Web/Home/HomeActionBar";

export default function HomeScreen() {
  const navigation = useNavigation<any>();

  return (
    <SafeAreaView style={styles.safeArea}>
      <View style={styles.container}>
        <HomeHeader />
        <HomeHeroBanner />
        <HomeActionBar onLoginPress={() => navigation.navigate("Login")} />
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: "#F5F5F5",
  },

  container: {
    flex: 1,
    backgroundColor: "#FFFFFF",
  },
});
