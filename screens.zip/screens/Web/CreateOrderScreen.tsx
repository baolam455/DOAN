import React, { useEffect, useState } from "react";
import {
    SafeAreaView,
    View,
    Text,
    TextInput,
    TouchableOpacity,
    StyleSheet,
    ScrollView,
    Platform,
    ActivityIndicator,
    Alert,
} from "react-native";
import type { DimensionValue, ViewStyle } from "react-native";
import { useNavigation } from "@react-navigation/native";
import { MaterialCommunityIcons } from "@expo/vector-icons";

import {
    getCurrentCustomer,
    logoutCustomer,
} from "../../services/customerApi";
import { createOrder } from "../../services/orderApi";

import DashboardSidebar from "../../components/Web/Dashboard/DashboardSidebar";
import DashboardQuickMenu from "../../components/Web/Dashboard/DashboardQuickMenu";

type CustomerProfile = {
    store_name?: string;
    email?: string;
    phone?: string;
};

type LocationStatus = "idle" | "loading" | "success" | "error";

const webNoOutline =
    Platform.OS === "web"
        ? ({
            outlineStyle: "none",
            outlineWidth: 0,
            outlineColor: "transparent",
        } as any)
        : null;

function getInitials(name?: string) {
    const cleanName = (name || "").trim();

    if (!cleanName) return "KH";

    const words = cleanName.split(/\s+/).filter(Boolean);

    if (words.length >= 2) {
        return `${words[0][0]}${words[1][0]}`.toUpperCase();
    }

    return cleanName.slice(0, 2).toUpperCase();
}

function formatMoneyText(value: string) {
    const number = Number(value.replace(/\D/g, "") || 0);
    return number.toLocaleString("vi-VN");
}

function HeaderTab({
    label,
    active = false,
}: {
    label: string;
    active?: boolean;
}) {
    return (
        <TouchableOpacity
            activeOpacity={0.8}
            style={[styles.headerTab, active && styles.headerTabActive, webNoOutline]}
        >
            <Text style={[styles.headerTabText, active && styles.headerTabTextActive]}>
                {label}
            </Text>
        </TouchableOpacity>
    );
}

function CheckCircle({ active }: { active: boolean }) {
    return (
        <View style={[styles.checkCircle, active && styles.checkCircleActive]}>
            {active && <MaterialCommunityIcons name="check" size={13} color="#FFFFFF" />}
        </View>
    );
}

function RadioOption({
    label,
    active = false,
    icon,
    onPress,
    compact = false,
}: {
    label: string;
    active?: boolean;
    icon?: any;
    onPress?: () => void;
    compact?: boolean;
}) {
    return (
        <TouchableOpacity
            activeOpacity={0.82}
            style={[styles.radioOption, compact && styles.radioOptionCompact, webNoOutline]}
            onPress={onPress}
        >
            <CheckCircle active={active} />

            {icon && (
                <MaterialCommunityIcons
                    name={icon}
                    size={20}
                    color={active ? "#4D9858" : "#111111"}
                    style={styles.radioIcon}
                />
            )}

            <Text style={styles.radioLabel}>{label}</Text>
        </TouchableOpacity>
    );
}

function LineInput({
    icon,
    placeholder,
    value,
    onChangeText,
    rightIcon,
    rightLabel,
    rightColor = "#4D9858",
    onRightPress,
}: {
    icon: any;
    placeholder: string;
    value: string;
    onChangeText: (value: string) => void;
    rightIcon?: any;
    rightLabel?: string;
    rightColor?: string;
    onRightPress?: () => void;
}) {
    return (
        <View style={styles.lineInputRow}>
            <MaterialCommunityIcons name={icon} size={20} color="#111111" />

            <TextInput
                style={[styles.lineInput, webNoOutline]}
                placeholder={placeholder}
                placeholderTextColor="#8F8F8F"
                value={value}
                onChangeText={onChangeText}
            />

            {rightIcon && onRightPress ? (
                <TouchableOpacity
                    activeOpacity={0.82}
                    style={[styles.lineRightButton, webNoOutline]}
                    onPress={onRightPress}
                >
                    <MaterialCommunityIcons name={rightIcon} size={17} color={rightColor} />
                    {rightLabel ? (
                        <Text style={[styles.lineRightText, { color: rightColor }]}>{rightLabel}</Text>
                    ) : null}
                </TouchableOpacity>
            ) : null}
        </View>
    );
}

function DropdownBox({
    dropdownId,
    value,
    options,
    onChange,
    width,
    disabled = false,
    activeDropdown,
    setActiveDropdown,
}: {
    dropdownId: string;
    value: string;
    options: string[];
    onChange: (value: string) => void;
    width?: DimensionValue;
    disabled?: boolean;
    activeDropdown: string | null;
    setActiveDropdown: (value: string | null) => void;
}) {
    const open = activeDropdown === dropdownId;
    const widthStyle = width !== undefined ? ({ width } as ViewStyle) : null;

    return (
        <View style={[styles.dropdownWrap, open && styles.dropdownWrapOpen, widthStyle]}>
            <TouchableOpacity
                activeOpacity={0.82}
                disabled={disabled}
                style={[styles.selectBox, disabled && styles.selectBoxDisabled, webNoOutline]}
                onPress={() => {
                    if (disabled) return;
                    setActiveDropdown(open ? null : dropdownId);
                }}
            >
                <Text
                    numberOfLines={1}
                    style={[styles.selectText, disabled && styles.selectTextDisabled]}
                >
                    {value}
                </Text>

                <MaterialCommunityIcons name="chevron-down" size={18} color="#4A4A4A" />
            </TouchableOpacity>

            {open && !disabled && (
                <View style={styles.dropdownMenu}>
                    {options.map((item) => {
                        const selected = item === value || value.endsWith(item);

                        return (
                            <TouchableOpacity
                                key={item}
                                activeOpacity={0.75}
                                style={[styles.dropdownItem, selected && styles.dropdownItemSelected, webNoOutline]}
                                onPress={() => {
                                    onChange(item);
                                    setActiveDropdown(null);
                                }}
                            >
                                <Text style={styles.dropdownItemText}>{item}</Text>
                                {selected ? (
                                    <MaterialCommunityIcons name="check" size={17} color="#4D9858" />
                                ) : null}
                            </TouchableOpacity>
                        );
                    })}
                </View>
            )}
        </View>
    );
}

function ServiceRow({
    title,
    desc,
    selected,
    onPress,
}: {
    title: string;
    desc: string;
    selected: boolean;
    onPress: () => void;
}) {
    return (
        <TouchableOpacity
            activeOpacity={0.82}
            style={[styles.serviceRow, webNoOutline]}
            onPress={onPress}
        >
            <Text style={styles.serviceTitle}>{title}</Text>

            <Text numberOfLines={1} style={styles.serviceDesc}>
                {desc}
            </Text>

            <View style={styles.serviceValueWrap}>
                <Text style={[styles.serviceValue, selected && styles.serviceValueSelected]}>
                    {selected ? "Đã chọn 1" : "Chưa chọn"}
                </Text>

                <MaterialCommunityIcons name="chevron-right" size={18} color="#555555" />
            </View>
        </TouchableOpacity>
    );
}

export default function CreateOrderScreen() {
    const navigation = useNavigation<any>();

    const [quickMenuVisible, setQuickMenuVisible] = useState(false);
    const [customer, setCustomer] = useState<CustomerProfile | null>(null);
    const [activeDropdown, setActiveDropdown] = useState<string | null>(null);
    const [locationStatus, setLocationStatus] = useState<LocationStatus>("idle");
    const [saving, setSaving] = useState(false);

    const [returnToShop, setReturnToShop] = useState(false);
    const [shopReturnAddress, setShopReturnAddress] = useState("");
    const [shippingType, setShippingType] = useState<"express" | "bbs">("express");
    const [transportType] = useState<"road">("road");
    const [pickupMethod, setPickupMethod] = useState<"home" | "post">("home");
    const [nearbyPostOffices, setNearbyPostOffices] = useState<string[]>([]);
    const [postOfficeStatus, setPostOfficeStatus] = useState<"idle" | "loading" | "done" | "error">("idle");
    const [selectedPostOffice, setSelectedPostOffice] = useState("");
    const [postOfficeOpen, setPostOfficeOpen] = useState(false);
    const [pickupAddress, setPickupAddress] = useState("");

    const [phone, setPhone] = useState("");
    const [receiverName, setReceiverName] = useState("");
    const [detailAddress, setDetailAddress] = useState("");

    const [specialAddress, setSpecialAddress] = useState("Địa chỉ đặc biệt");
    const [street, setStreet] = useState("Đường/Ấp/Khu");
    const [ward, setWard] = useState("Phường/Xã");
    const [province, setProvince] = useState("Tỉnh/TP");

    const [pickupDate, setPickupDate] = useState("Ngày 21/05");
    const [deliveryDate, setDeliveryDate] = useState("Hẹn giao");
    const [productName, setProductName] = useState("");
    const [weight, setWeight] = useState("0");
    const [quantity, setQuantity] = useState("1");
    const [cod, setCod] = useState("0");
    const [productValue, setProductValue] = useState("0");
    const [shipPayer, setShipPayer] = useState("Khách trả ship");
    const [shopOrderCode, setShopOrderCode] = useState("");

    const [highValue, setHighValue] = useState(false);
    const [pickupService, setPickupService] = useState(false);
    const [deliveryService, setDeliveryService] = useState(false);
    const [returnService, setReturnService] = useState(true);

    const dropdownControl = (dropdownId: string) => ({
        dropdownId,
        activeDropdown,
        setActiveDropdown,
    });

    useEffect(() => {
        const loadCustomer = async () => {
            try {
                const profile = await getCurrentCustomer();
                if (profile) setCustomer(profile);
            } catch (error) {
                console.log("Không lấy được thông tin khách hàng:", error);
            }
        };

        loadCustomer();
    }, []);

    const customerName = customer?.store_name || "Khách hàng";
    const customerInitials = getInitials(customerName);

    const goFeature = (title: string, description: string) => {
        navigation.navigate("Feature", { title, description });
    };

    const handleLogout = async () => {
        try {
            await logoutCustomer();
        } catch (error) {
            console.log("Đăng xuất lỗi:", error);
        } finally {
            navigation.reset({
                index: 0,
                routes: [{ name: "Login" }],
            });
        }
    };

    const handleFindPostOffices = async () => {
        setActiveDropdown(null);
        if (Platform.OS !== "web") return;
        const geo = (globalThis.navigator as any)?.geolocation;
        if (!geo) { alert("Trình duyệt không hỗ trợ vị trí."); return; }
        setPostOfficeStatus("loading");
        geo.getCurrentPosition(
            async (position: any) => {
                const lat = position.coords.latitude;
                const lon = position.coords.longitude;
                try {
                    // Tìm bưu cục + bưu điện + vnpost trong bán kính 3km
                    const queries = [
                        `https://nominatim.openstreetmap.org/search?format=json&q=bưu+cục&lat=${lat}&lon=${lon}&bounded=1&viewbox=${lon-0.08},${lat+0.08},${lon+0.08},${lat-0.08}&limit=8&accept-language=vi`,
                        `https://nominatim.openstreetmap.org/search?format=json&q=bưu+điện&lat=${lat}&lon=${lon}&bounded=1&viewbox=${lon-0.08},${lat+0.08},${lon+0.08},${lat-0.08}&limit=5&accept-language=vi`,
                    ];
                    const [r1, r2] = await Promise.all(queries.map(u => fetch(u).then(r => r.json()).catch(() => [])));
                    const combined = [...(r1 || []), ...(r2 || [])];
                    // Dedupe theo tên
                    const seen = new Set<string>();
                    const names: string[] = [];
                    for (const p of combined) {
                        const parts = (p.display_name || "").split(",").slice(0, 4);
                        const name = parts.join(",").trim();
                        if (!seen.has(name)) { seen.add(name); names.push(name); }
                    }
                    if (names.length > 0) {
                        setNearbyPostOffices(names.slice(0, 10));
                        setSelectedPostOffice(names[0]);
                        setPostOfficeOpen(true);
                    } else {
                        // fallback địa chỉ hành chính
                        const revRes = await fetch(`https://nominatim.openstreetmap.org/reverse?format=jsonv2&lat=${lat}&lon=${lon}&accept-language=vi`);
                        const revData = await revRes.json();
                        const addr = revData?.address || {};
                        const q2 = addr.suburb || addr.city_district || addr.quarter || addr.town || "";
                        const q3 = addr.county || addr.state_district || "";
                        const city = addr.city || addr.state || "";
                        const suggestions = [
                            q2 ? `Bưu cục ${q2}${city ? ", " + city : ""}` : null,
                            q3 ? `Bưu điện ${q3}${city ? ", " + city : ""}` : null,
                            `Bưu cục trung tâm ${city}`,
                            city ? `Bưu điện ${city}` : null,
                            q2 ? `VNPost - ${q2}` : null,
                        ].filter(Boolean) as string[];
                        setNearbyPostOffices(suggestions);
                        setSelectedPostOffice(suggestions[0]);
                        setPostOfficeOpen(true);
                    }
                    setPostOfficeStatus("done");
                } catch {
                    setPostOfficeStatus("error");
                    alert("Không tìm được bưu cục gần nhất.");
                }
            },
            () => { setPostOfficeStatus("error"); alert("Không lấy được vị trí."); },
            { enableHighAccuracy: true, timeout: 12000, maximumAge: 0 }
        );
    };

        const handleUseCurrentLocation = () => {
        setActiveDropdown(null);

        if (Platform.OS !== "web") {
            alert("Tính năng vị trí hiện tại đang ưu tiên bản web trước.");
            return;
        }

        const geo = (globalThis.navigator as any)?.geolocation;

        if (!geo) {
            alert("Trình duyệt của bạn không hỗ trợ lấy vị trí hiện tại.");
            return;
        }

        setLocationStatus("loading");

        geo.getCurrentPosition(
            async (position: any) => {
                const lat = position.coords.latitude;
                const lon = position.coords.longitude;

                try {
                    const response = await fetch(
                        `https://nominatim.openstreetmap.org/reverse?format=jsonv2&lat=${lat}&lon=${lon}&accept-language=vi`
                    );
                    const data = await response.json();
                    const address = data?.address || {};
                    const displayName = data?.display_name || `Vị trí hiện tại: ${lat.toFixed(6)}, ${lon.toFixed(6)}`;

                    setDetailAddress(displayName);
                    setSpecialAddress("Vị trí hiện tại");
                    setStreet(address.road || address.neighbourhood || address.quarter || "Đường/Ấp/Khu");
                    setWard(address.suburb || address.city_district || address.town || address.village || address.hamlet || "Phường/Xã");
                    setProvince(address.city || address.state || address.province || "Tỉnh/TP");
                    setLocationStatus("success");
                } catch (error) {
                    setDetailAddress(`Vị trí hiện tại: ${lat.toFixed(6)}, ${lon.toFixed(6)}`);
                    setSpecialAddress("Vị trí hiện tại");
                    setLocationStatus("success");
                }
            },
            () => {
                setLocationStatus("error");
                alert("Không lấy được vị trí. Bạn cần cho phép trình duyệt truy cập vị trí.");
            },
            {
                enableHighAccuracy: true,
                timeout: 12000,
                maximumAge: 0,
            }
        );
    };

    const handleCreateOrder = async () => {
        const phoneClean = phone.trim();
        const nameClean = receiverName.trim();
        const addressClean = detailAddress.trim();
        const productNameClean = productName.trim();

        if (!phoneClean || !nameClean || !addressClean) {
            const msg = "Vui lòng nhập đủ số điện thoại, tên và địa chỉ người nhận.";
            if (Platform.OS === "web") { (globalThis as any).alert(msg); } else { Alert.alert("Thiếu thông tin", msg); }
            return;
        }
        if (!productNameClean) {
            const msg = "Vui lòng nhập tên sản phẩm.";
            if (Platform.OS === "web") { (globalThis as any).alert(msg); } else { Alert.alert("Thiếu thông tin", msg); }
            return;
        }

        setSaving(true);
        try {
            await createOrder({
                receiverPhone: phoneClean,
                receiverName: nameClean,
                receiverAddress: addressClean,
                receiverWard: ward !== "Phường/Xã" ? ward : undefined,
                receiverProvince: province !== "Tỉnh/TP" ? province : undefined,
                shippingType,
                transportType,
                pickupMethod,
                shipPayer: shipPayer === "Shop trả ship" ? "shop" : "customer",
                codAmount: Number(cod.replace(/\D/g, "") || 0),
                productValue: Number(productValue.replace(/\D/g, "") || 0),
                totalWeight: Number(weight) || 0,
                productName: productNameClean,
                quantity: Number(quantity) || 1,
                shopOrderCode: shopOrderCode.trim() || undefined,
            });

            const msg = "Đơn hàng đã được tạo thành công!";
            if (Platform.OS === "web") { (globalThis as any).alert(msg); } else { Alert.alert("Thành công", msg); }
            navigation.navigate("OrderList");
        } catch (e: any) {
            const msg = e?.message || "Không thể tạo đơn hàng, vui lòng thử lại.";
            if (Platform.OS === "web") { (globalThis as any).alert("Lỗi: " + msg); } else { Alert.alert("Lỗi", msg); }
        } finally {
            setSaving(false);
        }
    };

    const leftTitle = returnToShop ? "Người gửi" : "Người nhận";
    const personText = returnToShop ? "người gửi" : "người nhận";
    const totalMoney = Number(cod.replace(/\D/g, "") || 0) + Number(productValue.replace(/\D/g, "") || 0);

    return (
        <SafeAreaView style={styles.safeArea}>
            <View style={styles.root}>
                {quickMenuVisible && (
                    <TouchableOpacity
                        activeOpacity={1}
                        style={styles.menuBackdrop}
                        onPress={() => setQuickMenuVisible(false)}
                    />
                )}

                {quickMenuVisible && <DashboardQuickMenu onLogout={handleLogout} />}

                <DashboardSidebar
                    initials={customerInitials}
                    onToggleQuickMenu={() => setQuickMenuVisible((prev) => !prev)}
                    onPressOverview={() => navigation.navigate("Dashboard")}
                    onPressOrders={() => goFeature("Danh sách đơn hàng", "Màn này sẽ hiển thị đơn nháp, đơn đã tạo, đơn đang giao, đơn hoàn và đơn thành công.")}
                    onPressReport={() => goFeature("Báo cáo thống kê", "Màn này sẽ hiển thị hiệu suất giao hàng, doanh thu và thời gian giao trung bình.")}
                    onPressMoney={() => goFeature("COD và đối soát", "Màn này sẽ quản lý tiền thu hộ, phí vận chuyển và lịch sử đối soát.")}
                    onPressChat={() => goFeature("Hỗ trợ khách hàng", "Màn này sẽ dùng cho chat, khiếu nại và hỗ trợ xử lý đơn hàng.")}
                    onPressWallet={() => goFeature("Ví thanh toán", "Màn này sẽ quản lý ví, thanh toán, COD và liên kết ngân hàng.")}
                    onPressHelp={() => goFeature("Trung tâm hỗ trợ", "Màn này sẽ chứa hướng dẫn sử dụng và câu hỏi thường gặp.")}
                />

                <View style={styles.mainArea}>
                    <View style={styles.header}>
                        <View style={styles.headerLeft}>
                            <Text style={styles.pageTitle}>Tạo đơn hàng</Text>

                            <View style={styles.headerTabs}>
                                <HeaderTab label="Đăng đơn lẻ" active />
                                <HeaderTab label="Đăng đơn Excel" />
                                <HeaderTab label="Đơn nháp 0" />
                                <HeaderTab label="Đơn đã tạo 0" />
                            </View>
                        </View>

                        <TouchableOpacity
                            activeOpacity={0.85}
                            style={[styles.createButton, saving && { opacity: 0.7 }, webNoOutline]}
                            onPress={handleCreateOrder}
                            disabled={saving}
                        >
                            {saving ? (
                                <ActivityIndicator size="small" color="#FFFFFF" />
                            ) : (
                                <MaterialCommunityIcons name="plus" size={20} color="#FFFFFF" />
                            )}
                            <Text style={styles.createButtonText}>
                                {saving ? "Đang tạo..." : "Tạo đơn hàng"}
                            </Text>
                        </TouchableOpacity>
                    </View>

                    <ScrollView
                        style={styles.scrollArea}
                        contentContainerStyle={styles.scrollContent}
                        showsVerticalScrollIndicator
                        onScrollBeginDrag={() => setActiveDropdown(null)}
                    >
                        <View style={styles.formCard}>
                            <View style={[styles.leftForm, activeDropdown && styles.activeColumn]}>
                                <View style={styles.sectionHeaderRow}>
                                    <Text style={styles.sectionTitle}>{leftTitle}</Text>

                                    <TouchableOpacity
                                        activeOpacity={0.82}
                                        style={[styles.sendBackRow, webNoOutline]}
                                        onPress={() => {
                                            setReturnToShop((prev) => !prev);
                                            setActiveDropdown(null);
                                        }}
                                    >
                                        <CheckCircle active={returnToShop} />
                                        <Text style={styles.sendBackText}>Giao về shop</Text>
                                    </TouchableOpacity>
                                </View>

                                <LineInput
                                    icon="phone-outline"
                                    placeholder={`Nhập số điện thoại ${personText}`}
                                    value={phone}
                                    onChangeText={(text) => setPhone(text.replace(/\D/g, "").slice(0, 10))}
                                />

                                <LineInput
                                    icon="account-outline"
                                    placeholder={`Tên ${personText}`}
                                    value={receiverName}
                                    onChangeText={setReceiverName}
                                />

                                <LineInput
                                    icon="home-outline"
                                    placeholder="Địa chỉ chi tiết"
                                    value={detailAddress}
                                    onChangeText={setDetailAddress}
                                    rightIcon="crosshairs-gps"
                                    rightLabel={locationStatus === "loading" ? "Đang lấy" : "Vị trí"}
                                    rightColor={locationStatus === "error" ? "#E45B58" : "#4D9858"}
                                    onRightPress={handleUseCurrentLocation}
                                />

                                <View style={styles.addressRow}>
                                    <MaterialCommunityIcons name="map-marker-outline" size={20} color="#111111" />

                                    <View style={styles.addressGrid}>
                                        <DropdownBox
                                            {...dropdownControl("specialAddress")}
                                            value={specialAddress}
                                            onChange={setSpecialAddress}
                                            options={["Địa chỉ đặc biệt", "Vị trí hiện tại", "Chung cư", "Tòa nhà", "Khu công nghiệp"]}
                                            width="49%"
                                        />

                                        <DropdownBox
                                            {...dropdownControl("street")}
                                            value={street}
                                            onChange={setStreet}
                                            options={["Đường/Ấp/Khu", "Đường số 1", "Đường số 2", "Khu phố 3"]}
                                            width="49%"
                                        />

                                        <DropdownBox
                                            {...dropdownControl("ward")}
                                            value={ward}
                                            onChange={setWard}
                                            options={["Phường/Xã", "Phường Tân Thuận", "Phường Tân Bình", "Phường Bến Nghé", "Phường 1"]}
                                            width="49%"
                                        />

                                        <DropdownBox
                                            {...dropdownControl("province")}
                                            value={province}
                                            onChange={setProvince}
                                            options={["Tỉnh/TP", "Thành phố Thủ Đức", "TP Hồ Chí Minh", "Hà Nội", "Đà Nẵng"]}
                                            width="49%"
                                        />
                                    </View>
                                </View>

                                {returnToShop ? (
                                    <View style={styles.returnShopBlock}>
                                        <Text style={styles.sectionTitle}>Giao về shop</Text>
                                        <View style={styles.returnShopLine}>
                                            <MaterialCommunityIcons name="map-marker-outline" size={18} color="#E45B58" style={{ marginRight: 8 }} />
                                            <TextInput
                                                style={[styles.shopAddressInput, webNoOutline]}
                                                placeholder="Nhập địa chỉ shop nhận hàng hoàn"
                                                placeholderTextColor="#9F9F9F"
                                                value={shopReturnAddress}
                                                onChangeText={setShopReturnAddress}
                                            />
                                        </View>
                                    </View>
                                ) : null}

                                <Text style={[styles.sectionTitle, styles.sectionSpacing]}>Lấy & Giao tận nơi</Text>

                                <View style={styles.optionRow}>
                                    <RadioOption
                                        label="EXPRESS nhanh < 20kg"
                                        icon="truck-fast-outline"
                                        active={shippingType === "express"}
                                        onPress={() => {
                                            setShippingType("express");
                                            setActiveDropdown(null);
                                        }}
                                    />

                                    <RadioOption
                                        label="BBS lớn ≥ 20kg"
                                        icon="truck-cargo-container"
                                        active={shippingType === "bbs"}
                                        onPress={() => {
                                            setShippingType("bbs");
                                            setActiveDropdown(null);
                                        }}
                                    />
                                </View>

                                <View style={[styles.deliveryLine, { zIndex: 600 }]}>
                                    <RadioOption
                                        label="Đường Bộ"
                                        icon="truck-outline"
                                        active={true}
                                        compact
                                    />

                                    <DropdownBox
                                        {...dropdownControl("pickupDate")}
                                        value={pickupDate}
                                        onChange={setPickupDate}
                                        options={["Ngày 21/05", "Ngày 22/05", "Ngày 23/05"]}
                                        width={222}
                                        disabled={false}
                                    />

                                    <DropdownBox
                                        {...dropdownControl("deliveryDate")}
                                        value={deliveryDate}
                                        onChange={setDeliveryDate}
                                        options={["Hẹn giao", "Giao trong ngày", "Giao hôm sau"]}
                                        width={222}
                                        disabled={false}
                                    />
                                </View>



                                <Text style={[styles.sectionTitle, styles.sectionSpacing]}>Hình thức lấy hàng</Text>

                                <View style={styles.pickupLine}>
                                    <RadioOption
                                        label="Lấy hàng tận nơi"
                                        active={pickupMethod === "home"}
                                        onPress={() => setPickupMethod("home")}
                                        compact
                                    />

                                    <View style={[styles.pickupAddressBox, pickupMethod !== "home" && styles.selectBoxDisabled]}>
                                        <MaterialCommunityIcons name="map-marker-outline" size={17} color="#E53935" style={{ marginRight: 6 }} />
                                        <TextInput
                                            style={[styles.pickupAddressText, webNoOutline]}
                                            placeholder="Nhập địa chỉ lấy hàng"
                                            placeholderTextColor="#9F9F9F"
                                            value={pickupAddress}
                                            onChangeText={setPickupAddress}
                                            editable={pickupMethod === "home"}
                                        />
                                    </View>
                                </View>

                                <View style={[styles.pickupLine, { alignItems: "flex-start" }]}>
                                    <View style={{ paddingTop: 9 }}>
                                        <RadioOption
                                            label="Gửi hàng bưu cục"
                                            active={pickupMethod === "post"}
                                            onPress={() => {
                                                setPickupMethod("post");
                                                if (nearbyPostOffices.length === 0 && postOfficeStatus === "idle") {
                                                    handleFindPostOffices();
                                                }
                                            }}
                                            compact
                                        />
                                    </View>

                                    {pickupMethod === "post" && (
                                        <View style={styles.postOfficeBox}>
                                            {postOfficeStatus === "loading" ? (
                                                <View style={styles.postOfficeLoading}>
                                                    <ActivityIndicator size="small" color="#4D9858" />
                                                    <Text style={styles.postOfficeLoadingText}>Đang tìm bưu cục gần nhất...</Text>
                                                </View>
                                            ) : selectedPostOffice && !postOfficeOpen ? (
                                                // Đã chọn xong → chỉ hiện bưu cục đã chọn + nút Đổi
                                                <TouchableOpacity
                                                    activeOpacity={0.85}
                                                    style={[styles.postOfficeSelected, webNoOutline]}
                                                    onPress={() => setPostOfficeOpen(true)}
                                                >
                                                    <MaterialCommunityIcons name="radiobox-marked" size={16} color="#4D9858" />
                                                    <Text style={styles.postOfficeNameSelected} numberOfLines={2}>
                                                        {selectedPostOffice}
                                                    </Text>
                                                    <Text style={styles.postOfficeChangeBtn}>Đổi</Text>
                                                </TouchableOpacity>
                                            ) : nearbyPostOffices.length > 0 ? (
                                                // Đang mở danh sách
                                                <>
                                                    {nearbyPostOffices.map((po, idx) => (
                                                        <TouchableOpacity
                                                            key={idx}
                                                            activeOpacity={0.8}
                                                            style={[styles.postOfficeItem, selectedPostOffice === po && styles.postOfficeItemSelected, webNoOutline]}
                                                            onPress={() => {
                                                                setSelectedPostOffice(po);
                                                                setPostOfficeOpen(false);
                                                            }}
                                                        >
                                                            <MaterialCommunityIcons
                                                                name={selectedPostOffice === po ? "radiobox-marked" : "radiobox-blank"}
                                                                size={16}
                                                                color={selectedPostOffice === po ? "#4D9858" : "#AAAAAA"}
                                                            />
                                                            <Text style={[styles.postOfficeName, selectedPostOffice === po && styles.postOfficeNameSelected]} numberOfLines={2}>
                                                                {po}
                                                            </Text>
                                                        </TouchableOpacity>
                                                    ))}
                                                    <TouchableOpacity activeOpacity={0.8} style={[styles.postOfficeRefresh, webNoOutline]} onPress={handleFindPostOffices}>
                                                        <MaterialCommunityIcons name="refresh" size={14} color="#4D9858" />
                                                        <Text style={styles.postOfficeRefreshText}>Tìm lại</Text>
                                                    </TouchableOpacity>
                                                </>
                                            ) : postOfficeStatus === "error" ? (
                                                <TouchableOpacity activeOpacity={0.8} style={[styles.postOfficeLoading, webNoOutline]} onPress={handleFindPostOffices}>
                                                    <MaterialCommunityIcons name="alert-circle-outline" size={16} color="#E45B58" />
                                                    <Text style={[styles.postOfficeLoadingText, { color: "#E45B58" }]}>Không tìm được — Thử lại</Text>
                                                </TouchableOpacity>
                                            ) : (
                                                <TouchableOpacity activeOpacity={0.8} style={[styles.postOfficeLoading, webNoOutline]} onPress={handleFindPostOffices}>
                                                    <MaterialCommunityIcons name="map-search-outline" size={16} color="#4D9858" />
                                                    <Text style={styles.postOfficeLoadingText}>Bấm để tìm bưu cục gần nhất</Text>
                                                </TouchableOpacity>
                                            )}
                                        </View>
                                    )}
                                </View>
                            </View>

                            <View style={styles.rightForm}>
                                <View style={styles.productHeader}>
                                    <Text style={styles.sectionTitle}>Sản phẩm</Text>

                                    <TouchableOpacity activeOpacity={0.8} style={webNoOutline}>
                                        <Text style={styles.greenLink}>+ Sản phẩm có sẵn</Text>
                                    </TouchableOpacity>
                                </View>

                                <View style={[styles.productInputRow, activeDropdown && styles.productInputRowLower]}>
                                    <TouchableOpacity activeOpacity={0.82} style={[styles.productImageBox, webNoOutline]}>
                                        <MaterialCommunityIcons name="image-plus" size={28} color="#CFCFCF" />
                                    </TouchableOpacity>

                                    <View style={styles.productInputGroup}>
                                        <View style={styles.productNameRow}>
                                            <Text style={styles.productIndex}>1.</Text>

                                            <TextInput
                                                style={[styles.productNameInput, webNoOutline]}
                                                placeholder="Nhập tên sản phẩm"
                                                placeholderTextColor="#8F8F8F"
                                                value={productName}
                                                onChangeText={setProductName}
                                            />

                                            <Text style={styles.productPrice}>0</Text>
                                        </View>

                                        <View style={styles.productSelectRow}>
                                            <DropdownBox
                                                {...dropdownControl("productWeight")}
                                                value={`Khối lượng (kg) ${weight}`}
                                                onChange={setWeight}
                                                options={["0", "0.5", "1", "2", "5"]}
                                                width="49.5%"
                                            />

                                            <DropdownBox
                                                {...dropdownControl("productQuantity")}
                                                value={`Số lượng ${quantity}`}
                                                onChange={setQuantity}
                                                options={["1", "2", "3", "4", "5"]}
                                                width="49.5%"
                                            />
                                        </View>
                                    </View>

                                    <TouchableOpacity
                                        activeOpacity={0.85}
                                        style={[styles.addProductBtn, webNoOutline]}
                                        onPress={() => goFeature("Thêm sản phẩm", "Bước sau mình sẽ làm thêm nhiều sản phẩm trong một đơn.")}
                                    >
                                        <MaterialCommunityIcons name="plus" size={27} color="#4D9858" />
                                    </TouchableOpacity>
                                </View>

                                <View style={styles.priceArea}>
                                    <View style={styles.priceRows}>
                                        <View style={styles.priceRow}>
                                            <Text style={styles.priceLabel}>Tổng KL</Text>
                                            <DropdownBox
                                                {...dropdownControl("totalWeight")}
                                                value={`${weight}   kg`}
                                                onChange={setWeight}
                                                options={["0", "0.5", "1", "2", "5"]}
                                                width={112}
                                            />
                                        </View>

                                        <View style={styles.priceRow}>
                                            <Text style={styles.priceLabel}>Khối lượng tính cước</Text>
                                            <Text style={styles.priceValue}>{weight} kg <Text style={styles.greenSmall}>(?)</Text></Text>
                                        </View>

                                        <View style={styles.priceRow}>
                                            <Text style={styles.priceLabel}>Tiền thu hộ</Text>
                                            <TextInput
                                                style={[styles.priceInput, webNoOutline]}
                                                value={formatMoneyText(cod)}
                                                onChangeText={(text) => setCod(text.replace(/\D/g, ""))}
                                                placeholder="0đ"
                                                placeholderTextColor="#B5B5B5"
                                            />
                                        </View>

                                        <View style={styles.priceRow}>
                                            <Text style={styles.priceLabel}>Giá trị hàng</Text>
                                            <TextInput
                                                style={[styles.priceInput, webNoOutline]}
                                                value={formatMoneyText(productValue)}
                                                onChangeText={(text) => setProductValue(text.replace(/\D/g, ""))}
                                                placeholder="0đ"
                                                placeholderTextColor="#111111"
                                            />
                                            <Text style={styles.greenSmall}>Miễn phí khai giá (?)</Text>
                                        </View>

                                        <View style={styles.priceRow}>
                                            <Text style={styles.priceLabel}>Phí ship</Text>
                                            <Text style={styles.priceValue}>0đ</Text>
                                            <DropdownBox
                                                {...dropdownControl("shipPayer")}
                                                value={shipPayer}
                                                onChange={setShipPayer}
                                                options={["Khách trả ship", "Shop trả ship"]}
                                                width={150}
                                            />
                                        </View>

                                        <View style={styles.priceRow}>
                                            <Text style={styles.priceLabel}>Tổng tiền</Text>
                                            <Text style={styles.priceValue}>{totalMoney.toLocaleString("vi-VN")}đ</Text>
                                        </View>

                                        <View style={styles.priceRow}>
                                            <Text style={styles.priceLabel}>Mã ĐH riêng</Text>
                                            <TextInput
                                                style={[styles.orderCodeInput, webNoOutline]}
                                                placeholder="Nhập mã đơn hàng riêng của shop"
                                                placeholderTextColor="#999999"
                                                value={shopOrderCode}
                                                onChangeText={setShopOrderCode}
                                            />
                                        </View>
                                    </View>

                                    <TouchableOpacity activeOpacity={0.82} style={[styles.orderImageBox, webNoOutline]}>
                                        <MaterialCommunityIcons name="image-plus" size={27} color="#CFCFCF" />
                                        <Text style={styles.orderImageText}>Ảnh ĐH</Text>
                                    </TouchableOpacity>
                                </View>

                                <Text style={[styles.sectionTitle, styles.solutionTitle]}>Dịch vụ giải pháp</Text>

                                <TouchableOpacity
                                    activeOpacity={0.82}
                                    style={[styles.checkboxLine, webNoOutline]}
                                    onPress={() => setHighValue((prev) => !prev)}
                                >
                                    <View style={[styles.smallCheckbox, highValue && styles.smallCheckboxActive]}>
                                        {highValue && <MaterialCommunityIcons name="check" size={13} color="#FFFFFF" />}
                                    </View>

                                    <Text style={styles.checkboxText}>Hàng giá trị cao ≥ 1,000,000đ</Text>
                                    <Text style={styles.greenSmall}>+Ảnh giá trị</Text>
                                </TouchableOpacity>

                                <ServiceRow
                                    title="Lấy hàng"
                                    desc="Gọi shop trước khi lấy hàng, Đồng kiểm khi lấy hàng"
                                    selected={pickupService}
                                    onPress={() => setPickupService((prev) => !prev)}
                                />

                                <ServiceRow
                                    title="Giao hàng"
                                    desc="Xem hàng, Gọi shop khi không giao được, Giao hàng 1 phần chọn SP, Giao..."
                                    selected={deliveryService}
                                    onPress={() => setDeliveryService((prev) => !prev)}
                                />

                                <ServiceRow
                                    title="Hoàn hàng"
                                    desc="Tự động lưu kho chờ check"
                                    selected={returnService}
                                    onPress={() => setReturnService((prev) => !prev)}
                                />
                            </View>
                        </View>
                    </ScrollView>

                    <View style={styles.verifyBox}>
                        <Text style={styles.verifyText}>Vui lòng xác thực CMT/CCCD và liên kết ngân hàng</Text>
                    </View>
                </View>
            </View>
        </SafeAreaView>
    );
}

const styles = StyleSheet.create({
    safeArea: {
        flex: 1,
        backgroundColor: "#F2F2F2",
    },

    root: {
        flex: 1,
        flexDirection: "row",
        backgroundColor: "#F2F2F2",
    },

    menuBackdrop: {
        position: "absolute",
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        zIndex: 20,
    },

    mainArea: {
        flex: 1,
        backgroundColor: "#F2F2F2",
    },

    header: {
        height: 72,
        backgroundColor: "#FFFFFF",
        borderBottomWidth: 1,
        borderBottomColor: "#E6E6E6",
        paddingLeft: 24,
        paddingRight: 28,
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "space-between",
    },

    headerLeft: {
        flexDirection: "row",
        alignItems: "center",
    },

    pageTitle: {
        fontSize: 22,
        fontWeight: "700",
        color: "#111111",
        marginRight: 24,
    },

    headerTabs: {
        flexDirection: "row",
        alignItems: "center",
    },

    headerTab: {
        height: 38,
        borderRadius: 6,
        paddingHorizontal: 15,
        justifyContent: "center",
        alignItems: "center",
        marginRight: 8,
    },

    headerTabActive: {
        backgroundColor: "#EAF6EC",
    },

    headerTabText: {
        fontSize: 14,
        color: "#111111",
        fontWeight: "500",
    },

    headerTabTextActive: {
        color: "#4D9858",
        fontWeight: "700",
    },

    createButton: {
        height: 42,
        borderRadius: 6,
        backgroundColor: "#4D9858",
        paddingHorizontal: 18,
        flexDirection: "row",
        alignItems: "center",
    },

    createButtonText: {
        fontSize: 15,
        fontWeight: "600",
        color: "#FFFFFF",
        marginLeft: 8,
    },

    scrollArea: {
        flex: 1,
    },

    scrollContent: {
        paddingHorizontal: 24,
        paddingTop: 24,
        paddingBottom: 110,
    },

    formCard: {
        backgroundColor: "#FFFFFF",
        borderRadius: 7,
        flexDirection: "row",
        minHeight: 660,
        overflow: "visible",
    },

    leftForm: {
        flex: 1,
        paddingHorizontal: 24,
        paddingTop: 24,
        paddingBottom: 24,
        borderRightWidth: 1,
        borderRightColor: "#EEEEEE",
        overflow: "visible",
        zIndex: 8,
    },

    activeColumn: {
        zIndex: 999,
    },

    rightForm: {
        flex: 1,
        paddingHorizontal: 24,
        paddingTop: 24,
        paddingBottom: 24,
        overflow: "visible",
        zIndex: 4,
    },

    sectionHeaderRow: {
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "space-between",
    },

    sectionTitle: {
        fontSize: 16,
        fontWeight: "700",
        color: "#111111",
    },

    sendBackRow: {
        flexDirection: "row",
        alignItems: "center",
    },

    sendBackText: {
        fontSize: 14,
        color: "#111111",
        marginLeft: 8,
    },

    checkCircle: {
        width: 19,
        height: 19,
        borderRadius: 10,
        borderWidth: 1,
        borderColor: "#D5D5D5",
        alignItems: "center",
        justifyContent: "center",
        backgroundColor: "#FFFFFF",
    },

    checkCircleActive: {
        borderColor: "#4D9858",
        backgroundColor: "#4D9858",
    },

    lineInputRow: {
        height: 51,
        borderBottomWidth: 1,
        borderBottomColor: "#EEEEEE",
        flexDirection: "row",
        alignItems: "center",
    },

    lineInput: {
        flex: 1,
        height: 51,
        fontSize: 14,
        color: "#111111",
        marginLeft: 12,
        paddingVertical: 0,
    },

    lineRightButton: {
        height: 32,
        paddingHorizontal: 8,
        flexDirection: "row",
        alignItems: "center",
        borderRadius: 4,
    },

    lineRightText: {
        fontSize: 13,
        fontWeight: "600",
        marginLeft: 4,
    },

    addressRow: {
        flexDirection: "row",
        alignItems: "flex-start",
        marginTop: 16,
        zIndex: 700,
        overflow: "visible",
    },

    addressGrid: {
        flex: 1,
        marginLeft: 12,
        flexDirection: "row",
        flexWrap: "wrap",
        justifyContent: "space-between",
        overflow: "visible",
    },

    dropdownWrap: {
        position: "relative",
        marginBottom: 10,
        zIndex: 1,
    },

    dropdownWrapOpen: {
        zIndex: 10000,
    },

    selectBox: {
        height: 38,
        backgroundColor: "#F4F4F4",
        borderRadius: 4,
        paddingHorizontal: 12,
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "space-between",
    },

    selectBoxDisabled: {
        opacity: 0.5,
    },

    selectText: {
        flex: 1,
        fontSize: 14,
        color: "#777777",
    },

    selectTextDisabled: {
        color: "#999999",
    },

    dropdownMenu: {
        position: "absolute",
        top: 41,
        left: 0,
        right: 0,
        backgroundColor: "#FFFFFF",
        borderRadius: 4,
        borderWidth: 1,
        borderColor: "#E6E6E6",
        shadowColor: "#000000",
        shadowOffset: { width: 0, height: 8 },
        shadowOpacity: 0.14,
        shadowRadius: 18,
        elevation: 18,
        zIndex: 20000,
    },

    dropdownItem: {
        height: 39,
        paddingHorizontal: 12,
        borderBottomWidth: 1,
        borderBottomColor: "#F0F0F0",
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "space-between",
    },

    dropdownItemSelected: {
        backgroundColor: "#F6F6F6",
    },

    dropdownItemText: {
        fontSize: 14,
        color: "#111111",
    },

    returnShopBlock: {
        marginTop: 44,
    },

    returnShopLine: {
        marginTop: 22,
        flexDirection: "row",
        alignItems: "center",
    },

    returnShopLabel: {
        width: 170,
        fontSize: 14,
        color: "#111111",
    },

    shopAddressBox: {
        flex: 1,
        height: 38,
        backgroundColor: "#F4F4F4",
        borderRadius: 4,
        paddingHorizontal: 12,
        flexDirection: "row",
        alignItems: "center",
    },

    shopAddressText: {
        flex: 1,
        fontSize: 14,
        color: "#111111",
    },

    sectionSpacing: {
        marginTop: 34,
        marginBottom: 14,
    },

    optionRow: {
        flexDirection: "row",
        alignItems: "center",
        marginBottom: 14,
    },

    radioOption: {
        flexDirection: "row",
        alignItems: "center",
        marginRight: 24,
        minWidth: 150,
    },

    radioOptionCompact: {
        width: 190,
        minWidth: 190,
        marginRight: 0,
    },

    radioIcon: {
        marginLeft: 8,
        marginRight: 6,
    },

    radioLabel: {
        fontSize: 14,
        color: "#111111",
    },

    deliveryLine: {
        flexDirection: "row",
        alignItems: "center",
        marginBottom: 12,
        zIndex: 500,
        overflow: "visible",
    },

    pickupLine: {
        flexDirection: "row",
        alignItems: "center",
        marginBottom: 12,
    },

    pickupAddressBox: {
        flex: 1,
        height: 38,
        backgroundColor: "#F4F4F4",
        borderRadius: 4,
        paddingHorizontal: 12,
        marginLeft: 12,
        flexDirection: "row",
        alignItems: "center",
    },

    pickupAddressText: {
        flex: 1,
        fontSize: 14,
        color: "#111111",
    },

    placeholderText: {
        flex: 1,
        fontSize: 14,
        color: "#999999",
    },

    productHeader: {
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "space-between",
        marginBottom: 22,
    },

    greenLink: {
        fontSize: 14,
        color: "#4D9858",
        fontWeight: "600",
    },

    productInputRow: {
        flexDirection: "row",
        alignItems: "stretch",
        marginBottom: 18,
        zIndex: 900,
        overflow: "visible",
    },

    productInputRowLower: {
        zIndex: 4,
    },

    productImageBox: {
        width: 72,
        height: 72,
        borderRadius: 4,
        backgroundColor: "#F1F1F1",
        alignItems: "center",
        justifyContent: "center",
        marginRight: 8,
    },

    productInputGroup: {
        flex: 1,
        overflow: "visible",
    },

    productNameRow: {
        height: 34,
        backgroundColor: "#F4F4F4",
        borderRadius: 4,
        flexDirection: "row",
        alignItems: "center",
        paddingHorizontal: 10,
        marginBottom: 4,
    },

    productIndex: {
        fontSize: 14,
        color: "#111111",
        fontWeight: "700",
        marginRight: 8,
    },

    productNameInput: {
        flex: 1,
        height: 34,
        fontSize: 14,
        color: "#111111",
        paddingVertical: 0,
    },

    productPrice: {
        fontSize: 14,
        color: "#111111",
        fontWeight: "600",
    },

    productSelectRow: {
        flexDirection: "row",
        justifyContent: "space-between",
        overflow: "visible",
    },

    addProductBtn: {
        width: 42,
        height: 72,
        borderRadius: 4,
        backgroundColor: "#EAF6EC",
        alignItems: "center",
        justifyContent: "center",
        marginLeft: 8,
    },

    priceArea: {
        flexDirection: "row",
        alignItems: "center",
        zIndex: 80,
        overflow: "visible",
    },

    priceRows: {
        flex: 1,
        zIndex: 80,
        overflow: "visible",
    },

    priceRow: {
        minHeight: 39,
        borderBottomWidth: 1,
        borderBottomColor: "#EEEEEE",
        flexDirection: "row",
        alignItems: "center",
        overflow: "visible",
        zIndex: 80,
    },

    priceLabel: {
        width: 170,
        fontSize: 14,
        color: "#111111",
    },

    priceValue: {
        fontSize: 14,
        color: "#111111",
        fontWeight: "600",
    },

    priceInput: {
        flex: 1,
        height: 38,
        fontSize: 14,
        color: "#111111",
        paddingVertical: 0,
    },

    greenSmall: {
        marginLeft: "auto",
        fontSize: 13,
        color: "#4D9858",
    },

    orderCodeInput: {
        flex: 1,
        height: 38,
        fontSize: 14,
        color: "#111111",
        paddingVertical: 0,
    },

    orderImageBox: {
        width: 76,
        height: 76,
        borderRadius: 5,
        backgroundColor: "#F4F4F4",
        alignItems: "center",
        justifyContent: "center",
        marginLeft: 14,
    },

    orderImageText: {
        marginTop: 4,
        color: "#B8B8B8",
        fontSize: 13,
    },

    solutionTitle: {
        marginTop: 30,
        marginBottom: 18,
    },

    checkboxLine: {
        height: 40,
        borderBottomWidth: 1,
        borderBottomColor: "#EEEEEE",
        flexDirection: "row",
        alignItems: "center",
    },

    smallCheckbox: {
        width: 18,
        height: 18,
        borderWidth: 1,
        borderColor: "#DDDDDD",
        borderRadius: 3,
        marginRight: 10,
        alignItems: "center",
        justifyContent: "center",
        backgroundColor: "#FFFFFF",
    },

    smallCheckboxActive: {
        backgroundColor: "#4D9858",
        borderColor: "#4D9858",
    },

    checkboxText: {
        fontSize: 14,
        color: "#111111",
    },

    serviceRow: {
        minHeight: 48,
        borderBottomWidth: 1,
        borderBottomColor: "#EEEEEE",
        flexDirection: "row",
        alignItems: "center",
    },

    serviceTitle: {
        width: 75,
        fontSize: 14,
        color: "#111111",
    },

    serviceDesc: {
        flex: 1,
        fontSize: 13,
        color: "#888888",
    },

    serviceValueWrap: {
        flexDirection: "row",
        alignItems: "center",
        marginLeft: 10,
    },

    serviceValue: {
        fontSize: 13,
        color: "#E53935",
    },

    serviceValueSelected: {
        color: "#111111",
    },

    verifyBox: {
        position: "absolute",
        left: 0,
        right: 0,
        bottom: 0,
        height: 72,
        backgroundColor: "#FFFFFF",
        borderTopWidth: 1,
        borderTopColor: "#EEEEEE",
        alignItems: "center",
        justifyContent: "center",
        zIndex: 30,
    },

    verifyText: {
        fontSize: 20,
        color: "#E45B58",
        fontWeight: "400",
    },

    shopAddressInput: {
        flex: 1,
        height: 42,
        backgroundColor: "#F4F4F4",
        borderRadius: 6,
        paddingHorizontal: 12,
        fontSize: 14,
        color: "#111111",
        borderWidth: 1,
        borderColor: "#E0E0E0",
    },

    postOfficeBox: {
        flex: 1,
        marginLeft: 12,
        backgroundColor: "#F8F8F8",
        borderRadius: 6,
        borderWidth: 1,
        borderColor: "#E6E6E6",
        overflow: "hidden",
    },

    postOfficeLoading: {
        flexDirection: "row",
        alignItems: "center",
        padding: 10,
        gap: 8,
    },

    postOfficeLoadingText: {
        fontSize: 13,
        color: "#666666",
    },

    postOfficeItem: {
        flexDirection: "row",
        alignItems: "flex-start",
        paddingHorizontal: 12,
        paddingVertical: 8,
        borderBottomWidth: 1,
        borderBottomColor: "#F0F0F0",
        gap: 8,
    },

    postOfficeItemSelected: {
        backgroundColor: "#F0FAF1",
    },

    postOfficeName: {
        flex: 1,
        fontSize: 13,
        color: "#333333",
        lineHeight: 18,
    },

    postOfficeNameSelected: {
        color: "#4D9858",
        fontWeight: "600",
    },

    postOfficeRefresh: {
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "center",
        paddingVertical: 7,
        gap: 4,
        borderTopWidth: 1,
        borderTopColor: "#EEEEEE",
    },

    postOfficeRefreshText: {
        fontSize: 12,
        color: "#4D9858",
        fontWeight: "600",
    },

    postOfficeSelected: {
        flexDirection: "row",
        alignItems: "center",
        paddingHorizontal: 12,
        paddingVertical: 10,
        gap: 8,
    },

    postOfficeChangeBtn: {
        marginLeft: "auto" as any,
        fontSize: 12,
        color: "#4D9858",
        fontWeight: "700",
        paddingHorizontal: 8,
        paddingVertical: 2,
        borderWidth: 1,
        borderColor: "#4D9858",
        borderRadius: 4,
    },
});
