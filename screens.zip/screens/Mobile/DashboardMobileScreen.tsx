import React, { useEffect, useState } from "react";
import { View, StyleSheet } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { useNavigation } from "@react-navigation/native";

import {
    getCurrentCustomer,
    logoutCustomer,
} from "../../services/customerApi";

import MobileBottomTabs, {
    MobileDashboardTab,
} from "../../components/Mobile/Dashboard/MobileBottomTabs";
import MobileOperationTab from "../../components/Mobile/Dashboard/MobileOperationTab";
import MobileAccountTab from "../../components/Mobile/Dashboard/MobileAccountTab";
import MobileChatsTab from "../../components/Mobile/Dashboard/MobileChatsTab";

type CustomerProfile = {
    store_name?: string;
    email?: string;
    phone?: string;
};

function getInitials(name?: string) {
    const cleanName = (name || "").trim();

    if (!cleanName) {
        return "M";
    }

    const words = cleanName.split(/\s+/).filter(Boolean);

    if (words.length >= 2) {
        return `${words[0][0]}${words[1][0]}`.toUpperCase();
    }

    return cleanName.slice(0, 1).toUpperCase();
}

export default function DashboardMobileScreen() {
    const navigation = useNavigation<any>();

    const [activeTab, setActiveTab] =
        useState<MobileDashboardTab>("account");

    const [customer, setCustomer] = useState<CustomerProfile | null>(null);

    useEffect(() => {
        const loadCustomer = async () => {
            try {
                const profile = await getCurrentCustomer();

                if (profile) {
                    setCustomer(profile);
                }
            } catch (error) {
                console.log("Không lấy được thông tin khách hàng:", error);
            }
        };

        loadCustomer();
    }, []);

    const customerName = customer?.store_name || "Mint";
    const customerEmail = customer?.email || "";
    const initials = getInitials(customerName);

    const handleLogout = async () => {
        try {
            await logoutCustomer();
        } catch (error) {
            console.log("Đăng xuất lỗi:", error);
        } finally {
            navigation.reset({
                index: 0,
                routes: [{ name: "Login" }],
            });
        }
    };

    return (
        <SafeAreaView edges={["top"]} style={styles.safeArea}>
            <View style={styles.container}>
                <View style={styles.content}>
                    {activeTab === "chats" && <MobileChatsTab />}

                    {activeTab === "operation" && <MobileOperationTab />}

                    {activeTab === "account" && (
                        <MobileAccountTab
                            name={customerName}
                            email={customerEmail}
                            initials={initials}
                            onLogout={handleLogout}
                        />
                    )}
                </View>

                <MobileBottomTabs
                    activeTab={activeTab}
                    onChangeTab={(tab) => {
                        if (tab === "account") {
                            navigation.navigate("Profile");
                        } else {
                            setActiveTab(tab);
                        }
                    }}
                />
            </View>
        </SafeAreaView>
    );
}

const styles = StyleSheet.create({
    safeArea: {
        flex: 1,
        backgroundColor: "#F4F4F4",
    },

    container: {
        flex: 1,
        backgroundColor: "#F4F4F4",
    },

    content: {
        flex: 1,
    },
});