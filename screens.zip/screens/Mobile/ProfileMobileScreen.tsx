import React, { useEffect, useState } from "react";
import {
    View,
    Text,
    StyleSheet,
    ScrollView,
    TouchableOpacity,
    ActivityIndicator,
    Alert,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { useNavigation } from "@react-navigation/native";
import { MaterialCommunityIcons } from "@expo/vector-icons";

import {
    getProfile,
    logoutCustomer,
    CustomerProfile,
} from "../../services/customerApi";

import MobileBottomTabs, {
    MobileDashboardTab,
} from "../../components/Mobile/Dashboard/MobileBottomTabs";
import ProfileCard from "../../components/Mobile/Profile/ProfileCard";
import ProfileEditForm from "../../components/Mobile/Profile/ProfileEditForm";

export default function ProfileMobileScreen() {
    const navigation = useNavigation<any>();

    const [profile, setProfile]     = useState<CustomerProfile | null>(null);
    const [loading, setLoading]     = useState(true);
    const [isEditing, setIsEditing] = useState(false);
    const [activeTab, setActiveTab] = useState<MobileDashboardTab>("account");

    useEffect(() => {
        loadProfile();
    }, []);

    const loadProfile = async () => {
        setLoading(true);
        try {
            const data = await getProfile();
            if (!data) {
                navigation.replace("Login");
                return;
            }
            setProfile(data);
        } catch {
            navigation.replace("Login");
        } finally {
            setLoading(false);
        }
    };

    const handleLogout = () => {
        Alert.alert("Đăng xuất", "Bạn có chắc muốn đăng xuất không?", [
            { text: "Hủy", style: "cancel" },
            {
                text: "Đăng xuất",
                style: "destructive",
                onPress: async () => {
                    await logoutCustomer();
                    navigation.replace("Home");
                },
            },
        ]);
    };

    const handleTabChange = (tab: MobileDashboardTab) => {
        setActiveTab(tab);
        if (tab === "operation") navigation.navigate("Dashboard");
        if (tab === "chats")     navigation.navigate("Feature", { title: "Chats" });
    };

    return (
        <SafeAreaView style={styles.safeArea} edges={["top", "left", "right"]}>
            {/* Header */}
            <View style={styles.header}>
                <TouchableOpacity
                    onPress={() => navigation.goBack()}
                    style={styles.backBtn}
                    activeOpacity={0.7}
                >
                    <MaterialCommunityIcons name="arrow-left" size={22} color="#111111" />
                </TouchableOpacity>
                <Text style={styles.headerTitle}>
                    {isEditing ? "Chỉnh sửa tài khoản" : "Tài khoản"}
                </Text>
                {!isEditing && (
                    <TouchableOpacity
                        onPress={() => setIsEditing(true)}
                        style={styles.editBtn}
                        activeOpacity={0.7}
                    >
                        <MaterialCommunityIcons name="pencil-outline" size={20} color="#4E9858" />
                    </TouchableOpacity>
                )}
                {isEditing && <View style={styles.editBtn} />}
            </View>

            {/* Body */}
            {loading ? (
                <View style={styles.loadingBox}>
                    <ActivityIndicator size="large" color="#4E9858" />
                    <Text style={styles.loadingText}>Đang tải...</Text>
                </View>
            ) : profile ? (
                <ScrollView
                    style={styles.scroll}
                    contentContainerStyle={styles.scrollContent}
                    showsVerticalScrollIndicator={false}
                    keyboardShouldPersistTaps="handled"
                >
                    {/* Card thông tin */}
                    {!isEditing && <ProfileCard profile={profile} />}

                    {/* Form chỉnh sửa */}
                    {isEditing && (
                        <ProfileEditForm
                            profile={profile}
                            onUpdated={(updated) => {
                                setProfile(updated);
                                setIsEditing(false);
                            }}
                            onCancel={() => setIsEditing(false)}
                        />
                    )}

                    {/* Nút đăng xuất (chỉ hiện khi không edit) */}
                    {!isEditing && (
                        <TouchableOpacity
                            style={styles.logoutBtn}
                            onPress={handleLogout}
                            activeOpacity={0.8}
                        >
                            <MaterialCommunityIcons
                                name="logout-variant"
                                size={20}
                                color="#E53935"
                            />
                            <Text style={styles.logoutText}>Đăng xuất</Text>
                        </TouchableOpacity>
                    )}
                </ScrollView>
            ) : null}

            {/* Bottom Tabs */}
            <MobileBottomTabs activeTab={activeTab} onChangeTab={handleTabChange} />
        </SafeAreaView>
    );
}

const styles = StyleSheet.create({
    safeArea: {
        flex: 1,
        backgroundColor: "#F5F5F5",
    },
    header: {
        height: 56,
        backgroundColor: "#FFFFFF",
        flexDirection: "row",
        alignItems: "center",
        paddingHorizontal: 16,
        borderBottomWidth: 1,
        borderBottomColor: "#EEEEEE",
    },
    backBtn: {
        width: 36,
        height: 36,
        justifyContent: "center",
        alignItems: "center",
    },
    headerTitle: {
        flex: 1,
        textAlign: "center",
        fontSize: 16,
        fontWeight: "700",
        color: "#111111",
    },
    editBtn: {
        width: 36,
        height: 36,
        justifyContent: "center",
        alignItems: "center",
    },
    loadingBox: {
        flex: 1,
        justifyContent: "center",
        alignItems: "center",
        gap: 10,
    },
    loadingText: {
        color: "#888888",
        fontSize: 14,
    },
    scroll: {
        flex: 1,
    },
    scrollContent: {
        paddingTop: 16,
        paddingBottom: 32,
    },
    logoutBtn: {
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "center",
        gap: 8,
        marginHorizontal: 16,
        marginTop: 20,
        paddingVertical: 14,
        borderRadius: 12,
        borderWidth: 1.5,
        borderColor: "#FFCDD2",
        backgroundColor: "#FFF5F5",
    },
    logoutText: {
        fontSize: 15,
        fontWeight: "600",
        color: "#E53935",
    },
});
