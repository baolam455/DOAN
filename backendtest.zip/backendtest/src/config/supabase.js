const { createClient } = require('@supabase/supabase-js');
require('dotenv').config();

// Sử dụng Service Role Key để có quyền Admin can thiệp vào table Profiles
const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
);

module.exports = supabase;

// NHIỆM VỤ KHỞI TẠO DATABASE VÀ KẾT NỐI DATABASE VỚI DỰ ÁN 
// CHỨC NĂNG: XUẤT ĐỐI TƯỢNG TỪ DATABASE CỦA SUPABASE ĐỂ CÁC FILE KHÁC CÓ THỂ TƯƠNG TÁC 
