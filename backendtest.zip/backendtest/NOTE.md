# 📌 Tổng quan hệ thống Backend

## 1. Cấu trúc & Chức năng File

Hệ thống chia thành 3 lớp chính:
- **Cấu hình**
- **Xử lý (Controllers)**
- **Điều hướng (Routes)**

### 🔧 Cấu hình
| File | Chức năng |
|------|----------|
| `server.js` | Điểm khởi chạy app, kết nối Routes & Middleware |
| `supabase.js` | Kết nối Supabase (Service Role - quyền Admin) |

### ⚙️ Controllers
| File | Chức năng |
|------|----------|
| `authController.js` | Đăng ký, đăng nhập|
| `aminController.js` | Xem danh sach user, phan quyen|
| `profileController.js` | Xem / sửa / xóa thông tin user |

### 🌐 Routes
| File | Chức năng |
|------|----------|
| `authRoutes.js` | API public (login/register) |
| `userRoutes.js` | API cho user đã login |
| `adminRoutes.js` | API riêng cho admin |

### 🧩 Tiện ích
| File | Chức năng |
|------|----------|
| `authMiddleware.js` | Verify token + check role |
| `tokenHelper.js` | Tạo JWT (id + role) + Refresh Token  |

---

## 2. Luồng xử lý chính (Workflow)

### 🔐 A. Đăng ký & Đăng nhập

#### ➤ Đăng ký

Client → authRoutes → authController
→ Tạo user trong Supabase Auth
→ Tạo profile trong DB
→ Trả kết quả


#### ➤ Đăng nhập

Client → authRoutes → authController
→ Xác thực email/password
→ Lấy role từ Profile
→ Tạo JWT (tokenHelper)
→ Trả AccessToken


---

### 🛡️ B. Bảo mật & Phân quyền

- Client gọi API → `verifyToken` (middleware)
- Decode JWT → lấy `id` + `role`
- Nếu API yêu cầu admin:
  - `authorize(['admin'])`
  - Sai role → ❌ 403 Forbidden

---

## 3. Danh sách API (Test Postman)

### 🌍 Public (Không cần token)

| Method | API | Mô tả |
|--------|-----|------|
| POST | `/api/auth/register` | Đăng ký (mặc định role: customer) |
| POST | `/api/auth/login` | Đăng nhập, lấy access token và refresh token |
| POST | `/api/auth/refresh` | Dùng refresh token để cấp lại access token và refresh token mới  |


---

### 👤 User (Cần token)

| Method | API | Mô tả |
|--------|-----|------|
| GET | `/api/users/me` | Xem profile |
| PUT | `/api/users/me` | Cập nhật info (không sửa role) |
| DELETE | `/api/users/me` | Xóa tài khoản |

---

### 👑 Admin (Chỉ admin)

| Method | API | Mô tả |
|--------|-----|------|
| GET | `/api/admin/all-users` | Lấy tất cả user |
| POST | `/api/admin/set-role` | Đổi role (admin/shipper/customer) |

---

## 📎 Ghi chú thêm

- JWT chứa: `id`, `role`
- Token dùng cho mọi request protected
- Middleware là lớp bảo vệ chính
  src/
├── config/         # Cấu hình Supabase, Env
├── controllers/    # Điều hướng: Nhận input, gọi Service, trả output
├── services/       # LOGIC CHÍNH: Tính toán, xử lý nghiệp vụ (Chỗ này quan trọng nhất)
├── models/         # Tương tác Database: Nơi chứa các hàm lấy/ghi dữ liệu
├── middlewares/    # Bảo mật: Kiểm tra Token, phân quyền
├── routes/         # Định nghĩa các đường dẫn API
├── utils/          # Công cụ hỗ trợ: Tạo token, format ngày tháng
└── validation/     # Kiểm tra dữ liệu đầu vào (Dùng Joi hoặc Zod)

Tóm tắt luồng xử lý (Flow)
. Request (Khách hàng): App React Native của bạn gửi một yêu cầu (ví dụ: Đăng ký tài khoản).

. Route (Cửa tiếp tân): Nhận yêu cầu và chỉ định các "trạm kiểm soát" phải đi qua.

. Validation Middleware (Trạm kiểm tra chất lượng):

Sử dụng Schema (Bộ luật) từ file authValidator.js.

Kiểm tra: Email có hợp lệ không? Mật khẩu có đủ 6 ký tự không?

Kết quả: Nếu sai -> Đuổi về ngay (400 Bad Request). Nếu đúng -> Cho đi tiếp.

. Auth Middleware (Trạm bảo vệ - Nếu cần):

Kiểm tra Token xem người dùng là ai, có quyền Admin không.

. Controller (Quản lý phân xưởng):

Nhận dữ liệu đã được làm sạch từ trạm kiểm tra.

Gọi hàm tương ứng trong Service. (Controller không tự làm, chỉ ra lệnh).

. Service (Kỹ sư trưởng):

Thực hiện logic nghiệp vụ: Mã hóa mật khẩu, kiểm tra xem email đã tồn tại chưa, tính toán logic...

Khi cần lấy hoặc lưu dữ liệu, Service sẽ gọi Model.

. Model (Công nhân kho):

Là lớp duy nhất biết cách nói chuyện với Supabase.

Thực hiện lệnh: INSERT, SELECT, UPDATE, DELETE. Trả kết quả lại cho Service.

Phản hồi (Response): Service báo cáo kết quả cho Controller -> Controller đóng gói thành JSON và gửi trả về cho App.