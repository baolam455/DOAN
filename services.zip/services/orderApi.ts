import { supabase } from "../config/supabase";

export type OrderStatus =
    | "pending"
    | "picked_up"
    | "in_transit"
    | "delivering"
    | "delivered"
    | "returned"
    | "cancelled";

export type Order = {
    id: string;
    customer_id: string;
    order_code: string;
    shop_order_code: string | null;
    status: OrderStatus;
    receiver_phone: string;
    receiver_name: string;
    receiver_address: string;
    receiver_ward: string | null;
    receiver_province: string | null;
    shipping_type: "express" | "bbs";
    transport_type: "road" | "air";
    pickup_method: "home" | "post";
    ship_payer: "customer" | "shop";
    cod_amount: number;
    product_value: number;
    shipping_fee: number;
    total_weight: number;
    product_name: string | null;
    quantity: number;
    notes: string | null;
    created_at: string;
    updated_at: string;
    pickup_at: string | null;
    delivered_at: string | null;
};

export type OrderTracking = {
    id: string;
    order_id: string;
    status: string;
    note: string | null;
    location: string | null;
    created_at: string;
};

export type DashboardStats = {
    total: number;
    delivered: number;
    delivering: number;
    returned: number;
    totalCod: number;
    totalShippingFee: number;
    totalQuantity: number;
    deliveredQuantity: number;
    deliveringQuantity: number;
};

export type CreateOrderInput = {
    receiverPhone: string;
    receiverName: string;
    receiverAddress: string;
    receiverWard?: string;
    receiverProvince?: string;
    shippingType: "express" | "bbs";
    transportType: "road" | "air";
    pickupMethod: "home" | "post";
    shipPayer: "customer" | "shop";
    codAmount: number;
    productValue: number;
    totalWeight: number;
    productName: string;
    quantity: number;
    shopOrderCode?: string;
};

export function statusLabel(status: string): string {
    switch (status) {
        case "pending": return "Chờ lấy hàng";
        case "picked_up": return "Đã lấy hàng";
        case "in_transit": return "Đang vận chuyển";
        case "delivering": return "Đang giao hàng";
        case "delivered": return "Giao thành công";
        case "returned": return "Hoàn hàng";
        case "cancelled": return "Đã hủy";
        default: return status;
    }
}

export function statusColor(status: string): string {
    switch (status) {
        case "pending": return "#F59E0B";
        case "picked_up": return "#3B82F6";
        case "in_transit": return "#8B5CF6";
        case "delivering": return "#F97316";
        case "delivered": return "#4D9858";
        case "returned": return "#EF4444";
        case "cancelled": return "#9CA3AF";
        default: return "#666666";
    }
}

export function statusIcon(status: string): string {
    switch (status) {
        case "pending": return "package-variant-closed";
        case "picked_up": return "truck-check-outline";
        case "in_transit": return "truck-fast-outline";
        case "delivering": return "truck-delivery-outline";
        case "delivered": return "check-circle-outline";
        case "returned": return "arrow-u-left-top";
        case "cancelled": return "close-circle-outline";
        default: return "circle-outline";
    }
}

function generateOrderCode(): string {
    const now = new Date();
    const ymd = `${now.getFullYear()}${String(now.getMonth() + 1).padStart(2, "0")}${String(now.getDate()).padStart(2, "0")}`;
    const rand = Math.random().toString(36).substring(2, 7).toUpperCase();
    return `TK${ymd}${rand}`;
}

export async function createOrder(input: CreateOrderInput): Promise<Order> {
    const { data: userData } = await supabase.auth.getUser();
    const customerId = userData.user?.id;
    if (!customerId) throw new Error("Chưa đăng nhập");

    const orderCode = generateOrderCode();

    const { data, error } = await supabase
        .from("orders")
        .insert({
            customer_id: customerId,
            order_code: orderCode,
            shop_order_code: input.shopOrderCode || null,
            status: "pending",
            receiver_phone: input.receiverPhone,
            receiver_name: input.receiverName,
            receiver_address: input.receiverAddress,
            receiver_ward: input.receiverWard || null,
            receiver_province: input.receiverProvince || null,
            shipping_type: input.shippingType,
            transport_type: input.transportType,
            pickup_method: input.pickupMethod,
            ship_payer: input.shipPayer,
            cod_amount: input.codAmount,
            product_value: input.productValue,
            shipping_fee: 0,
            total_weight: input.totalWeight,
            product_name: input.productName || null,
            quantity: input.quantity,
        })
        .select()
        .single();

    if (error) throw new Error(error.message);

    await supabase.from("order_tracking").insert({
        order_id: data.id,
        status: "pending",
        note: "Đơn hàng đã được tạo thành công",
        location: "Hệ thống",
    });

    return data as Order;
}

export async function getOrders(filters?: {
    status?: OrderStatus;
    dateFrom?: string;
    dateTo?: string;
}): Promise<Order[]> {
    const { data: userData } = await supabase.auth.getUser();
    const customerId = userData.user?.id;
    if (!customerId) throw new Error("Chưa đăng nhập");

    let query = supabase
        .from("orders")
        .select("*")
        .eq("customer_id", customerId)
        .order("created_at", { ascending: false });

    if (filters?.status) {
        query = query.eq("status", filters.status);
    }
    if (filters?.dateFrom) {
        query = query.gte("created_at", filters.dateFrom);
    }
    if (filters?.dateTo) {
        query = query.lte("created_at", filters.dateTo);
    }

    const { data, error } = await query;
    if (error) throw new Error(error.message);
    return (data || []) as Order[];
}

export async function getOrderById(orderId: string): Promise<Order> {
    const { data, error } = await supabase
        .from("orders")
        .select("*")
        .eq("id", orderId)
        .single();

    if (error) throw new Error(error.message);
    return data as Order;
}

export async function getOrderTracking(orderId: string): Promise<OrderTracking[]> {
    const { data, error } = await supabase
        .from("order_tracking")
        .select("*")
        .eq("order_id", orderId)
        .order("created_at", { ascending: true });

    if (error) throw new Error(error.message);
    return (data || []) as OrderTracking[];
}

export async function getDashboardStats(
    dateFrom?: string,
    dateTo?: string
): Promise<DashboardStats> {
    const { data: userData } = await supabase.auth.getUser();
    const customerId = userData.user?.id;
    if (!customerId) throw new Error("Chưa đăng nhập");

    let query = supabase
        .from("orders")
        .select("status, cod_amount, shipping_fee, quantity")
        .eq("customer_id", customerId);

    if (dateFrom) query = query.gte("created_at", dateFrom);
    if (dateTo) query = query.lte("created_at", dateTo);

    const { data, error } = await query;
    if (error) throw new Error(error.message);

    const orders = data || [];
    const deliveringStatuses = ["picked_up", "in_transit", "delivering"];

    const delivered = orders.filter((o) => o.status === "delivered");
    const delivering = orders.filter((o) => deliveringStatuses.includes(o.status));

    return {
        total: orders.length,
        delivered: delivered.length,
        delivering: delivering.length,
        returned: orders.filter((o) => o.status === "returned").length,
        totalCod: delivered.reduce((sum, o) => sum + (o.cod_amount || 0), 0),
        totalShippingFee: orders.reduce((sum, o) => sum + (o.shipping_fee || 0), 0),
        totalQuantity: orders.reduce((sum, o) => sum + (o.quantity || 0), 0),
        deliveredQuantity: delivered.reduce((sum, o) => sum + (o.quantity || 0), 0),
        deliveringQuantity: delivering.reduce((sum, o) => sum + (o.quantity || 0), 0),
    };
}

export async function cancelOrder(orderId: string): Promise<boolean> {
    const { error } = await supabase
        .from("orders")
        .update({ status: "cancelled", updated_at: new Date().toISOString() })
        .eq("id", orderId);

    if (error) throw new Error(error.message);

    await supabase.from("order_tracking").insert({
        order_id: orderId,
        status: "cancelled",
        note: "Đơn hàng đã bị hủy",
        location: "Hệ thống",
    });

    return true;
}
