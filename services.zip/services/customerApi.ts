import AsyncStorage from "@react-native-async-storage/async-storage";
import { supabase } from "../config/supabase";

// ============================================================
// ĐỊA CHỈ BE CỦA BẠN
// Nếu test trên thiết bị thật (không phải emulator/web),
// đổi thành IP máy tính chạy BE, ví dụ: "http://192.168.1.10:3000"
// ============================================================
const BASE_URL = "http://localhost:3000";

// ─── Types ────────────────────────────────────────────────────

type RegisterCustomerInput = {
  storeName: string;
  phone: string;
  email: string;
  address: string;
  password: string;
  rePassword: string;
};

type LoginCustomerInput = {
  account: string;
  password: string;
};

type BusinessRequestInput = {
  fullName: string;
  phone: string;
  email: string;
  company: string;
  taxCode: string;
};

// ─── Token Helpers ────────────────────────────────────────────

async function saveTokens(accessToken: string, refreshToken: string) {
  await AsyncStorage.multiSet([
    ["accessToken", accessToken],
    ["refreshToken", refreshToken],
  ]);
}

export async function getAccessToken(): Promise<string | null> {
  return AsyncStorage.getItem("accessToken");
}

export async function getRefreshToken(): Promise<string | null> {
  return AsyncStorage.getItem("refreshToken");
}

async function clearTokens() {
  await AsyncStorage.multiRemove(["accessToken", "refreshToken"]);
}

// ─── Validators ───────────────────────────────────────────────

function cleanText(value: string) {
  return value.trim();
}

function cleanEmail(value: string) {
  return value.trim().toLowerCase();
}

function cleanPhone(value: string) {
  return value.trim().replace(/\D/g, "");
}

function isValidEmail(email: string) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

function isStrongPassword(password: string) {
  return /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[^A-Za-z0-9]).{6,}$/.test(password);
}

function getErrorMessage(error: unknown) {
  if (error instanceof Error) return error.message;
  return "Có lỗi xảy ra, vui lòng thử lại";
}

// ─── Refresh Token ────────────────────────────────────────────

export async function refreshAccessToken(): Promise<string | null> {
  const refreshToken = await getRefreshToken();
  if (!refreshToken) return null;

  try {
    const res = await fetch(`${BASE_URL}/api/auth/refresh`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ refreshToken }),
    });

    if (!res.ok) return null;

    const data = await res.json();
    await saveTokens(data.accessToken, data.refreshToken);
    return data.accessToken;
  } catch {
    return null;
  }
}

// ─── Register ─────────────────────────────────────────────────

export async function registerCustomer(input: RegisterCustomerInput) {
  const storeName = cleanText(input.storeName);
  const phone = cleanPhone(input.phone);
  const email = cleanEmail(input.email);
  const address = cleanText(input.address);
  const { password, rePassword } = input;

  if (!storeName || !phone || !email || !address || !password || !rePassword) {
    throw new Error("Vui lòng nhập đầy đủ thông tin");
  }
  if (!/^\d{10}$/.test(phone)) {
    throw new Error("Số điện thoại phải đủ 10 số");
  }
  if (!isValidEmail(email)) {
    throw new Error("Email không hợp lệ");
  }
  if (!isStrongPassword(password)) {
    throw new Error("Mật khẩu phải có chữ hoa, chữ thường, số và ký tự đặc biệt");
  }
  if (password !== rePassword) {
    throw new Error("Mật khẩu xác nhận không khớp");
  }

  // 1. Đăng ký qua BE của bạn (friend's backend)
  const res = await fetch(`${BASE_URL}/api/auth/register`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      email,
      password,
      full_name: storeName,
      phone,
      address,
    }),
  });

  const data = await res.json();
  if (!res.ok) throw new Error(data.error || "Đăng ký thất bại");

  // 2. Cũng tạo tài khoản trên Supabase (của mình) để quản lý đơn hàng (RLS)
  const { data: signUpData, error: signUpError } = await supabase.auth.signUp({
    email,
    password,
  });

  if (!signUpError && signUpData.user) {
    await supabase.from("customer_profiles").insert({
      id: signUpData.user.id,
      store_name: storeName,
      phone,
      email,
      address,
    });
  }

  return { message: data.message || "Đăng ký thành công" };
}

// ─── Login ────────────────────────────────────────────────────

export async function loginCustomer(input: LoginCustomerInput) {
  const account = cleanText(input.account);
  const { password } = input;

  if (!account || !password) {
    throw new Error("Vui lòng nhập tài khoản và mật khẩu");
  }

  let email = cleanEmail(account);

  // Nếu nhập số điện thoại → tìm email trong Supabase của mình
  if (!account.includes("@")) {
    const phone = cleanPhone(account);

    if (!/^\d{10}$/.test(phone)) {
      throw new Error("Số điện thoại phải đủ 10 số hoặc nhập email hợp lệ");
    }

    const { data: profile } = await supabase
      .from("customer_profiles")
      .select("email")
      .eq("phone", phone)
      .maybeSingle();

    if (!profile?.email) {
      throw new Error("Không tìm thấy tài khoản với số điện thoại này");
    }

    email = profile.email;
  }

  // 1. Đăng nhập qua BE của bạn → lấy JWT tokens
  const res = await fetch(`${BASE_URL}/api/auth/login`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ email, password }),
  });

  const data = await res.json();
  if (!res.ok) throw new Error(data.error || "Sai tài khoản hoặc mật khẩu");

  // 2. Lưu JWT tokens vào AsyncStorage
  await saveTokens(data.accessToken, data.refreshToken);

  // 3. Cũng đăng nhập vào Supabase của mình để quản lý đơn hàng (RLS)
  await supabase.auth.signInWithPassword({ email, password });

  return {
    accessToken: data.accessToken,
    refreshToken: data.refreshToken,
    role: data.role,
    message: "Đăng nhập thành công",
  };
}

// ─── Get Current User ─────────────────────────────────────────

export async function getCurrentCustomer() {
  const token = await getAccessToken();
  if (!token) return null;

  try {
    const res = await fetch(`${BASE_URL}/api/users/me`, {
      headers: { Authorization: `Bearer ${token}` },
    });

    if (!res.ok) return null;
    return res.json();
  } catch {
    return null;
  }
}

// ─── Logout ───────────────────────────────────────────────────

export async function logoutCustomer() {
  await clearTokens();
  await supabase.auth.signOut();
  return true;
}

// ─── Business Request (vẫn dùng Supabase của mình) ───────────

export async function registerBusinessRequest(input: BusinessRequestInput) {
  const fullName = cleanText(input.fullName);
  const phone = cleanPhone(input.phone);
  const email = cleanEmail(input.email);
  const company = cleanText(input.company);
  const taxCode = cleanText(input.taxCode);

  if (!fullName || !phone || !email || !company || !taxCode) {
    throw new Error("Vui lòng nhập đầy đủ thông tin doanh nghiệp");
  }
  if (!/^\d{10}$/.test(phone)) {
    throw new Error("Số điện thoại phải đủ 10 số");
  }
  if (!isValidEmail(email)) {
    throw new Error("Email không hợp lệ");
  }

  const { data, error } = await supabase
    .from("business_requests")
    .insert({
      full_name: fullName,
      phone,
      email,
      company,
      tax_code: taxCode,
    })
    .select()
    .single();

  if (error) throw new Error(error.message);

  return { data, message: "Gửi thông tin doanh nghiệp thành công" };
}

// ─── Get Profile ──────────────────────────────────────────────

export type CustomerProfile = {
  id: string;
  full_name: string;
  phone: string;
  address: string;
  role: string;
  created_at: string;
};

export async function getProfile(): Promise<CustomerProfile | null> {
  const token = await getAccessToken();
  if (!token) return null;

  try {
    const res = await fetch(`${BASE_URL}/api/users/me`, {
      headers: { Authorization: `Bearer ${token}` },
    });
    if (!res.ok) return null;
    return res.json();
  } catch {
    return null;
  }
}

// ─── Update Profile ───────────────────────────────────────────

type UpdateProfileInput = {
  full_name?: string;
  phone?: string;
  address?: string;
};

export async function updateProfile(input: UpdateProfileInput): Promise<CustomerProfile> {
  const token = await getAccessToken();
  if (!token) throw new Error("Chưa đăng nhập");

  const full_name = input.full_name ? cleanText(input.full_name) : undefined;
  const phone     = input.phone     ? cleanPhone(input.phone)    : undefined;
  const address   = input.address   ? cleanText(input.address)   : undefined;

  if (phone && !/^\d{10}$/.test(phone)) {
    throw new Error("Số điện thoại phải đủ 10 số");
  }
  if (full_name !== undefined && full_name.length < 3) {
    throw new Error("Họ tên phải có ít nhất 3 ký tự");
  }

  const body: UpdateProfileInput = {};
  if (full_name !== undefined) body.full_name = full_name;
  if (phone     !== undefined) body.phone     = phone;
  if (address   !== undefined) body.address   = address;

  const res = await fetch(`${BASE_URL}/api/users/me`, {
    method: "PUT",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${token}`,
    },
    body: JSON.stringify(body),
  });

  const data = await res.json();
  if (!res.ok) throw new Error(data.error || "Cập nhật thất bại");
  return data.data;
}

export { getErrorMessage };