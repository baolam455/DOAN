-- ============================================================
-- LOOGISTIC — SUPABASE FRESH RESET SCRIPT
-- Chạy toàn bộ file này trong Supabase SQL Editor để reset DB.
-- Sau khi chạy xong, đăng ký tài khoản trên app rồi chạy thêm:
--   UPDATE public.profiles SET role = 'admin' WHERE email = 'YOUR_ADMIN_EMAIL';
-- ============================================================

-- ── 1. Xóa trigger cũ ──────────────────────────────────────
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;

-- ── 2. Xóa bảng cũ trước để policy phụ thuộc bị xoá theo bảng ─
DROP TABLE IF EXISTS public.order_tracking CASCADE;
DROP TABLE IF EXISTS public.orders CASCADE;
DROP TABLE IF EXISTS public.customer_profiles CASCADE;
DROP TABLE IF EXISTS public.business_requests CASCADE;
DROP TABLE IF EXISTS public.post_offices CASCADE;
DROP TABLE IF EXISTS public.shipping_fee_rules CASCADE;
DROP TABLE IF EXISTS public.profiles CASCADE;

-- ── 3. Xóa function cũ sau khi bảng/policy đã mất ───────────
DROP FUNCTION IF EXISTS public.handle_new_auth_user() CASCADE;
DROP FUNCTION IF EXISTS public.current_user_role() CASCADE;

-- ── 4. Extension ──────────────────────────────────────────────
CREATE EXTENSION IF NOT EXISTS pgcrypto;

-- ── 5. Tạo bảng ──────────────────────────────────────────────

CREATE TABLE public.profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name TEXT NOT NULL,
  email TEXT UNIQUE NOT NULL,
  phone TEXT UNIQUE,
  role TEXT NOT NULL DEFAULT 'customer' CHECK (
    role IN ('admin', 'dispatcher', 'warehouse', 'shipper', 'customer')
  ),
  status TEXT NOT NULL DEFAULT 'active' CHECK (
    status IN ('active', 'locked_short', 'locked_long', 'disabled')
  ),
  locked_until TIMESTAMPTZ,
  lock_reason TEXT,
  warehouse_name TEXT,
  total_orders INTEGER NOT NULL DEFAULT 0,
  success_rate NUMERIC NOT NULL DEFAULT 0,
  last_active_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE public.customer_profiles (
  id UUID PRIMARY KEY REFERENCES public.profiles(id) ON DELETE CASCADE,
  store_name TEXT NOT NULL,
  phone TEXT UNIQUE NOT NULL,
  email TEXT UNIQUE NOT NULL,
  address TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE public.business_requests (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  full_name TEXT NOT NULL,
  phone TEXT NOT NULL,
  email TEXT NOT NULL,
  company TEXT NOT NULL,
  tax_code TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'rejected')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE public.orders (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_id UUID NOT NULL REFERENCES public.customer_profiles(id) ON DELETE CASCADE,
  order_code TEXT UNIQUE NOT NULL,
  shop_order_code TEXT,
  status TEXT NOT NULL DEFAULT 'pending' CHECK (
    status IN (
      'pending', 'picked_up', 'in_transit',
      'delivering', 'delivered', 'returned', 'cancelled'
    )
  ),
  receiver_phone TEXT NOT NULL,
  receiver_name TEXT NOT NULL,
  receiver_address TEXT NOT NULL,
  receiver_ward TEXT,
  receiver_province TEXT,
  shipping_type TEXT NOT NULL DEFAULT 'express' CHECK (shipping_type IN ('express', 'bbs')),
  transport_type TEXT NOT NULL DEFAULT 'road' CHECK (transport_type IN ('road', 'air')),
  pickup_method TEXT NOT NULL DEFAULT 'home' CHECK (pickup_method IN ('home', 'post')),
  ship_payer TEXT NOT NULL DEFAULT 'customer' CHECK (ship_payer IN ('customer', 'shop')),
  cod_amount BIGINT NOT NULL DEFAULT 0,
  product_value BIGINT NOT NULL DEFAULT 0,
  shipping_fee BIGINT NOT NULL DEFAULT 0,
  total_weight NUMERIC NOT NULL DEFAULT 0,
  product_name TEXT,
  quantity INTEGER NOT NULL DEFAULT 1,
  assigned_shipper TEXT,
  pickup_address TEXT,     -- địa chỉ lấy hàng (nếu pickup_method = 'home')
  notes TEXT,              -- ghi chú/lưu ý lấy hàng
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  pickup_at TIMESTAMPTZ,
  delivered_at TIMESTAMPTZ
);

CREATE TABLE public.order_tracking (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id UUID NOT NULL REFERENCES public.orders(id) ON DELETE CASCADE,
  status TEXT NOT NULL,
  note TEXT,
  location TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE public.post_offices (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  code TEXT UNIQUE NOT NULL,
  name TEXT NOT NULL,
  province TEXT NOT NULL,
  district TEXT NOT NULL,
  address TEXT NOT NULL,
  lat NUMERIC NOT NULL,
  lng NUMERIC NOT NULL,
  staff_count INTEGER NOT NULL DEFAULT 0,
  active_shipper_count INTEGER NOT NULL DEFAULT 0,
  queue_orders INTEGER NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE public.shipping_fee_rules (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  distance_from_km NUMERIC NOT NULL DEFAULT 0,
  distance_to_km NUMERIC NOT NULL DEFAULT 0,
  weight_from_kg NUMERIC NOT NULL DEFAULT 0,
  weight_to_kg NUMERIC NOT NULL DEFAULT 0,
  base_fee BIGINT NOT NULL DEFAULT 0,
  extra_fee_per_kg BIGINT NOT NULL DEFAULT 0,
  active BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ── 6. Function lấy role hiện tại ────────────────────────────
-- Backend tạo profile bằng Service Role Key.
-- KHÔNG dùng trigger auth.users để tránh lỗi: "Database error creating new user".
CREATE OR REPLACE FUNCTION public.current_user_role()
RETURNS TEXT
LANGUAGE SQL
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT COALESCE(
    (SELECT role FROM public.profiles WHERE id = auth.uid() LIMIT 1),
    'customer'
  );
$$;

-- ── 7. Row Level Security ─────────────────────────────────────
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.customer_profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.business_requests ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.order_tracking ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.post_offices ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.shipping_fee_rules ENABLE ROW LEVEL SECURITY;

-- profiles
DROP POLICY IF EXISTS "profiles_select_own_or_admin" ON public.profiles;
DROP POLICY IF EXISTS "profiles_insert_own_or_admin" ON public.profiles;
DROP POLICY IF EXISTS "profiles_update_admin" ON public.profiles;
CREATE POLICY "profiles_select_own_or_admin" ON public.profiles FOR SELECT
  USING (id = auth.uid() OR public.current_user_role() = 'admin');
CREATE POLICY "profiles_insert_own_or_admin" ON public.profiles FOR INSERT
  WITH CHECK (id = auth.uid() OR public.current_user_role() = 'admin');
CREATE POLICY "profiles_update_admin" ON public.profiles FOR UPDATE
  USING (public.current_user_role() = 'admin')
  WITH CHECK (public.current_user_role() = 'admin');

-- customer_profiles
DROP POLICY IF EXISTS "customer_profiles_select_own_or_admin" ON public.customer_profiles;
DROP POLICY IF EXISTS "customer_profiles_insert_own_or_admin" ON public.customer_profiles;
DROP POLICY IF EXISTS "customer_profiles_update_own_or_admin" ON public.customer_profiles;
CREATE POLICY "customer_profiles_select_own_or_admin" ON public.customer_profiles FOR SELECT
  USING (id = auth.uid() OR public.current_user_role() = 'admin');
CREATE POLICY "customer_profiles_insert_own_or_admin" ON public.customer_profiles FOR INSERT
  WITH CHECK (id = auth.uid() OR public.current_user_role() = 'admin');
CREATE POLICY "customer_profiles_update_own_or_admin" ON public.customer_profiles FOR UPDATE
  USING (id = auth.uid() OR public.current_user_role() = 'admin')
  WITH CHECK (id = auth.uid() OR public.current_user_role() = 'admin');

-- business_requests
DROP POLICY IF EXISTS "business_requests_insert_public" ON public.business_requests;
DROP POLICY IF EXISTS "business_requests_admin_all" ON public.business_requests;
CREATE POLICY "business_requests_insert_public" ON public.business_requests FOR INSERT
  WITH CHECK (TRUE);
CREATE POLICY "business_requests_admin_all" ON public.business_requests FOR ALL
  USING (public.current_user_role() = 'admin')
  WITH CHECK (public.current_user_role() = 'admin');

-- orders
DROP POLICY IF EXISTS "orders_select_own_or_admin" ON public.orders;
DROP POLICY IF EXISTS "orders_insert_own_or_admin" ON public.orders;
DROP POLICY IF EXISTS "orders_update_own_or_admin" ON public.orders;
CREATE POLICY "orders_select_own_or_admin" ON public.orders FOR SELECT
  USING (customer_id = auth.uid() OR public.current_user_role() = 'admin');
CREATE POLICY "orders_insert_own_or_admin" ON public.orders FOR INSERT
  WITH CHECK (customer_id = auth.uid() OR public.current_user_role() = 'admin');
CREATE POLICY "orders_update_own_or_admin" ON public.orders FOR UPDATE
  USING (customer_id = auth.uid() OR public.current_user_role() = 'admin')
  WITH CHECK (customer_id = auth.uid() OR public.current_user_role() = 'admin');

-- order_tracking
DROP POLICY IF EXISTS "tracking_select_own_or_admin" ON public.order_tracking;
DROP POLICY IF EXISTS "tracking_insert_own_or_admin" ON public.order_tracking;
CREATE POLICY "tracking_select_own_or_admin" ON public.order_tracking FOR SELECT
  USING (
    public.current_user_role() = 'admin'
    OR EXISTS (
      SELECT 1 FROM public.orders
      WHERE orders.id = order_tracking.order_id
        AND orders.customer_id = auth.uid()
    )
  );
CREATE POLICY "tracking_insert_own_or_admin" ON public.order_tracking FOR INSERT
  WITH CHECK (
    public.current_user_role() = 'admin'
    OR EXISTS (
      SELECT 1 FROM public.orders
      WHERE orders.id = order_tracking.order_id
        AND orders.customer_id = auth.uid()
    )
  );

-- post_offices
DROP POLICY IF EXISTS "post_offices_read_all" ON public.post_offices;
DROP POLICY IF EXISTS "post_offices_admin_all" ON public.post_offices;
CREATE POLICY "post_offices_read_all" ON public.post_offices FOR SELECT USING (TRUE);
CREATE POLICY "post_offices_admin_all" ON public.post_offices FOR ALL
  USING (public.current_user_role() = 'admin')
  WITH CHECK (public.current_user_role() = 'admin');

-- shipping_fee_rules
DROP POLICY IF EXISTS "shipping_fee_rules_read_all" ON public.shipping_fee_rules;
DROP POLICY IF EXISTS "shipping_fee_rules_admin_all" ON public.shipping_fee_rules;
CREATE POLICY "shipping_fee_rules_read_all" ON public.shipping_fee_rules FOR SELECT USING (TRUE);
CREATE POLICY "shipping_fee_rules_admin_all" ON public.shipping_fee_rules FOR ALL
  USING (public.current_user_role() = 'admin')
  WITH CHECK (public.current_user_role() = 'admin');

-- ── 8. Indexes ────────────────────────────────────────────────
CREATE INDEX IF NOT EXISTS idx_profiles_role ON public.profiles(role);
CREATE INDEX IF NOT EXISTS idx_profiles_status ON public.profiles(status);
CREATE INDEX IF NOT EXISTS idx_orders_customer_id ON public.orders(customer_id);
CREATE INDEX IF NOT EXISTS idx_orders_status ON public.orders(status);
CREATE INDEX IF NOT EXISTS idx_orders_created_at ON public.orders(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_order_tracking_order_id ON public.order_tracking(order_id);
CREATE INDEX IF NOT EXISTS idx_post_offices_province ON public.post_offices(province);
CREATE UNIQUE INDEX IF NOT EXISTS idx_shipping_fee_rules_name ON public.shipping_fee_rules(name);

-- ── 9. Seed: Bảng phí vận chuyển ─────────────────────────────
INSERT INTO public.shipping_fee_rules
  (name, distance_from_km, distance_to_km, weight_from_kg, weight_to_kg, base_fee, extra_fee_per_kg, active)
VALUES
  ('Nội thành nhẹ',            0,   5,  0, 3,  22000, 3000, TRUE),
  ('Nội thành tiêu chuẩn',     5,  15,  0, 10, 30000, 4500, TRUE),
  ('Liên quận / ngoại thành', 15,  40,  0, 20, 42000, 5500, TRUE),
  ('Liên tỉnh',               40, 500,  0, 50, 65000, 8500, TRUE)
ON CONFLICT (name) DO UPDATE SET
  distance_from_km  = EXCLUDED.distance_from_km,
  distance_to_km    = EXCLUDED.distance_to_km,
  weight_from_kg    = EXCLUDED.weight_from_kg,
  weight_to_kg      = EXCLUDED.weight_to_kg,
  base_fee          = EXCLUDED.base_fee,
  extra_fee_per_kg  = EXCLUDED.extra_fee_per_kg,
  active            = EXCLUDED.active;

-- ── 10. Seed: Bưu cục ─────────────────────────────────────────
INSERT INTO public.post_offices
  (code, name, province, district, address, lat, lng, staff_count, active_shipper_count, queue_orders)
VALUES
  ('BC001', 'Bưu cục Quận 1',           'TP.HCM', 'Quận 1',     '12 Nguyễn Huệ, Quận 1',              10.7757, 106.7004, 22, 14, 38),
  ('BC002', 'Bưu cục Quận 3',           'TP.HCM', 'Quận 3',     '189 Cách Mạng Tháng 8, Quận 3',      10.7842, 106.6844, 18, 11, 31),
  ('BC003', 'Bưu cục Bình Thạnh',       'TP.HCM', 'Bình Thạnh', '42 Điện Biên Phủ, Bình Thạnh',       10.8033, 106.6962, 20, 12, 44),
  ('BC004', 'Bưu cục Thủ Đức',          'TP.HCM', 'Thủ Đức',    '19 Võ Văn Ngân, Thủ Đức',            10.8497, 106.7717, 21, 15, 29),
  ('BC005', 'Bưu cục Quận 7',           'TP.HCM', 'Quận 7',     '88 Nguyễn Thị Thập, Quận 7',         10.7397, 106.7019, 24, 17, 52),
  ('BC006', 'Bưu cục Tân Bình',         'TP.HCM', 'Tân Bình',   '2 Trường Sơn, Tân Bình',             10.8131, 106.6621, 19, 13, 34),
  ('BC007', 'Bưu cục Gò Vấp',           'TP.HCM', 'Gò Vấp',     '31 Quang Trung, Gò Vấp',             10.8389, 106.6653, 18, 12, 40),
  ('BC008', 'Bưu cục Quận 10',          'TP.HCM', 'Quận 10',    '155 Sư Vạn Hạnh, Quận 10',           10.7724, 106.6678, 17, 10, 26),
  ('BC009', 'Bưu cục Cầu Giấy',         'Hà Nội', 'Cầu Giấy',   '36 Xuân Thủy, Cầu Giấy',             21.0362, 105.7829, 23, 14, 46),
  ('BC010', 'Bưu cục Hoàn Kiếm',        'Hà Nội', 'Hoàn Kiếm',  '14 Tràng Tiền, Hoàn Kiếm',           21.0245, 105.8538, 20, 12, 35),
  ('BC011', 'Bưu cục Đống Đa',          'Hà Nội', 'Đống Đa',    '91 Chùa Bộc, Đống Đa',               21.0089, 105.8288, 18, 10, 33),
  ('BC012', 'Bưu cục Hà Đông',          'Hà Nội', 'Hà Đông',    '25 Quang Trung, Hà Đông',             20.9712, 105.7784, 17, 10, 24),
  ('BC013', 'Bưu cục Long Biên',        'Hà Nội', 'Long Biên',  '3 Nguyễn Văn Cừ, Long Biên',         21.0481, 105.8807, 16,  9, 28),
  ('BC014', 'Bưu cục Tây Hồ',           'Hà Nội', 'Tây Hồ',     '68 Lạc Long Quân, Tây Hồ',           21.0682, 105.8194, 15,  8, 21),
  ('BC015', 'Bưu cục Hải Châu',         'Đà Nẵng','Hải Châu',   '39 Nguyễn Văn Linh, Hải Châu',       16.0605, 108.2230, 19, 12, 37),
  ('BC016', 'Bưu cục Sơn Trà',          'Đà Nẵng','Sơn Trà',    '27 Ngô Quyền, Sơn Trà',              16.0819, 108.2458, 15,  9, 20),
  ('BC017', 'Bưu cục Thanh Khê',        'Đà Nẵng','Thanh Khê',  '202 Điện Biên Phủ, Thanh Khê',       16.0664, 108.1937, 16, 10, 25),
  ('BC018', 'Bưu cục Ninh Kiều',        'Cần Thơ','Ninh Kiều',  '7 Hòa Bình, Ninh Kiều',              10.0338, 105.7831, 17, 11, 30),
  ('BC019', 'Bưu cục Cái Răng',         'Cần Thơ','Cái Răng',   '51 Võ Nguyên Giáp, Cái Răng',        10.0002, 105.8050, 14,  8, 18),
  ('BC020', 'Bưu cục Biên Hòa',         'Đồng Nai','Biên Hòa',  '104 Phạm Văn Thuận, Biên Hòa',       10.9574, 106.8426, 20, 13, 36),
  ('BC021', 'Bưu cục Dĩ An',            'Bình Dương','Dĩ An',    '72 Nguyễn An Ninh, Dĩ An',           10.9068, 106.7694, 18, 12, 29),
  ('BC022', 'Bưu cục Thủ Dầu Một',      'Bình Dương','Thủ Dầu Một','16 Đại lộ Bình Dương',             10.9804, 106.6519, 16,  9, 22),
  ('BC023', 'Bưu cục Vũng Tàu',         'Bà Rịa - Vũng Tàu','Vũng Tàu','2 Lê Lợi, Vũng Tàu',         10.3460, 107.0843, 15,  9, 19),
  ('BC024', 'Bưu cục Nha Trang',        'Khánh Hòa','Nha Trang','44 Lê Thánh Tôn, Nha Trang',         12.2388, 109.1967, 18, 11, 27),
  ('BC025', 'Bưu cục Đà Lạt',           'Lâm Đồng','Đà Lạt',    '4 Trần Phú, Đà Lạt',                 11.9404, 108.4583, 14,  8, 16),
  ('BC026', 'Bưu cục Buôn Ma Thuột',    'Đắk Lắk','Buôn Ma Thuột','10 Nguyễn Tất Thành, Buôn Ma Thuột',12.6662,108.0378, 16, 10, 23),
  ('BC027', 'Bưu cục Quy Nhơn',         'Bình Định','Quy Nhơn', '22 Nguyễn Huệ, Quy Nhơn',            13.7820, 109.2190, 15,  8, 18),
  ('BC028', 'Bưu cục Huế',              'Thừa Thiên Huế','Huế', '11 Hùng Vương, Huế',                  16.4637, 107.5909, 17, 10, 24),
  ('BC029', 'Bưu cục Vinh',             'Nghệ An','Vinh',        '5 Lê Lợi, Vinh',                     18.6796, 105.6813, 17, 10, 25),
  ('BC030', 'Bưu cục Thanh Hóa',        'Thanh Hóa','Thanh Hóa','37 Đại lộ Lê Lợi, Thanh Hóa',        19.8075, 105.7764, 16,  9, 21),
  ('BC031', 'Bưu cục Hải Phòng',        'Hải Phòng','Ngô Quyền','55 Lạch Tray, Ngô Quyền',             20.8449, 106.6881, 20, 13, 35),
  ('BC032', 'Bưu cục Hạ Long',          'Quảng Ninh','Hạ Long', '88 Trần Hưng Đạo, Hạ Long',           20.9511, 107.0838, 16,  9, 20),
  ('BC033', 'Bưu cục Bắc Ninh',         'Bắc Ninh','Bắc Ninh',  '12 Lý Thái Tổ, Bắc Ninh',            21.1861, 106.0763, 15,  8, 18),
  ('BC034', 'Bưu cục Thái Nguyên',      'Thái Nguyên','Thái Nguyên','20 Hoàng Văn Thụ, Thái Nguyên',  21.5942, 105.8482, 14,  8, 17),
  ('BC035', 'Bưu cục Việt Trì',         'Phú Thọ','Việt Trì',   '6 Hùng Vương, Việt Trì',              21.3227, 105.4020, 13,  7, 15),
  ('BC036', 'Bưu cục Nam Định',         'Nam Định','Nam Định',   '31 Trần Hưng Đạo, Nam Định',          20.4388, 106.1621, 14,  8, 18),
  ('BC037', 'Bưu cục Ninh Bình',        'Ninh Bình','Ninh Bình', '9 Lê Đại Hành, Ninh Bình',           20.2539, 105.9745, 13,  7, 14),
  ('BC038', 'Bưu cục Pleiku',           'Gia Lai','Pleiku',       '18 Trần Phú, Pleiku',                 13.9833, 108.0000, 14,  8, 17),
  ('BC039', 'Bưu cục Phan Thiết',       'Bình Thuận','Phan Thiết','52 Tôn Đức Thắng, Phan Thiết',       10.9333, 108.1000, 15,  8, 19),
  ('BC040', 'Bưu cục Long Xuyên',       'An Giang','Long Xuyên', '33 Trần Hưng Đạo, Long Xuyên',       10.3864, 105.4352, 15,  9, 22),
  ('BC041', 'Bưu cục Rạch Giá',         'Kiên Giang','Rạch Giá', '45 Nguyễn Trung Trực, Rạch Giá',     10.0125, 105.0809, 14,  8, 18),
  ('BC042', 'Bưu cục Cà Mau',           'Cà Mau','Cà Mau',       '19 Phan Ngọc Hiển, Cà Mau',           9.1769, 105.1524, 13,  7, 15),
  ('BC043', 'Bưu cục Mỹ Tho',           'Tiền Giang','Mỹ Tho',  '7 Ấp Bắc, Mỹ Tho',                   10.3600, 106.3600, 14,  8, 19),
  ('BC044', 'Bưu cục Bến Tre',          'Bến Tre','Bến Tre',     '28 Đồng Khởi, Bến Tre',               10.2433, 106.3756, 13,  7, 16),
  ('BC045', 'Bưu cục Trà Vinh',         'Trà Vinh','Trà Vinh',   '41 Nguyễn Đáng, Trà Vinh',            9.9347, 106.3453, 12,  7, 14),
  ('BC046', 'Bưu cục Sóc Trăng',        'Sóc Trăng','Sóc Trăng', '15 Trần Hưng Đạo, Sóc Trăng',        9.6036, 105.9800, 13,  7, 16),
  ('BC047', 'Bưu cục Bạc Liêu',         'Bạc Liêu','Bạc Liêu',  '23 Trần Phú, Bạc Liêu',               9.2940, 105.7216, 12,  7, 13),
  ('BC048', 'Bưu cục Cao Lãnh',         'Đồng Tháp','Cao Lãnh', '25 Nguyễn Huệ, Cao Lãnh',             10.4602, 105.6329, 13,  7, 15),
  ('BC049', 'Bưu cục Tân An',           'Long An','Tân An',      '6 Hùng Vương, Tân An',                10.5330, 106.4167, 14,  8, 17),
  ('BC050', 'Bưu cục Tây Ninh',         'Tây Ninh','Tây Ninh',   '30 Cách Mạng Tháng 8, Tây Ninh',      11.3100, 106.0983, 13,  7, 14)
ON CONFLICT (code) DO UPDATE SET
  name                 = EXCLUDED.name,
  province             = EXCLUDED.province,
  district             = EXCLUDED.district,
  address              = EXCLUDED.address,
  lat                  = EXCLUDED.lat,
  lng                  = EXCLUDED.lng,
  staff_count          = EXCLUDED.staff_count,
  active_shipper_count = EXCLUDED.active_shipper_count,
  queue_orders         = EXCLUDED.queue_orders;

-- ── 11. Grants cơ bản cho Supabase client ───────────────────
GRANT USAGE ON SCHEMA public TO anon, authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA public TO authenticated;
GRANT SELECT ON public.post_offices TO anon;
GRANT SELECT ON public.shipping_fee_rules TO anon;
GRANT INSERT ON public.business_requests TO anon;

-- ── 12. Cấp quyền Admin (chạy SAU KHI đã đăng ký tài khoản) ──
-- Thay YOUR_ADMIN_EMAIL bằng email bạn vừa đăng ký trên app:
--
-- UPDATE public.profiles
-- SET role = 'admin'
-- WHERE email = 'YOUR_ADMIN_EMAIL';
--
-- Sau đó logout và login lại để token mới được cấp với role admin.
