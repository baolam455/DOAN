import React, { useEffect, useState } from "react";
import {
  Keyboard,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
  StyleSheet,
  View,
  Text,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { useNavigation } from "@react-navigation/native";

import BusinessRegisterTopBar from "../../components/Mobile/BusinessRegister/BusinessRegisterTopBar";
import BusinessRegisterForm from "../../components/Mobile/BusinessRegister/BusinessRegisterForm";

import {
  registerBusinessRequest,
  getErrorMessage,
} from "../../services/customerApi";

export default function BusinessRegisterMobileScreen() {
  const navigation = useNavigation<any>();

  const [fullName, setFullName] = useState("");
  const [phone, setPhone] = useState("");
  const [email, setEmail] = useState("");
  const [company, setCompany] = useState("");
  const [taxCode, setTaxCode] = useState("");
  const [agree, setAgree] = useState(false);

  const [loading, setLoading] = useState(false);

  const [notice, setNotice] = useState({
    visible: false,
    type: "success" as "success" | "error",
    title: "",
    message: "",
  });

  const [keyboardVisible, setKeyboardVisible] = useState(false);

  useEffect(() => {
    const showSub = Keyboard.addListener("keyboardDidShow", () => {
      setKeyboardVisible(true);
    });

    const hideSub = Keyboard.addListener("keyboardDidHide", () => {
      setKeyboardVisible(false);
    });

    return () => {
      showSub.remove();
      hideSub.remove();
    };
  }, []);

  const handleBack = () => {
    if (navigation.canGoBack()) {
      navigation.goBack();
    } else {
      navigation.navigate("Home");
    }
  };

  const showNotice = (
    type: "success" | "error",
    title: string,
    message: string
  ) => {
    setNotice({
      visible: true,
      type,
      title,
      message,
    });
  };

  const closeNotice = () => {
    setNotice((prev) => ({
      ...prev,
      visible: false,
    }));
  };

  const validateBusinessRegister = () => {
    const phoneDigits = phone.replace(/\D/g, "");

    if (!fullName.trim()) {
      showNotice("error", "Thiếu thông tin", "Vui lòng nhập họ và tên");
      return false;
    }

    if (!phoneDigits) {
      showNotice("error", "Thiếu thông tin", "Vui lòng nhập số điện thoại");
      return false;
    }

    if (!/^\d{10}$/.test(phoneDigits)) {
      showNotice("error", "Số điện thoại không hợp lệ", "Số điện thoại phải đủ 10 số");
      return false;
    }

    if (!email.trim()) {
      showNotice("error", "Thiếu thông tin", "Vui lòng nhập email");
      return false;
    }

    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) {
      showNotice("error", "Email không hợp lệ", "Vui lòng nhập đúng định dạng email");
      return false;
    }

    if (!company.trim()) {
      showNotice("error", "Thiếu thông tin", "Vui lòng nhập tên công ty");
      return false;
    }

    if (!taxCode.trim()) {
      showNotice("error", "Thiếu thông tin", "Vui lòng nhập mã số thuế");
      return false;
    }

    if (!agree) {
      showNotice(
        "error",
        "Chưa đồng ý điều khoản",
        "Vui lòng đồng ý điều khoản trước khi đăng ký"
      );
      return false;
    }

    return true;
  };

  const handleBusinessRegister = async () => {
    const isValid = validateBusinessRegister();

    if (!isValid) {
      return;
    }

    try {
      setLoading(true);

      await registerBusinessRequest({
        fullName: fullName.trim(),
        phone: phone.replace(/\D/g, ""),
        email: email.trim().toLowerCase(),
        company: company.trim(),
        taxCode: taxCode.trim(),
      });

      showNotice(
        "success",
        "Đăng ký thành công",
        "Thông tin doanh nghiệp đã được gửi. Bộ phận tư vấn sẽ liên hệ sau."
      );

      setTimeout(() => {
        closeNotice();

        navigation.reset({
          index: 0,
          routes: [{ name: "Home" }],
        });
      }, 1400);
    } catch (error) {
      showNotice("error", "Đăng ký thất bại", getErrorMessage(error));
    } finally {
      setLoading(false);
    }
  };

  return (
    <SafeAreaView edges={["top"]} style={styles.screen}>
      <BusinessRegisterTopBar onBackPress={handleBack} />

      <KeyboardAvoidingView
        style={styles.keyboardView}
        behavior={Platform.OS === "ios" ? "padding" : "height"}
      >
        <ScrollView
          contentContainerStyle={styles.scrollContent}
          keyboardShouldPersistTaps="handled"
          showsVerticalScrollIndicator={false}
          scrollEnabled={keyboardVisible}
          bounces={false}
          overScrollMode="never"
          automaticallyAdjustKeyboardInsets={true}
        >
          <BusinessRegisterForm
            fullName={fullName}
            phone={phone}
            email={email}
            company={company}
            taxCode={taxCode}
            agree={agree}
            loading={loading}
            onChangeFullName={setFullName}
            onChangePhone={setPhone}
            onChangeEmail={setEmail}
            onChangeCompany={setCompany}
            onChangeTaxCode={setTaxCode}
            onToggleAgree={() => setAgree((prev) => !prev)}
            onRegisterPress={handleBusinessRegister}
          />
        </ScrollView>
      </KeyboardAvoidingView>

      {notice.visible && (
        <View style={styles.noticeOverlay}>
          <View style={styles.noticeBox}>
            <View
              style={[
                styles.noticeIcon,
                notice.type === "error" && styles.noticeIconError,
              ]}
            >
              <Text style={styles.noticeIconText}>
                {notice.type === "success" ? "✓" : "!"}
              </Text>
            </View>

            <Text style={styles.noticeTitle}>{notice.title}</Text>

            <Text style={styles.noticeDesc}>{notice.message}</Text>

            {notice.type === "error" && (
              <Text style={styles.closeNoticeText} onPress={closeNotice}>
                Đóng
              </Text>
            )}
          </View>
        </View>
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: "#E0F5EA",
  },

  keyboardView: {
    flex: 1,
    backgroundColor: "#FFFFFF",
  },

  scrollContent: {
    flexGrow: 1,
    backgroundColor: "#FFFFFF",
  },

  noticeOverlay: {
    position: "absolute",
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: "rgba(0, 0, 0, 0.32)",
    justifyContent: "center",
    alignItems: "center",
    zIndex: 999,
  },

  noticeBox: {
    width: 310,
    minHeight: 185,
    backgroundColor: "#FFFFFF",
    borderRadius: 14,
    alignItems: "center",
    justifyContent: "center",
    paddingHorizontal: 24,
    paddingVertical: 26,
  },

  noticeIcon: {
    width: 56,
    height: 56,
    borderRadius: 28,
    backgroundColor: "#16B94E",
    alignItems: "center",
    justifyContent: "center",
    marginBottom: 14,
  },

  noticeIconError: {
    backgroundColor: "#E53935",
  },

  noticeIconText: {
    fontSize: 32,
    fontWeight: "900",
    color: "#FFFFFF",
    lineHeight: 36,
  },

  noticeTitle: {
    fontSize: 20,
    fontWeight: "800",
    color: "#111111",
    marginBottom: 8,
    textAlign: "center",
  },

  noticeDesc: {
    fontSize: 14,
    color: "#777777",
    textAlign: "center",
    lineHeight: 20,
  },

  closeNoticeText: {
    marginTop: 16,
    fontSize: 15,
    fontWeight: "800",
    color: "#16B94E",
  },
});