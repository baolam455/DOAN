import React, { useEffect, useState } from "react";
import {
    Keyboard,
    KeyboardAvoidingView,
    Platform,
    ScrollView,
    StyleSheet,
    View,
    Text,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { useNavigation } from "@react-navigation/native";

import RegisterTopBar from "../../components/Mobile/Register/RegisterTopBar";
import RegisterForm from "../../components/Mobile/Register/RegisterForm";

import { registerCustomer, getErrorMessage } from "../../services/customerApi";

export default function RegisterMobileScreen() {
    const navigation = useNavigation<any>();

    const [storeName, setStoreName] = useState("");
    const [phone, setPhone] = useState("");
    const [email, setEmail] = useState("");
    const [address, setAddress] = useState("");
    const [password, setPassword] = useState("");
    const [rePassword, setRePassword] = useState("");
    const [agree, setAgree] = useState(false);

    const [loading, setLoading] = useState(false);

    const [notice, setNotice] = useState({
        visible: false,
        type: "success" as "success" | "error",
        title: "",
        message: "",
    });

    const [keyboardVisible, setKeyboardVisible] = useState(false);

    useEffect(() => {
        const showSub = Keyboard.addListener("keyboardDidShow", () => {
            setKeyboardVisible(true);
        });

        const hideSub = Keyboard.addListener("keyboardDidHide", () => {
            setKeyboardVisible(false);
        });

        return () => {
            showSub.remove();
            hideSub.remove();
        };
    }, []);

    const handleBack = () => {
        if (navigation.canGoBack()) {
            navigation.goBack();
        } else {
            navigation.navigate("Home");
        }
    };

    const showNotice = (
        type: "success" | "error",
        title: string,
        message: string
    ) => {
        setNotice({
            visible: true,
            type,
            title,
            message,
        });
    };

    const closeNotice = () => {
        setNotice((prev) => ({
            ...prev,
            visible: false,
        }));
    };

    const validateRegister = () => {
        const phoneDigits = phone.replace(/\D/g, "");

        if (!storeName.trim()) {
            showNotice("error", "Thiếu thông tin", "Vui lòng nhập tên cửa hàng");
            return false;
        }

        if (!phoneDigits) {
            showNotice("error", "Thiếu thông tin", "Vui lòng nhập số điện thoại");
            return false;
        }

        if (!/^\d{10}$/.test(phoneDigits)) {
            showNotice("error", "Số điện thoại không hợp lệ", "Số điện thoại phải đủ 10 số");
            return false;
        }

        if (!email.trim()) {
            showNotice("error", "Thiếu thông tin", "Vui lòng nhập email");
            return false;
        }

        if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) {
            showNotice("error", "Email không hợp lệ", "Vui lòng nhập đúng định dạng email");
            return false;
        }

        if (!address.trim()) {
            showNotice("error", "Thiếu thông tin", "Vui lòng nhập địa chỉ lấy hàng");
            return false;
        }

        if (!password) {
            showNotice("error", "Thiếu thông tin", "Vui lòng nhập mật khẩu");
            return false;
        }

        if (
            !/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[^A-Za-z0-9]).{6,}$/.test(
                password
            )
        ) {
            showNotice(
                "error",
                "Mật khẩu chưa đủ mạnh",
                "Mật khẩu phải có chữ hoa, chữ thường, số và ký tự đặc biệt"
            );
            return false;
        }

        if (!rePassword) {
            showNotice("error", "Thiếu thông tin", "Vui lòng nhập lại mật khẩu");
            return false;
        }

        if (password !== rePassword) {
            showNotice("error", "Mật khẩu không khớp", "Mật khẩu xác nhận không khớp");
            return false;
        }

        if (!agree) {
            showNotice(
                "error",
                "Chưa đồng ý điều khoản",
                "Vui lòng đồng ý điều khoản trước khi đăng ký"
            );
            return false;
        }

        return true;
    };

    const handleRegister = async () => {
        const isValid = validateRegister();

        if (!isValid) {
            return;
        }

        try {
            setLoading(true);

            await registerCustomer({
                storeName: storeName.trim(),
                phone: phone.replace(/\D/g, ""),
                email: email.trim().toLowerCase(),
                address: address.trim(),
                password,
                rePassword,
            });

            showNotice(
                "success",
                "Đăng ký thành công",
                "Đang chuyển về màn hình đăng nhập..."
            );

            setTimeout(() => {
                closeNotice();

                navigation.reset({
                    index: 0,
                    routes: [{ name: "Login" }],
                });
            }, 1200);
        } catch (error) {
            showNotice("error", "Đăng ký thất bại", getErrorMessage(error));
        } finally {
            setLoading(false);
        }
    };

    return (
        <SafeAreaView edges={["top"]} style={styles.screen}>
            <RegisterTopBar onBackPress={handleBack} />

            <KeyboardAvoidingView
                style={styles.keyboardView}
                behavior={Platform.OS === "ios" ? "padding" : "height"}
            >
                <ScrollView
                    contentContainerStyle={styles.scrollContent}
                    keyboardShouldPersistTaps="handled"
                    showsVerticalScrollIndicator={false}
                    scrollEnabled={keyboardVisible}
                    bounces={false}
                    overScrollMode="never"
                    automaticallyAdjustKeyboardInsets={true}
                >
                    <RegisterForm
                        storeName={storeName}
                        phone={phone}
                        email={email}
                        address={address}
                        password={password}
                        rePassword={rePassword}
                        agree={agree}
                        loading={loading}
                        onChangeStoreName={setStoreName}
                        onChangePhone={setPhone}
                        onChangeEmail={setEmail}
                        onChangeAddress={setAddress}
                        onChangePassword={setPassword}
                        onChangeRePassword={setRePassword}
                        onToggleAgree={() => setAgree((prev) => !prev)}
                        onRegisterPress={handleRegister}
                    />
                </ScrollView>
            </KeyboardAvoidingView>

            {notice.visible && (
                <View style={styles.noticeOverlay}>
                    <View style={styles.noticeBox}>
                        <View
                            style={[
                                styles.noticeIcon,
                                notice.type === "error" && styles.noticeIconError,
                            ]}
                        >
                            <Text style={styles.noticeIconText}>
                                {notice.type === "success" ? "✓" : "!"}
                            </Text>
                        </View>

                        <Text style={styles.noticeTitle}>{notice.title}</Text>

                        <Text style={styles.noticeDesc}>{notice.message}</Text>

                        {notice.type === "error" && (
                            <Text style={styles.closeNoticeText} onPress={closeNotice}>
                                Đóng
                            </Text>
                        )}
                    </View>
                </View>
            )}
        </SafeAreaView>
    );
}

const styles = StyleSheet.create({
    screen: {
        flex: 1,
        backgroundColor: "#E0F5EA",
    },

    keyboardView: {
        flex: 1,
        backgroundColor: "#FFFFFF",
    },

    scrollContent: {
        flexGrow: 1,
        backgroundColor: "#FFFFFF",
    },

    noticeOverlay: {
        position: "absolute",
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        backgroundColor: "rgba(0, 0, 0, 0.32)",
        justifyContent: "center",
        alignItems: "center",
        zIndex: 999,
    },

    noticeBox: {
        width: 310,
        minHeight: 185,
        backgroundColor: "#FFFFFF",
        borderRadius: 14,
        alignItems: "center",
        justifyContent: "center",
        paddingHorizontal: 24,
        paddingVertical: 26,
    },

    noticeIcon: {
        width: 56,
        height: 56,
        borderRadius: 28,
        backgroundColor: "#16B94E",
        alignItems: "center",
        justifyContent: "center",
        marginBottom: 14,
    },

    noticeIconError: {
        backgroundColor: "#E53935",
    },

    noticeIconText: {
        fontSize: 32,
        fontWeight: "900",
        color: "#FFFFFF",
        lineHeight: 36,
    },

    noticeTitle: {
        fontSize: 20,
        fontWeight: "800",
        color: "#111111",
        marginBottom: 8,
        textAlign: "center",
    },

    noticeDesc: {
        fontSize: 14,
        color: "#777777",
        textAlign: "center",
        lineHeight: 20,
    },

    closeNoticeText: {
        marginTop: 16,
        fontSize: 15,
        fontWeight: "800",
        color: "#16B94E",
    },
});