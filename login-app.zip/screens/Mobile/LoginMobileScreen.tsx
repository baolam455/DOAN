import React, { useEffect, useState } from "react";
import {
    Alert,
    Keyboard,
    KeyboardAvoidingView,
    Platform,
    ScrollView,
    StyleSheet,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { useNavigation } from "@react-navigation/native";

import LoginTopBar from "../../components/Mobile/Login/LoginTopBar";
import LoginForm from "../../components/Mobile/Login/LoginForm";

import { loginCustomer, getErrorMessage } from "../../services/customerApi";

export default function LoginMobileScreen() {
    const navigation = useNavigation<any>();

    const [account, setAccount] = useState("");
    const [password, setPassword] = useState("");

    const [keyboardVisible, setKeyboardVisible] = useState(false);

    useEffect(() => {
        const showSub = Keyboard.addListener("keyboardDidShow", () => {
            setKeyboardVisible(true);
        });

        const hideSub = Keyboard.addListener("keyboardDidHide", () => {
            setKeyboardVisible(false);
        });

        return () => {
            showSub.remove();
            hideSub.remove();
        };
    }, []);

    const handleBack = () => {
        if (navigation.canGoBack()) {
            navigation.goBack();
        } else {
            navigation.navigate("Home");
        }
    };

    const handleLogin = async () => {
        if (!account.trim()) {
            Alert.alert("Thiếu thông tin", "Vui lòng nhập số điện thoại hoặc email");
            return;
        }

        if (!password) {
            Alert.alert("Thiếu thông tin", "Vui lòng nhập mật khẩu");
            return;
        }

        try {
            const session = await loginCustomer({
                account: account.trim(),
                password,
            });

            navigation.reset({
                index: 0,
                routes: [{ name: session.role === "admin" ? "AdminDashboard" : "Dashboard" }],
            });
        } catch (error) {
            Alert.alert("Đăng nhập thất bại", getErrorMessage(error));
        }
    };

    return (
        <SafeAreaView edges={["top"]} style={styles.screen}>
            <LoginTopBar onBackPress={handleBack} />

            <KeyboardAvoidingView
                style={styles.keyboardView}
                behavior={Platform.OS === "ios" ? "padding" : "height"}
            >
                <ScrollView
                    contentContainerStyle={styles.scrollContent}
                    keyboardShouldPersistTaps="handled"
                    showsVerticalScrollIndicator={false}
                    scrollEnabled={keyboardVisible}
                    bounces={false}
                    overScrollMode="never"
                    automaticallyAdjustKeyboardInsets={true}
                >
                    <LoginForm
                        account={account}
                        password={password}
                        onChangeAccount={setAccount}
                        onChangePassword={setPassword}
                        onLoginPress={handleLogin}
                    />
                </ScrollView>
            </KeyboardAvoidingView>
        </SafeAreaView>
    );
}

const styles = StyleSheet.create({
    screen: {
        flex: 1,
        backgroundColor: "#E0F5EA",
    },

    keyboardView: {
        flex: 1,
        backgroundColor: "#FFFFFF",
    },

    scrollContent: {
        flexGrow: 1,
        backgroundColor: "#FFFFFF",
    },
});
