import React, { useEffect, useMemo, useState } from "react";
import {
  ActivityIndicator,
  Alert,
  KeyboardAvoidingView,
  Platform,
  SafeAreaView,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";
import { useNavigation } from "@react-navigation/native";
import { MaterialCommunityIcons } from "@expo/vector-icons";

import { CustomerProfile, getCurrentCustomer } from "../../services/customerApi";
import { createOrder } from "../../services/orderApi";
import { quoteShippingFee } from "../../services/publicApi";
import { colors, radii } from "../../theme";

type LocationTarget = "receiver" | "pickup";
type LocationStatus = "idle" | "loading" | "success" | "error";

const webNoOutline =
  Platform.OS === "web"
    ? ({ outlineStyle: "none", outlineWidth: 0, outlineColor: "transparent" } as any)
    : null;

function moneyToNumber(value: string) {
  return Number(value.replace(/\D/g, "") || 0);
}

function formatMoney(value: number) {
  return value.toLocaleString("vi-VN");
}

function parseWeight(value: string) {
  const parsed = Number(value.replace(",", "."));
  return Number.isFinite(parsed) ? parsed : 0;
}

function Field({
  label,
  value,
  onChangeText,
  placeholder,
  keyboardType = "default",
  multiline = false,
}: {
  label: string;
  value: string;
  onChangeText: (value: string) => void;
  placeholder: string;
  keyboardType?: "default" | "phone-pad" | "numeric" | "decimal-pad";
  multiline?: boolean;
}) {
  return (
    <View style={styles.field}>
      <Text style={styles.label}>{label}</Text>
      <TextInput
        style={[styles.input, multiline && styles.textArea, webNoOutline]}
        value={value}
        onChangeText={onChangeText}
        placeholder={placeholder}
        placeholderTextColor={colors.textSubtle}
        keyboardType={keyboardType}
        multiline={multiline}
      />
    </View>
  );
}

function OptionButton({
  label,
  active,
  onPress,
}: {
  label: string;
  active: boolean;
  onPress: () => void;
}) {
  return (
    <TouchableOpacity
      activeOpacity={0.84}
      style={[styles.optionButton, active && styles.optionButtonActive, webNoOutline]}
      onPress={onPress}
    >
      <Text style={[styles.optionText, active && styles.optionTextActive]}>{label}</Text>
    </TouchableOpacity>
  );
}

function SummaryRow({ label, value }: { label: string; value: string }) {
  return (
    <View style={styles.summaryRow}>
      <Text style={styles.summaryLabel}>{label}</Text>
      <Text style={styles.summaryValue}>{value}</Text>
    </View>
  );
}

export default function CreateOrderMobileScreen() {
  const navigation = useNavigation<any>();
  const [customer, setCustomer] = useState<CustomerProfile | null>(null);
  const [saving, setSaving] = useState(false);
  const [feeLoading, setFeeLoading] = useState(false);
  const [shippingFee, setShippingFee] = useState(0);
  const [locationStatus, setLocationStatus] = useState<Record<LocationTarget, LocationStatus>>({
    receiver: "idle",
    pickup: "idle",
  });

  const [receiverPhone, setReceiverPhone] = useState("");
  const [receiverName, setReceiverName] = useState("");
  const [receiverAddress, setReceiverAddress] = useState("");
  const [receiverWard, setReceiverWard] = useState("");
  const [receiverProvince, setReceiverProvince] = useState("");
  const [pickupAddress, setPickupAddress] = useState("");
  const [productName, setProductName] = useState("");
  const [quantity, setQuantity] = useState("1");
  const [weight, setWeight] = useState("0.5");
  const [codAmount, setCodAmount] = useState("");
  const [productValue, setProductValue] = useState("");
  const [shippingType, setShippingType] = useState<"express" | "bbs">("express");
  const [transportType, setTransportType] = useState<"road" | "air">("road");
  const [pickupMethod, setPickupMethod] = useState<"home" | "post">("home");
  const [shipPayer, setShipPayer] = useState<"customer" | "shop">("customer");

  const weightNumber = useMemo(() => parseWeight(weight), [weight]);
  const codNumber = moneyToNumber(codAmount);
  const productValueNumber = moneyToNumber(productValue);
  const totalCollection = shipPayer === "customer" ? codNumber + shippingFee : codNumber;

  useEffect(() => {
    getCurrentCustomer()
      .then((profile) => {
        if (!profile) return;
        setCustomer(profile);
        setPickupAddress((current) => current || profile.address || "");
      })
      .catch(() => {});
  }, []);

  useEffect(() => {
    if (!Number.isFinite(weightNumber) || weightNumber <= 0) {
      setShippingFee(0);
      return;
    }

    let cancelled = false;

    const loadFee = async () => {
      try {
        setFeeLoading(true);
        const fee = await quoteShippingFee({
          receiverProvince: receiverProvince.trim() || undefined,
          shippingType,
          totalWeight: weightNumber,
        });
        if (!cancelled) setShippingFee(fee);
      } catch {
        if (!cancelled) setShippingFee(0);
      } finally {
        if (!cancelled) setFeeLoading(false);
      }
    };

    loadFee();

    return () => {
      cancelled = true;
    };
  }, [receiverProvince, shippingType, weightNumber]);

  const setLocationState = (target: LocationTarget, status: LocationStatus) => {
    setLocationStatus((prev) => ({ ...prev, [target]: status }));
  };

  const fillAddressFromCurrentLocation = (target: LocationTarget) => {
    const geo = (globalThis.navigator as any)?.geolocation;

    if (!geo) {
      Alert.alert(
        "Không lấy được vị trí",
        "Môi trường hiện tại chưa hỗ trợ định vị. Bạn nhập địa chỉ thủ công giúp mình.",
      );
      return;
    }

    setLocationState(target, "loading");
    geo.getCurrentPosition(
      async (position: any) => {
        try {
          const lat = position.coords.latitude;
          const lon = position.coords.longitude;
          const response = await fetch(
            `https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat}&lon=${lon}&accept-language=vi`,
          );
          const data = await response.json();
          const address = data?.address || {};
          const displayName = data?.display_name || `${lat}, ${lon}`;

          if (target === "receiver") {
            setReceiverAddress(displayName);
            setReceiverWard(address.suburb || address.ward || address.village || address.town || "");
            setReceiverProvince(address.city || address.state || address.province || "");
          } else {
            setPickupAddress(displayName);
          }

          setLocationState(target, "success");
        } catch {
          setLocationState(target, "error");
          Alert.alert("Không đọc được địa chỉ", "Bạn nhập thủ công giúp mình.");
        }
      },
      () => {
        setLocationState(target, "error");
        Alert.alert("Không lấy được vị trí", "Bạn cần cấp quyền vị trí rồi thử lại.");
      },
      { enableHighAccuracy: true, timeout: 10000, maximumAge: 60000 },
    );
  };

  const handleSave = async () => {
    const phone = receiverPhone.replace(/\D/g, "");
    const name = receiverName.trim();
    const receiverFullAddress = [receiverAddress.trim(), receiverWard.trim(), receiverProvince.trim()]
      .filter(Boolean)
      .join(", ");
    const pickup = pickupAddress.trim();
    const product = productName.trim();

    if (!/^\d{10}$/.test(phone)) {
      Alert.alert("Số điện thoại chưa đúng", "Số điện thoại người nhận cần đủ 10 số.");
      return;
    }

    if (!name || !receiverFullAddress || !product) {
      Alert.alert("Thiếu thông tin", "Vui lòng nhập người nhận, địa chỉ nhận và sản phẩm.");
      return;
    }

    if (pickupMethod === "home" && !pickup) {
      Alert.alert("Thiếu địa chỉ lấy hàng", "Vui lòng nhập địa chỉ lấy hàng.");
      return;
    }

    if (!Number.isFinite(weightNumber) || weightNumber <= 0) {
      Alert.alert("Khối lượng chưa đúng", "Khối lượng đơn hàng phải lớn hơn 0kg.");
      return;
    }

    setSaving(true);
    try {
      await createOrder({
        receiverPhone: phone,
        receiverName: name,
        receiverAddress: receiverFullAddress,
        receiverWard: receiverWard.trim() || undefined,
        receiverProvince: receiverProvince.trim() || undefined,
        shippingType,
        transportType,
        pickupMethod,
        shipPayer,
        codAmount: codNumber,
        productValue: productValueNumber,
        totalWeight: weightNumber,
        productName: product,
        quantity: Number(quantity.replace(/\D/g, "") || 1),
        pickupAddress: pickup || undefined,
        pickupNote: pickupMethod === "post" ? "Khách gửi tại bưu cục" : undefined,
      });

      Alert.alert("Thành công", "Đơn hàng đã được tạo.", [
        { text: "Xem đơn", onPress: () => navigation.navigate("OrderList") },
      ]);
    } catch (error: any) {
      Alert.alert("Lỗi tạo đơn", error?.message || "Không thể tạo đơn hàng.");
    } finally {
      setSaving(false);
    }
  };

  return (
    <SafeAreaView style={styles.safeArea}>
      <View style={styles.header}>
        <TouchableOpacity
          activeOpacity={0.84}
          style={[styles.iconButton, webNoOutline]}
          onPress={() => navigation.navigate("Dashboard")}
        >
          <MaterialCommunityIcons name="chevron-left" size={28} color={colors.text} />
        </TouchableOpacity>
        <View style={styles.headerCenter}>
          <Text style={styles.title}>Tạo đơn</Text>
          <Text style={styles.subtitle}>{customer?.store_name || "Đơn hàng mới"}</Text>
        </View>
        <View style={styles.iconButton} />
      </View>

      <KeyboardAvoidingView
        style={styles.keyboardView}
        behavior={Platform.OS === "ios" ? "padding" : "height"}
      >
        <ScrollView
          style={styles.scroll}
          contentContainerStyle={styles.content}
          keyboardShouldPersistTaps="handled"
          showsVerticalScrollIndicator={false}
        >
          <View style={styles.card}>
            <Text style={styles.cardTitle}>Người nhận</Text>
            <Field
              label="Số điện thoại"
              value={receiverPhone}
              onChangeText={(text) => setReceiverPhone(text.replace(/\D/g, "").slice(0, 10))}
              placeholder="0901234567"
              keyboardType="phone-pad"
            />
            <Field
              label="Tên người nhận"
              value={receiverName}
              onChangeText={setReceiverName}
              placeholder="Nhập tên người nhận"
            />
            <Field
              label="Địa chỉ chi tiết"
              value={receiverAddress}
              onChangeText={setReceiverAddress}
              placeholder="Số nhà, đường, tòa nhà..."
              multiline
            />
            <View style={styles.twoColumns}>
              <View style={styles.halfField}>
                <Field
                  label="Phường/Xã"
                  value={receiverWard}
                  onChangeText={setReceiverWard}
                  placeholder="Phường/Xã"
                />
              </View>
              <View style={styles.halfField}>
                <Field
                  label="Tỉnh/TP"
                  value={receiverProvince}
                  onChangeText={setReceiverProvince}
                  placeholder="Tỉnh/TP"
                />
              </View>
            </View>
            <TouchableOpacity
              activeOpacity={0.84}
              style={[styles.locationButton, webNoOutline]}
              onPress={() => fillAddressFromCurrentLocation("receiver")}
            >
              {locationStatus.receiver === "loading" ? (
                <ActivityIndicator size="small" color={colors.brand} />
              ) : (
                <MaterialCommunityIcons name="crosshairs-gps" size={18} color={colors.brand} />
              )}
              <Text style={styles.locationText}>Dùng vị trí hiện tại</Text>
            </TouchableOpacity>
          </View>

          <View style={styles.card}>
            <Text style={styles.cardTitle}>Lấy hàng</Text>
            <View style={styles.optionRow}>
              <OptionButton
                label="Lấy tận nơi"
                active={pickupMethod === "home"}
                onPress={() => setPickupMethod("home")}
              />
              <OptionButton
                label="Gửi bưu cục"
                active={pickupMethod === "post"}
                onPress={() => setPickupMethod("post")}
              />
            </View>
            <Field
              label="Địa chỉ lấy hàng"
              value={pickupAddress}
              onChangeText={setPickupAddress}
              placeholder="Nhập địa chỉ kho/cửa hàng"
              multiline
            />
            <TouchableOpacity
              activeOpacity={0.84}
              style={[styles.locationButton, webNoOutline]}
              onPress={() => fillAddressFromCurrentLocation("pickup")}
            >
              {locationStatus.pickup === "loading" ? (
                <ActivityIndicator size="small" color={colors.brand} />
              ) : (
                <MaterialCommunityIcons name="map-marker-radius-outline" size={18} color={colors.brand} />
              )}
              <Text style={styles.locationText}>Dùng vị trí lấy hàng</Text>
            </TouchableOpacity>
          </View>

          <View style={styles.card}>
            <Text style={styles.cardTitle}>Hàng hóa</Text>
            <Field
              label="Tên sản phẩm"
              value={productName}
              onChangeText={setProductName}
              placeholder="Nhập tên sản phẩm"
            />
            <View style={styles.twoColumns}>
              <View style={styles.halfField}>
                <Field
                  label="Số lượng"
                  value={quantity}
                  onChangeText={(text) => setQuantity(text.replace(/\D/g, "") || "1")}
                  placeholder="1"
                  keyboardType="numeric"
                />
              </View>
              <View style={styles.halfField}>
                <Field
                  label="Kg"
                  value={weight}
                  onChangeText={setWeight}
                  placeholder="0.5"
                  keyboardType="decimal-pad"
                />
              </View>
            </View>
            <Field
              label="COD"
              value={codAmount ? formatMoney(moneyToNumber(codAmount)) : ""}
              onChangeText={(text) => setCodAmount(text.replace(/\D/g, ""))}
              placeholder="0"
              keyboardType="numeric"
            />
            <Field
              label="Giá trị hàng"
              value={productValue ? formatMoney(moneyToNumber(productValue)) : ""}
              onChangeText={(text) => setProductValue(text.replace(/\D/g, ""))}
              placeholder="0"
              keyboardType="numeric"
            />
          </View>

          <View style={styles.card}>
            <Text style={styles.cardTitle}>Dịch vụ và thanh toán</Text>
            <Text style={styles.optionLabel}>Loại đơn</Text>
            <View style={styles.optionRow}>
              <OptionButton
                label="EXP <20kg"
                active={shippingType === "express"}
                onPress={() => setShippingType("express")}
              />
              <OptionButton
                label="BBS ≥20kg"
                active={shippingType === "bbs"}
                onPress={() => setShippingType("bbs")}
              />
            </View>

            <Text style={styles.optionLabel}>Vận chuyển</Text>
            <View style={styles.optionRow}>
              <OptionButton
                label="Đường bộ"
                active={transportType === "road"}
                onPress={() => setTransportType("road")}
              />
              <OptionButton
                label="Đường bay"
                active={transportType === "air"}
                onPress={() => setTransportType("air")}
              />
            </View>

            <Text style={styles.optionLabel}>Người trả phí ship</Text>
            <View style={styles.optionRow}>
              <OptionButton
                label="Khách trả"
                active={shipPayer === "customer"}
                onPress={() => setShipPayer("customer")}
              />
              <OptionButton
                label="Shop trả"
                active={shipPayer === "shop"}
                onPress={() => setShipPayer("shop")}
              />
            </View>

            <View style={styles.summaryBox}>
              <SummaryRow label="COD" value={`${formatMoney(codNumber)}đ`} />
              <SummaryRow
                label="Phí ship"
                value={feeLoading ? "Đang tính..." : `${formatMoney(shippingFee)}đ`}
              />
              <View style={styles.summaryDivider} />
              <SummaryRow label="Tổng thu" value={`${formatMoney(totalCollection)}đ`} />
            </View>
          </View>

          <TouchableOpacity
            activeOpacity={0.86}
            style={[styles.saveButton, saving && styles.saveButtonDisabled, webNoOutline]}
            onPress={handleSave}
            disabled={saving}
          >
            {saving ? (
              <ActivityIndicator size="small" color="#FFFFFF" />
            ) : (
              <MaterialCommunityIcons name="check-circle-outline" size={20} color="#FFFFFF" />
            )}
            <Text style={styles.saveText}>{saving ? "Đang tạo..." : "Tạo đơn hàng"}</Text>
          </TouchableOpacity>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: colors.background,
  },

  header: {
    minHeight: 64,
    backgroundColor: colors.surface,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 14,
  },

  iconButton: {
    width: 40,
    height: 40,
    alignItems: "center",
    justifyContent: "center",
  },

  headerCenter: {
    flex: 1,
    alignItems: "center",
  },

  title: {
    fontSize: 18,
    fontWeight: "900",
    color: colors.text,
  },

  subtitle: {
    marginTop: 2,
    fontSize: 12,
    color: colors.textMuted,
  },

  keyboardView: {
    flex: 1,
  },

  scroll: {
    flex: 1,
  },

  content: {
    padding: 14,
    paddingBottom: 34,
  },

  card: {
    backgroundColor: colors.surface,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: radii.md,
    padding: 14,
    marginBottom: 12,
  },

  cardTitle: {
    fontSize: 16,
    fontWeight: "900",
    color: colors.text,
    marginBottom: 12,
  },

  field: {
    marginBottom: 12,
  },

  label: {
    fontSize: 13,
    fontWeight: "800",
    color: "#344054",
    marginBottom: 6,
  },

  input: {
    minHeight: 44,
    borderRadius: radii.sm,
    borderWidth: 1,
    borderColor: colors.borderStrong,
    backgroundColor: colors.surface,
    paddingHorizontal: 12,
    paddingVertical: 9,
    fontSize: 14,
    color: colors.text,
  },

  textArea: {
    minHeight: 78,
    textAlignVertical: "top",
  },

  twoColumns: {
    flexDirection: "row",
    justifyContent: "space-between",
  },

  halfField: {
    width: "48%",
  },

  optionLabel: {
    fontSize: 13,
    fontWeight: "800",
    color: "#344054",
    marginBottom: 8,
  },

  optionRow: {
    flexDirection: "row",
    marginBottom: 14,
  },

  optionButton: {
    minHeight: 38,
    borderRadius: radii.sm,
    borderWidth: 1,
    borderColor: colors.borderStrong,
    backgroundColor: colors.surface,
    paddingHorizontal: 12,
    alignItems: "center",
    justifyContent: "center",
    marginRight: 8,
  },

  optionButtonActive: {
    borderColor: colors.brand,
    backgroundColor: colors.brandSoft,
  },

  optionText: {
    fontSize: 13,
    fontWeight: "800",
    color: colors.textMuted,
  },

  optionTextActive: {
    color: colors.brandDark,
  },

  locationButton: {
    minHeight: 40,
    borderRadius: radii.sm,
    borderWidth: 1,
    borderColor: colors.border,
    backgroundColor: colors.surfaceMuted,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    paddingHorizontal: 12,
  },

  locationText: {
    marginLeft: 8,
    fontSize: 13,
    fontWeight: "800",
    color: colors.brandDark,
  },

  summaryBox: {
    borderRadius: radii.md,
    borderWidth: 1,
    borderColor: colors.border,
    backgroundColor: colors.surfaceMuted,
    padding: 12,
  },

  summaryRow: {
    minHeight: 28,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },

  summaryLabel: {
    fontSize: 13,
    color: colors.textMuted,
  },

  summaryValue: {
    fontSize: 14,
    fontWeight: "900",
    color: colors.text,
  },

  summaryDivider: {
    height: 1,
    backgroundColor: colors.border,
    marginVertical: 8,
  },

  saveButton: {
    minHeight: 48,
    borderRadius: radii.md,
    backgroundColor: colors.brand,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
  },

  saveButtonDisabled: {
    opacity: 0.72,
  },

  saveText: {
    fontSize: 15,
    fontWeight: "900",
    color: "#FFFFFF",
    marginLeft: 8,
  },
});
