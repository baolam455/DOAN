import React from "react";
import { View, StyleSheet } from "react-native";
import { useNavigation } from "@react-navigation/native";

import WelcomeBackground from "../../components/Mobile/Welcome/WelcomeBackground";
import WelcomeButtonArea from "../../components/Mobile/Welcome/WelcomeButtonArea";

export default function WelcomeMobileScreen() {
    const navigation = useNavigation<any>();

    return (
        <View style={styles.screen}>
            <WelcomeBackground>
                <WelcomeButtonArea
                    onLoginPress={() => navigation.navigate("Login")}
                    onRegisterPress={() => navigation.navigate("Register")}
                    onBusinessRegisterPress={() => navigation.navigate("BusinessRegister")}
                />
            </WelcomeBackground>
        </View>
    );
}

const styles = StyleSheet.create({
    screen: {
        flex: 1,
        backgroundColor: "#000000",
    },
});