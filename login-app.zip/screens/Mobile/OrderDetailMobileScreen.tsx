import React, { useEffect, useState } from "react";
import {
  ActivityIndicator,
  SafeAreaView,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";
import { useNavigation, useRoute } from "@react-navigation/native";
import { MaterialCommunityIcons } from "@expo/vector-icons";

import {
  getOrderById,
  getOrderTracking,
  Order,
  OrderTracking,
  statusColor,
  statusIcon,
  statusLabel,
} from "../../services/orderApi";

function formatMoney(amount: number | null | undefined) {
  if (amount == null || isNaN(amount)) return "—";
  return amount.toLocaleString("vi-VN") + "đ";
}

function formatDate(value: string) {
  return new Date(value).toLocaleString("vi-VN", {
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
}

function InfoRow({ label, value }: { label: string; value: string }) {
  return (
    <View style={styles.infoRow}>
      <Text style={styles.infoLabel}>{label}</Text>
      <Text style={styles.infoValue}>{value}</Text>
    </View>
  );
}

function TrackingRow({ item, last }: { item: OrderTracking; last: boolean }) {
  const color = statusColor(item.status);

  return (
    <View style={styles.trackingRow}>
      <View style={styles.trackingLeft}>
        <View style={[styles.trackingDot, { backgroundColor: color }]}>
          <MaterialCommunityIcons name={statusIcon(item.status) as any} size={13} color="#FFFFFF" />
        </View>
        {!last && <View style={styles.trackingLine} />}
      </View>

      <View style={styles.trackingContent}>
        <Text style={[styles.trackingStatus, { color }]}>{statusLabel(item.status)}</Text>
        {item.note ? <Text style={styles.trackingNote}>{item.note}</Text> : null}
        {item.location ? <Text style={styles.trackingLocation}>{item.location}</Text> : null}
        <Text style={styles.trackingTime}>{formatDate(item.created_at)}</Text>
      </View>
    </View>
  );
}

export default function OrderDetailMobileScreen() {
  const navigation = useNavigation<any>();
  const route = useRoute<any>();
  const orderId = route.params?.orderId as string | undefined;

  const [order, setOrder] = useState<Order | null>(null);
  const [tracking, setTracking] = useState<OrderTracking[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!orderId) return;

    const loadData = async () => {
      setLoading(true);
      try {
        const [orderData, trackingData] = await Promise.all([
          getOrderById(orderId),
          getOrderTracking(orderId),
        ]);
        setOrder(orderData);
        setTracking(trackingData);
      } finally {
        setLoading(false);
      }
    };

    loadData();
  }, [orderId]);

  const color = order ? statusColor(order.status) : "#667085";

  return (
    <SafeAreaView style={styles.safeArea}>
      <View style={styles.header}>
        <TouchableOpacity
          activeOpacity={0.82}
          style={styles.iconButton}
          onPress={() => navigation.navigate("OrderList")}
        >
          <MaterialCommunityIcons name="chevron-left" size={28} color="#111827" />
        </TouchableOpacity>

        <Text style={styles.title}>Chi tiết đơn</Text>

        <View style={styles.iconButton} />
      </View>

      {loading ? (
        <View style={styles.centerBox}>
          <ActivityIndicator size="large" color="#148F5A" />
          <Text style={styles.centerText}>Đang tải chi tiết...</Text>
        </View>
      ) : !order ? (
        <View style={styles.centerBox}>
          <MaterialCommunityIcons name="alert-circle-outline" size={56} color="#D0D5DD" />
          <Text style={styles.emptyTitle}>Không tìm thấy đơn hàng</Text>
        </View>
      ) : (
        <ScrollView
          style={styles.scroll}
          contentContainerStyle={styles.content}
          showsVerticalScrollIndicator={false}
        >
          <View style={styles.summaryCard}>
            <Text style={styles.orderCode}>{order.order_code}</Text>

            <View style={[styles.statusBadge, { backgroundColor: color + "18" }]}>
              <MaterialCommunityIcons name={statusIcon(order.status) as any} size={15} color={color} />
              <Text style={[styles.statusText, { color }]}>{statusLabel(order.status)}</Text>
            </View>
          </View>

          <View style={styles.card}>
            <Text style={styles.cardTitle}>Người nhận</Text>
            <InfoRow label="Tên" value={order.receiver_name} />
            <InfoRow label="Số điện thoại" value={order.receiver_phone} />
            <InfoRow label="Địa chỉ" value={order.receiver_address} />
            <InfoRow label="Khu vực" value={order.receiver_province || "Chưa có"} />
          </View>

          <View style={styles.card}>
            <Text style={styles.cardTitle}>Hàng hóa và thanh toán</Text>
            <InfoRow label="Sản phẩm" value={order.product_name || "Sản phẩm"} />
            <InfoRow label="Số lượng" value={`${order.quantity} sản phẩm`} />
            <InfoRow label="Khối lượng" value={`${order.total_weight} kg`} />
            <InfoRow label="COD" value={formatMoney(order.cod_amount)} />
            <InfoRow label="Phí giao" value={formatMoney(order.shipping_fee)} />
          </View>

          <View style={styles.card}>
            <Text style={styles.cardTitle}>Lịch sử vận chuyển</Text>
            {tracking.length === 0 ? (
              <Text style={styles.noTracking}>Chưa có lịch sử vận chuyển</Text>
            ) : (
              [...tracking].reverse().map((item, index) => (
                <TrackingRow
                  key={item.id}
                  item={item}
                  last={index === tracking.length - 1}
                />
              ))
            )}
          </View>
        </ScrollView>
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: "#F4F4F4",
  },

  header: {
    height: 62,
    backgroundColor: "#FFFFFF",
    borderBottomWidth: 1,
    borderBottomColor: "#E5E7EB",
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 14,
  },

  iconButton: {
    width: 40,
    height: 40,
    alignItems: "center",
    justifyContent: "center",
  },

  title: {
    flex: 1,
    fontSize: 20,
    fontWeight: "900",
    color: "#111827",
    textAlign: "center",
  },

  scroll: {
    flex: 1,
  },

  content: {
    padding: 14,
    paddingBottom: 32,
  },

  summaryCard: {
    backgroundColor: "#FFFFFF",
    borderRadius: 12,
    padding: 14,
    marginBottom: 12,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },

  orderCode: {
    flex: 1,
    fontSize: 16,
    fontWeight: "900",
    color: "#148F5A",
  },

  statusBadge: {
    minHeight: 30,
    borderRadius: 15,
    paddingHorizontal: 10,
    flexDirection: "row",
    alignItems: "center",
  },

  statusText: {
    fontSize: 12,
    fontWeight: "900",
    marginLeft: 5,
  },

  card: {
    backgroundColor: "#FFFFFF",
    borderRadius: 12,
    padding: 14,
    marginBottom: 12,
  },

  cardTitle: {
    fontSize: 16,
    fontWeight: "900",
    color: "#111827",
    marginBottom: 10,
  },

  infoRow: {
    minHeight: 38,
    borderTopWidth: 1,
    borderTopColor: "#F0F0F0",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },

  infoLabel: {
    flex: 1,
    fontSize: 13,
    color: "#667085",
  },

  infoValue: {
    flex: 1.4,
    fontSize: 13,
    fontWeight: "800",
    color: "#111827",
    textAlign: "right",
  },

  trackingRow: {
    flexDirection: "row",
    minHeight: 72,
  },

  trackingLeft: {
    width: 28,
    alignItems: "center",
  },

  trackingDot: {
    width: 26,
    height: 26,
    borderRadius: 13,
    alignItems: "center",
    justifyContent: "center",
  },

  trackingLine: {
    width: 2,
    flex: 1,
    backgroundColor: "#E5E7EB",
    marginTop: 4,
  },

  trackingContent: {
    flex: 1,
    paddingLeft: 10,
    paddingBottom: 14,
  },

  trackingStatus: {
    fontSize: 14,
    fontWeight: "900",
  },

  trackingNote: {
    fontSize: 13,
    color: "#475467",
    marginTop: 4,
  },

  trackingLocation: {
    fontSize: 12,
    color: "#667085",
    marginTop: 4,
  },

  trackingTime: {
    fontSize: 12,
    color: "#98A2B3",
    marginTop: 4,
  },

  noTracking: {
    fontSize: 13,
    color: "#667085",
    paddingVertical: 10,
  },

  centerBox: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    paddingHorizontal: 32,
  },

  centerText: {
    marginTop: 12,
    fontSize: 14,
    color: "#667085",
  },

  emptyTitle: {
    fontSize: 18,
    fontWeight: "700",
    color: "#111827",
    marginTop: 12,
  },
});
