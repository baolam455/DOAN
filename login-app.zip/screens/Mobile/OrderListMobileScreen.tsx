import React, { useCallback, useEffect, useMemo, useState } from "react";
import {
  ActivityIndicator,
  SafeAreaView,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";
import { useNavigation } from "@react-navigation/native";
import { MaterialCommunityIcons } from "@expo/vector-icons";

import { getOrders, Order, OrderStatus } from "../../services/orderApi";
import MobileOrderCard from "../../components/Mobile/Orders/MobileOrderCard";

type FilterTab = "all" | OrderStatus;

const tabs: { key: FilterTab; label: string }[] = [
  { key: "all", label: "Tất cả" },
  { key: "pending", label: "Chờ lấy" },
  { key: "delivering", label: "Đang giao" },
  { key: "delivered", label: "Thành công" },
  { key: "returned", label: "Hoàn" },
];

function isDelivering(status: OrderStatus) {
  return ["picked_up", "in_transit", "delivering"].includes(status);
}

export default function OrderListMobileScreen() {
  const navigation = useNavigation<any>();
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<FilterTab>("all");

  const loadOrders = useCallback(async () => {
    setLoading(true);
    try {
      const data = await getOrders();
      setOrders(data);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadOrders();
  }, [loadOrders]);

  const filteredOrders = useMemo(() => {
    if (activeTab === "all") return orders;
    if (activeTab === "delivering") {
      return orders.filter((order) => isDelivering(order.status));
    }
    return orders.filter((order) => order.status === activeTab);
  }, [activeTab, orders]);

  return (
    <SafeAreaView style={styles.safeArea}>
      <View style={styles.header}>
        <TouchableOpacity
          activeOpacity={0.82}
          style={styles.iconButton}
          onPress={() => navigation.navigate("Dashboard")}
        >
          <MaterialCommunityIcons name="chevron-left" size={28} color="#111827" />
        </TouchableOpacity>

        <Text style={styles.title}>Đơn hàng</Text>

        <TouchableOpacity
          activeOpacity={0.82}
          style={styles.addButton}
          onPress={() => navigation.navigate("CreateOrder")}
        >
          <MaterialCommunityIcons name="plus" size={22} color="#FFFFFF" />
        </TouchableOpacity>
      </View>

      <View style={styles.tabsWrap}>
        <ScrollView horizontal showsHorizontalScrollIndicator={false}>
          {tabs.map((tab) => {
            const active = tab.key === activeTab;

            return (
              <TouchableOpacity
                key={tab.key}
                activeOpacity={0.82}
                style={[styles.tab, active && styles.tabActive]}
                onPress={() => setActiveTab(tab.key)}
              >
                <Text style={[styles.tabText, active && styles.tabTextActive]}>
                  {tab.label}
                </Text>
              </TouchableOpacity>
            );
          })}
        </ScrollView>
      </View>

      {loading ? (
        <View style={styles.centerBox}>
          <ActivityIndicator size="large" color="#148F5A" />
          <Text style={styles.centerText}>Đang tải đơn hàng...</Text>
        </View>
      ) : filteredOrders.length === 0 ? (
        <View style={styles.centerBox}>
          <MaterialCommunityIcons name="package-variant" size={56} color="#D0D5DD" />
          <Text style={styles.emptyTitle}>Chưa có đơn hàng</Text>
          <Text style={styles.emptyText}>Tạo đơn đầu tiên để bắt đầu theo dõi vận hành.</Text>
        </View>
      ) : (
        <ScrollView
          style={styles.list}
          contentContainerStyle={styles.listContent}
          showsVerticalScrollIndicator={false}
        >
          {filteredOrders.map((order) => (
            <MobileOrderCard
              key={order.id}
              order={order}
              onPress={() => navigation.navigate("OrderDetail", { orderId: order.id })}
            />
          ))}
        </ScrollView>
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: "#F4F4F4",
  },

  header: {
    height: 62,
    backgroundColor: "#FFFFFF",
    borderBottomWidth: 1,
    borderBottomColor: "#E5E7EB",
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 14,
  },

  iconButton: {
    width: 40,
    height: 40,
    alignItems: "center",
    justifyContent: "center",
  },

  title: {
    flex: 1,
    fontSize: 20,
    fontWeight: "900",
    color: "#111827",
    textAlign: "center",
  },

  addButton: {
    width: 38,
    height: 38,
    borderRadius: 19,
    backgroundColor: "#148F5A",
    alignItems: "center",
    justifyContent: "center",
  },

  tabsWrap: {
    height: 52,
    backgroundColor: "#FFFFFF",
    borderBottomWidth: 1,
    borderBottomColor: "#EAECF0",
    paddingLeft: 14,
    justifyContent: "center",
  },

  tab: {
    height: 34,
    borderRadius: 17,
    backgroundColor: "#F2F4F7",
    paddingHorizontal: 14,
    alignItems: "center",
    justifyContent: "center",
    marginRight: 8,
  },

  tabActive: {
    backgroundColor: "#E9F7EF",
  },

  tabText: {
    fontSize: 13,
    fontWeight: "800",
    color: "#667085",
  },

  tabTextActive: {
    color: "#148F5A",
  },

  list: {
    flex: 1,
  },

  listContent: {
    padding: 14,
    paddingBottom: 28,
  },

  centerBox: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    paddingHorizontal: 32,
  },

  centerText: {
    marginTop: 12,
    fontSize: 14,
    color: "#667085",
  },

  emptyTitle: {
    fontSize: 18,
    fontWeight: "900",
    color: "#111827",
    marginTop: 14,
  },

  emptyText: {
    fontSize: 14,
    color: "#667085",
    textAlign: "center",
    marginTop: 6,
    lineHeight: 20,
  },
});
