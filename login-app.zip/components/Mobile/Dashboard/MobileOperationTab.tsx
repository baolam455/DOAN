import React from "react";
import {
    ScrollView,
    View,
    Text,
    TouchableOpacity,
    StyleSheet,
} from "react-native";
import { MaterialCommunityIcons } from "@expo/vector-icons";

function HeaderIcon({ icon }: { icon: any }) {
    return (
        <TouchableOpacity activeOpacity={0.8} style={styles.headerIcon}>
            <MaterialCommunityIcons name={icon} size={23} color="#111111" />
        </TouchableOpacity>
    );
}

function ServiceItem({
    icon,
    title,
    onPress,
}: {
    icon: any;
    title: string;
    onPress?: () => void;
}) {
    return (
        <TouchableOpacity activeOpacity={0.85} style={styles.serviceItem} onPress={onPress}>
            <View style={styles.serviceImage}>
                <MaterialCommunityIcons name={icon} size={38} color="#D98E44" />
            </View>

            <Text style={styles.serviceText}>{title}</Text>
        </TouchableOpacity>
    );
}

function OrderStat({
    title,
    value,
}: {
    title: string;
    value: string;
}) {
    return (
        <View style={styles.orderStat}>
            <Text style={styles.orderStatTitle}>{title}</Text>
            <Text style={styles.orderStatValue}>{value}</Text>
        </View>
    );
}

type Props = {
    onCreateOrder?: () => void;
    onOpenOrders?: () => void;
};

export default function MobileOperationTab({ onCreateOrder, onOpenOrders }: Props) {
    return (
        <ScrollView
            style={styles.screen}
            contentContainerStyle={styles.content}
            showsVerticalScrollIndicator={false}
        >
            <View style={styles.header}>
                <Text style={styles.title}>Vận hành</Text>

                <View style={styles.headerRight}>
                    <HeaderIcon icon="magnify" />
                    <HeaderIcon icon="file-document-outline" />
                    <HeaderIcon icon="line-scan" />
                    <HeaderIcon icon="bell-outline" />
                    <HeaderIcon icon="view-grid-plus-outline" />
                </View>
            </View>

            <View style={styles.serviceRow}>
                <ServiceItem icon="package-variant-closed" title="EXP <20kg" onPress={onCreateOrder} />
                <ServiceItem icon="package-variant" title="BBS ≥20kg" onPress={onCreateOrder} />
                <ServiceItem icon="home-variant-outline" title="Gửi bưu cục" onPress={onCreateOrder} />
            </View>

            <TouchableOpacity activeOpacity={0.9} style={styles.orderCard} onPress={onOpenOrders}>
                <View style={styles.orderHeader}>
                    <View>
                        <Text style={styles.orderTitle}>Đơn hàng</Text>
                        <View style={styles.orderUnderline} />
                    </View>

                    <View style={styles.orderHeaderRight}>
                        <MaterialCommunityIcons
                            name="calendar-month-outline"
                            size={23}
                            color="#111111"
                        />

                        <Text style={styles.dayText}>30 ngày</Text>

                        <MaterialCommunityIcons
                            name="filter-outline"
                            size={25}
                            color="#111111"
                            style={styles.filterIcon}
                        />
                    </View>
                </View>

                <ScrollView
                    horizontal
                    showsHorizontalScrollIndicator={false}
                    contentContainerStyle={styles.orderStatsRow}
                >
                    <OrderStat title="Phát sinh" value="0 ĐH" />
                    <OrderStat title="Chưa tiếp nhận" value="0 ĐH" />
                    <OrderStat title="Đã lấy" value="0 ĐH" />
                    <OrderStat title="Delay lấy" value="0 ĐH" />
                </ScrollView>
            </TouchableOpacity>

            <View style={styles.emptyArea}>
                <Text style={styles.emptyText}>Không có thông tin đơn hàng</Text>
            </View>
        </ScrollView>
    );
}

const styles = StyleSheet.create({
    screen: {
        flex: 1,
        backgroundColor: "#F4F4F4",
    },

    content: {
        paddingHorizontal: 16,
        paddingTop: 18,
        paddingBottom: 90,
    },

    header: {
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "space-between",
    },

    title: {
        fontSize: 24,
        fontWeight: "800",
        color: "#111111",
    },

    headerRight: {
        flexDirection: "row",
        alignItems: "center",
    },

    headerIcon: {
        marginLeft: 12,
    },

    serviceRow: {
        flexDirection: "row",
        alignItems: "center",
        marginTop: 24,
        marginBottom: 26,
    },

    serviceItem: {
        width: 92,
        marginRight: 16,
    },

    serviceImage: {
        height: 48,
        alignItems: "center",
        justifyContent: "center",
    },

    serviceText: {
        fontSize: 14,
        color: "#111111",
        marginTop: 5,
        textAlign: "center",
    },

    orderCard: {
        backgroundColor: "#FFFFFF",
        borderRadius: 12,
        paddingHorizontal: 18,
        paddingTop: 18,
        paddingBottom: 20,
    },

    orderHeader: {
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "space-between",
    },

    orderTitle: {
        fontSize: 20,
        fontWeight: "800",
        color: "#111111",
    },

    orderUnderline: {
        width: 76,
        height: 2,
        backgroundColor: "#111111",
        marginTop: 8,
    },

    orderHeaderRight: {
        flexDirection: "row",
        alignItems: "center",
    },

    dayText: {
        fontSize: 15,
        color: "#111111",
        marginLeft: 6,
    },

    filterIcon: {
        marginLeft: 16,
    },

    orderStatsRow: {
        paddingTop: 22,
    },

    orderStat: {
        width: 128,
        height: 82,
        borderRadius: 8,
        backgroundColor: "#F7F7F7",
        justifyContent: "center",
        paddingHorizontal: 14,
        marginRight: 12,
    },

    orderStatTitle: {
        fontSize: 13,
        color: "#999999",
        marginBottom: 6,
    },

    orderStatValue: {
        fontSize: 17,
        fontWeight: "800",
        color: "#111111",
    },

    emptyArea: {
        minHeight: 360,
        alignItems: "center",
        justifyContent: "center",
    },

    emptyText: {
        fontSize: 15,
        color: "#9A9A9A",
    },
});
