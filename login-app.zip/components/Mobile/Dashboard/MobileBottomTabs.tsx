import React from "react";
import { View, Text, TouchableOpacity, StyleSheet } from "react-native";
import { MaterialCommunityIcons } from "@expo/vector-icons";

export type MobileDashboardTab = "chats" | "operation" | "account";

type Props = {
    activeTab: MobileDashboardTab;
    onChangeTab: (tab: MobileDashboardTab) => void;
};

function TabButton({
    label,
    icon,
    tab,
    activeTab,
    onChangeTab,
    badge,
}: {
    label: string;
    icon: any;
    tab: MobileDashboardTab;
    activeTab: MobileDashboardTab;
    onChangeTab: (tab: MobileDashboardTab) => void;
    badge?: string;
}) {
    const active = activeTab === tab;

    return (
        <TouchableOpacity
            activeOpacity={0.85}
            style={styles.tabButton}
            onPress={() => onChangeTab(tab)}
        >
            <View style={styles.iconWrap}>
                <MaterialCommunityIcons
                    name={icon}
                    size={25}
                    color={active ? "#148F5A" : "#606060"}
                />

                {badge && (
                    <View style={styles.badge}>
                        <Text style={styles.badgeText}>{badge}</Text>
                    </View>
                )}
            </View>

            <Text style={[styles.tabText, active && styles.tabTextActive]}>
                {label}
            </Text>
        </TouchableOpacity>
    );
}

export default function MobileBottomTabs({ activeTab, onChangeTab }: Props) {
    return (
        <View style={styles.bottomTabs}>
            <TabButton
                label="Chats"
                icon="message-processing-outline"
                tab="chats"
                activeTab={activeTab}
                onChangeTab={onChangeTab}
                badge="1"
            />

            <TabButton
                label="Vận hành"
                icon="clipboard-check-outline"
                tab="operation"
                activeTab={activeTab}
                onChangeTab={onChangeTab}
            />

            <TabButton
                label="Tài khoản"
                icon="account-circle"
                tab="account"
                activeTab={activeTab}
                onChangeTab={onChangeTab}
            />
        </View>
    );
}

const styles = StyleSheet.create({
    bottomTabs: {
        height: 66,
        backgroundColor: "#FFFFFF",
        borderTopWidth: 1,
        borderTopColor: "#E2E2E2",
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "space-around",
        paddingBottom: 4,
    },

    tabButton: {
        flex: 1,
        alignItems: "center",
        justifyContent: "center",
    },

    iconWrap: {
        position: "relative",
        marginBottom: 2,
    },

    badge: {
        position: "absolute",
        top: -7,
        right: -9,
        minWidth: 18,
        height: 18,
        borderRadius: 9,
        backgroundColor: "#FF0000",
        alignItems: "center",
        justifyContent: "center",
        paddingHorizontal: 4,
    },

    badgeText: {
        color: "#FFFFFF",
        fontSize: 10,
        fontWeight: "800",
    },

    tabText: {
        fontSize: 12,
        color: "#606060",
    },

    tabTextActive: {
        color: "#148F5A",
        fontWeight: "600",
    },
});
