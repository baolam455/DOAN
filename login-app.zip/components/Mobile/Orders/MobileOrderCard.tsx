import React from "react";
import { View, Text, TouchableOpacity, StyleSheet } from "react-native";
import { MaterialCommunityIcons } from "@expo/vector-icons";

import { Order, statusColor, statusIcon, statusLabel } from "../../../services/orderApi";

type Props = {
  order: Order;
  onPress: () => void;
};

function formatMoney(amount: number | null | undefined) {
  if (amount == null || isNaN(amount)) return "—";
  return amount.toLocaleString("vi-VN") + "đ";
}

function formatDate(value: string) {
  const date = new Date(value);
  return date.toLocaleDateString("vi-VN", {
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
  });
}

export default function MobileOrderCard({ order, onPress }: Props) {
  const color = statusColor(order.status);

  return (
    <TouchableOpacity activeOpacity={0.86} style={styles.card} onPress={onPress}>
      <View style={styles.header}>
        <View>
          <Text style={styles.orderCode}>{order.order_code}</Text>
          <Text style={styles.createdAt}>{formatDate(order.created_at)}</Text>
        </View>

        <View style={[styles.statusBadge, { backgroundColor: color + "18" }]}>
          <MaterialCommunityIcons name={statusIcon(order.status) as any} size={14} color={color} />
          <Text style={[styles.statusText, { color }]}>{statusLabel(order.status)}</Text>
        </View>
      </View>

      <View style={styles.receiverRow}>
        <MaterialCommunityIcons name="account-outline" size={18} color="#667085" />
        <View style={styles.receiverInfo}>
          <Text style={styles.receiverName}>{order.receiver_name}</Text>
          <Text style={styles.receiverSub}>
            {order.receiver_phone} · {order.receiver_province || "Chưa có tỉnh/TP"}
          </Text>
        </View>
      </View>

      <View style={styles.footer}>
        <View>
          <Text style={styles.productName} numberOfLines={1}>
            {order.product_name || "Sản phẩm"}
          </Text>
          <Text style={styles.productMeta}>
            {order.quantity} SP · {order.total_weight} kg
          </Text>
        </View>

        <View style={styles.moneyBox}>
          <Text style={styles.codLabel}>COD</Text>
          <Text style={styles.codValue}>{formatMoney(order.cod_amount)}</Text>
        </View>
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: "#FFFFFF",
    borderRadius: 12,
    padding: 14,
    marginBottom: 12,
  },

  header: {
    flexDirection: "row",
    alignItems: "flex-start",
    justifyContent: "space-between",
    marginBottom: 12,
  },

  orderCode: {
    fontSize: 15,
    fontWeight: "800",
    color: "#148F5A",
  },

  createdAt: {
    fontSize: 12,
    color: "#98A2B3",
    marginTop: 3,
  },

  statusBadge: {
    minHeight: 28,
    borderRadius: 14,
    paddingHorizontal: 9,
    flexDirection: "row",
    alignItems: "center",
  },

  statusText: {
    fontSize: 12,
    fontWeight: "800",
    marginLeft: 4,
  },

  receiverRow: {
    flexDirection: "row",
    alignItems: "center",
    borderBottomWidth: 1,
    borderBottomColor: "#F0F0F0",
    paddingBottom: 12,
  },

  receiverInfo: {
    flex: 1,
    marginLeft: 8,
  },

  receiverName: {
    fontSize: 14,
    fontWeight: "800",
    color: "#111827",
  },

  receiverSub: {
    fontSize: 12,
    color: "#667085",
    marginTop: 3,
  },

  footer: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingTop: 12,
  },

  productName: {
    maxWidth: 190,
    fontSize: 14,
    fontWeight: "700",
    color: "#111827",
  },

  productMeta: {
    fontSize: 12,
    color: "#98A2B3",
    marginTop: 3,
  },

  moneyBox: {
    alignItems: "flex-end",
  },

  codLabel: {
    fontSize: 11,
    color: "#98A2B3",
    fontWeight: "800",
  },

  codValue: {
    fontSize: 15,
    fontWeight: "700",
    color: "#111827",
  },
});
