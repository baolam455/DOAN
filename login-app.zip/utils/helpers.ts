/**
 * utils/helpers.ts
 * Các hàm tiện ích dùng chung trong toàn bộ app.
 * Thêm helper mới vào đây thay vì định nghĩa lại ở từng file.
 */
import { Alert, Platform } from "react-native";

/**
 * Hiển thị thông báo "Tính năng đang phát triển" (dùng thay navigate FeatureScreen).
 * Dùng Alert.alert cho cả web lẫn native — bỏ window.alert để nhất quán giữa platform.
 */
export function showComingSoon(title?: string): void {
  const featureName = title ? `"${title}"` : "Tính năng này";
  const msg = `${featureName} đang được phát triển và sẽ sớm ra mắt.`;
  Alert.alert("Sắp ra mắt", msg);
}

/**
 * Lấy 2 chữ viết tắt từ tên người dùng.
 * Ví dụ: "Nguyễn Minh Hiệp" → "NH", "Admin" → "AD"
 */
export function getInitials(name?: string, fallback = "KH"): string {
  const cleanName = (name || "").trim();

  if (!cleanName) return fallback;

  const words = cleanName.split(/\s+/).filter(Boolean);

  if (words.length >= 2) {
    return `${words[0][0]}${words[words.length - 1][0]}`.toUpperCase();
  }

  return cleanName.slice(0, 2).toUpperCase();
}

/**
 * Format số tiền sang định dạng VND.
 * Ví dụ: 540000 → "540.000đ", undefined/null → "—"
 * Nhận thêm null | undefined để tránh crash khi API trả về thiếu field.
 */
export function formatMoney(amount: number | null | undefined): string {
  if (amount == null || isNaN(amount)) return "—";
  return amount.toLocaleString("vi-VN") + "đ";
}

/**
 * Format ngày giờ sang dạng DD/MM/YYYY HH:MM.
 */
export function formatDate(dateStr: string): string {
  const d = new Date(dateStr);
  const day = String(d.getDate()).padStart(2, "0");
  const month = String(d.getMonth() + 1).padStart(2, "0");
  const year = d.getFullYear();
  const hours = String(d.getHours()).padStart(2, "0");
  const minutes = String(d.getMinutes()).padStart(2, "0");
  return `${day}/${month}/${year} ${hours}:${minutes}`;
}
