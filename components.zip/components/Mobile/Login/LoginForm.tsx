import React, { useState } from "react";
import {
    View,
    Text,
    TextInput,
    TouchableOpacity,
    StyleSheet,
} from "react-native";
import { MaterialCommunityIcons } from "@expo/vector-icons";

type LoginErrors = {
    account?: string;
    password?: string;
};

type Props = {
    account: string;
    password: string;
    errors?: LoginErrors;
    loading?: boolean;
    onChangeAccount: (value: string) => void;
    onChangePassword: (value: string) => void;
    onLoginPress: () => void;
};

function RequiredLabel({ label }: { label: string }) {
    return (
        <Text style={styles.label}>
            {label} <Text style={styles.requiredStar}>*</Text>
        </Text>
    );
}

function ErrorText({ message }: { message?: string }) {
    if (!message) {
        return null;
    }

    return <Text style={styles.errorText}>{message}</Text>;
}

export default function LoginForm({
    account,
    password,
    errors,
    loading = false,
    onChangeAccount,
    onChangePassword,
    onLoginPress,
}: Props) {
    const [showPassword, setShowPassword] = useState(false);

    const isDisabled =
        loading || account.trim() === "" || password.trim() === "";

    return (
        <View style={styles.form}>
            <View style={styles.inputBlock}>
                <RequiredLabel label="Số điện thoại hoặc email" />

                <TextInput
                    style={[styles.input, errors?.account && styles.inputError]}
                    placeholder="Nhập số điện thoại hoặc email"
                    placeholderTextColor="#C7C7C7"
                    value={account}
                    onChangeText={onChangeAccount}
                    keyboardType="email-address"
                    autoCapitalize="none"
                />

                <ErrorText message={errors?.account} />
            </View>

            <View style={styles.inputBlock}>
                <RequiredLabel label="Mật khẩu" />

                <View
                    style={[
                        styles.passwordBox,
                        errors?.password && styles.inputError,
                    ]}
                >
                    <TextInput
                        style={styles.passwordInput}
                        placeholder="Nhập mật khẩu"
                        placeholderTextColor="#C7C7C7"
                        value={password}
                        onChangeText={onChangePassword}
                        secureTextEntry={!showPassword}
                    />

                    <TouchableOpacity
                        activeOpacity={0.75}
                        style={styles.eyeButton}
                        onPress={() => setShowPassword((prev) => !prev)}
                    >
                        <MaterialCommunityIcons
                            name={showPassword ? "eye-off-outline" : "eye-outline"}
                            size={24}
                            color="#777777"
                        />
                    </TouchableOpacity>
                </View>

                <ErrorText message={errors?.password} />
            </View>

            <TouchableOpacity activeOpacity={0.8} style={styles.forgotButton}>
                <Text style={styles.forgotText}>Quên mật khẩu?</Text>
            </TouchableOpacity>

            <TouchableOpacity
                activeOpacity={0.85}
                style={[
                    styles.loginButton,
                    isDisabled && styles.loginButtonDisabled,
                ]}
                disabled={isDisabled}
                onPress={onLoginPress}
            >
                <Text style={styles.loginButtonText}>
                    {loading ? "Đang đăng nhập..." : "Đăng nhập"}
                </Text>
            </TouchableOpacity>
        </View>
    );
}

const styles = StyleSheet.create({
    form: {
        flex: 1,
        paddingHorizontal: 42,
        paddingTop: 34,
        backgroundColor: "#FFFFFF",
    },

    inputBlock: {
        marginBottom: 22,
    },

    label: {
        fontSize: 17,
        fontWeight: "700",
        color: "#565656",
        marginBottom: 10,
    },

    requiredStar: {
        color: "#E53935",
    },

    input: {
        height: 48,
        borderBottomWidth: 1,
        borderBottomColor: "#DADADA",
        fontSize: 18,
        color: "#111111",
        paddingVertical: 0,
    },

    inputError: {
        borderBottomColor: "#E53935",
    },

    errorText: {
        fontSize: 13,
        color: "#E53935",
        marginTop: 6,
    },

    passwordBox: {
        height: 48,
        borderBottomWidth: 1,
        borderBottomColor: "#DADADA",
        flexDirection: "row",
        alignItems: "center",
    },

    passwordInput: {
        flex: 1,
        height: 48,
        fontSize: 18,
        color: "#111111",
        paddingVertical: 0,
    },

    eyeButton: {
        width: 46,
        height: 48,
        alignItems: "center",
        justifyContent: "center",
    },

    forgotButton: {
        alignSelf: "flex-end",
        marginTop: -6,
        marginBottom: 38,
    },

    forgotText: {
        fontSize: 17,
        fontWeight: "700",
        color: "#00A650",
        textDecorationLine: "underline",
    },

    loginButton: {
        height: 52,
        borderRadius: 5,
        backgroundColor: "#00A650",
        alignItems: "center",
        justifyContent: "center",
    },

    loginButtonDisabled: {
        backgroundColor: "#DADADA",
    },

    loginButtonText: {
        fontSize: 19,
        fontWeight: "800",
        color: "#FFFFFF",
    },
});