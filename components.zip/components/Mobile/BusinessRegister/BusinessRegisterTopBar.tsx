import React from "react";
import { View, Text, TouchableOpacity, StyleSheet } from "react-native";

type Props = {
    onBackPress: () => void;
};

export default function BusinessRegisterTopBar({ onBackPress }: Props) {
    return (
        <View style={styles.topBar}>
            <TouchableOpacity
                activeOpacity={0.85}
                style={styles.backButton}
                onPress={onBackPress}
            >
                <Text style={styles.backIcon}>‹</Text>
            </TouchableOpacity>

            <Text style={styles.title} numberOfLines={1}>
                Đăng ký tài khoản doanh nghiệp
            </Text>
        </View>
    );
}

const styles = StyleSheet.create({
    topBar: {
        height: 88,
        backgroundColor: "#E0F5EA",
        flexDirection: "row",
        alignItems: "center",
        paddingHorizontal: 24,
    },

    backButton: {
        width: 52,
        height: 52,
        borderRadius: 26,
        backgroundColor: "#FFFFFF",
        justifyContent: "center",
        alignItems: "center",
        marginRight: 12,
    },

    backIcon: {
        fontSize: 42,
        lineHeight: 42,
        fontWeight: "800",
        color: "#169E4A",
        marginTop: 0,
    },

    title: {
        flex: 1,
        fontSize: 18,
        fontWeight: "700",
        color: "#111111",
    },
});