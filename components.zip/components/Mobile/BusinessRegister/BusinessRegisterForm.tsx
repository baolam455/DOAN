import React from "react";
import { View, Text, TextInput, TouchableOpacity, StyleSheet } from "react-native";

type Props = {
    fullName: string;
    phone: string;
    email: string;
    company: string;
    taxCode: string;
    agree: boolean;
    loading?: boolean;
    onChangeFullName: (value: string) => void;
    onChangePhone: (value: string) => void;
    onChangeEmail: (value: string) => void;
    onChangeCompany: (value: string) => void;
    onChangeTaxCode: (value: string) => void;
    onToggleAgree: () => void;
    onRegisterPress: () => void;
};

function RequiredLabel({ label }: { label: string }) {
    return (
        <Text style={styles.label}>
            {label} <Text style={styles.requiredStar}>*</Text>
        </Text>
    );
}

type FormInputProps = {
    label: string;
    placeholder: string;
    value: string;
    onChangeText: (value: string) => void;
    keyboardType?: "default" | "phone-pad" | "email-address";
};

function FormInput({
    label,
    placeholder,
    value,
    onChangeText,
    keyboardType = "default",
}: FormInputProps) {
    return (
        <View style={styles.inputBlock}>
            <RequiredLabel label={label} />

            <TextInput
                style={styles.input}
                placeholder={placeholder}
                placeholderTextColor="#C7C7C7"
                value={value}
                onChangeText={onChangeText}
                keyboardType={keyboardType}
                autoCapitalize={keyboardType === "email-address" ? "none" : "sentences"}
            />
        </View>
    );
}

export default function BusinessRegisterForm({
    fullName,
    phone,
    email,
    company,
    taxCode,
    agree,
    loading = false,
    onChangeFullName,
    onChangePhone,
    onChangeEmail,
    onChangeCompany,
    onChangeTaxCode,
    onToggleAgree,
    onRegisterPress,
}: Props) {
    const isDisabled =
        loading ||
        fullName.trim() === "" ||
        phone.trim() === "" ||
        email.trim() === "" ||
        company.trim() === "" ||
        taxCode.trim() === "" ||
        agree === false;

    return (
        <View style={styles.form}>
            <Text style={styles.introText}>
                Để được tư vấn và hỗ trợ tạo tài khoản đối tác, vui lòng nhập thông tin
                doanh nghiệp của bạn
            </Text>

            <FormInput
                label="Họ và tên"
                placeholder="Nhập họ và tên người liên hệ"
                value={fullName}
                onChangeText={onChangeFullName}
            />

            <FormInput
                label="Số điện thoại"
                placeholder="Nhập số điện thoại"
                value={phone}
                onChangeText={(text) => {
                    const onlyNumber = text.replace(/\D/g, "").slice(0, 10);
                    onChangePhone(onlyNumber);
                }}
                keyboardType="phone-pad"
            />

            <FormInput
                label="Email"
                placeholder="Nhập địa chỉ email"
                value={email}
                onChangeText={onChangeEmail}
                keyboardType="email-address"
            />

            <FormInput
                label="Tên công ty"
                placeholder="Nhập tên công ty"
                value={company}
                onChangeText={onChangeCompany}
            />

            <FormInput
                label="Mã số thuế"
                placeholder="Nhập mã số thuế"
                value={taxCode}
                onChangeText={onChangeTaxCode}
            />

            <TouchableOpacity
                activeOpacity={0.85}
                style={styles.agreeRow}
                onPress={onToggleAgree}
            >
                <View style={[styles.checkbox, agree && styles.checkboxActive]}>
                    {agree && <Text style={styles.checkboxTick}>✓</Text>}
                </View>

                <Text style={styles.agreeText}>
                    Tôi đã đọc và đồng ý với Điều khoản & Quy định và Chính sách bảo mật
                </Text>
            </TouchableOpacity>

            <TouchableOpacity
                activeOpacity={0.85}
                style={[
                    styles.registerButton,
                    isDisabled && styles.registerButtonDisabled,
                ]}
                disabled={isDisabled}
                onPress={onRegisterPress}
            >
                <Text style={styles.registerButtonText}>
                    {loading ? "Đang gửi..." : "Đăng ký"}
                </Text>
            </TouchableOpacity>

            <Text style={styles.supportText}>
                💬 Chat để được hỗ trợ hoặc Để lại SĐT để được hỗ trợ
            </Text>
        </View>
    );
}

const styles = StyleSheet.create({
    form: {
        flex: 1,
        backgroundColor: "#FFFFFF",
        paddingHorizontal: 28,
        paddingTop: 28,
    },

    introText: {
        fontSize: 16,
        lineHeight: 24,
        fontWeight: "600",
        color: "#111111",
        marginBottom: 26,
    },

    inputBlock: {
        marginBottom: 22,
    },

    label: {
        fontSize: 16,
        fontWeight: "700",
        color: "#5F5F5F",
        marginBottom: 8,
    },

    requiredStar: {
        color: "#E53935",
    },

    input: {
        height: 40,
        borderBottomWidth: 1,
        borderBottomColor: "#D6D6D6",
        fontSize: 18,
        color: "#111111",
        paddingVertical: 0,
    },

    agreeRow: {
        flexDirection: "row",
        alignItems: "flex-start",
        marginTop: 4,
        marginBottom: 18,
    },

    checkbox: {
        width: 16,
        height: 16,
        borderWidth: 1,
        borderColor: "#CFCFCF",
        backgroundColor: "#F5F5F5",
        marginRight: 10,
        marginTop: 2,
        alignItems: "center",
        justifyContent: "center",
    },

    checkboxActive: {
        backgroundColor: "#16B94E",
        borderColor: "#16B94E",
    },

    checkboxTick: {
        fontSize: 11,
        fontWeight: "900",
        color: "#FFFFFF",
        lineHeight: 12,
    },

    agreeText: {
        flex: 1,
        fontSize: 12,
        lineHeight: 17,
        color: "#9D9D9D",
    },

    registerButton: {
        height: 56,
        borderRadius: 6,
        backgroundColor: "#16B94E",
        justifyContent: "center",
        alignItems: "center",
        marginTop: "auto",
    },

    registerButtonDisabled: {
        backgroundColor: "#DDDDDD",
    },

    registerButtonText: {
        fontSize: 21,
        fontWeight: "800",
        color: "#FFFFFF",
    },

    supportText: {
        textAlign: "center",
        marginTop: 18,
        marginBottom: 30,
        fontSize: 14,
        fontWeight: "800",
        color: "#16B94E",
    },
});