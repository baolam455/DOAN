import React, { useState } from "react";
import {
    View,
    Text,
    TextInput,
    TouchableOpacity,
    StyleSheet,
} from "react-native";
import { MaterialCommunityIcons } from "@expo/vector-icons";

type Props = {
    storeName: string;
    phone: string;
    email: string;
    address: string;
    password: string;
    rePassword: string;
    agree: boolean;
    loading?: boolean;
    onChangeStoreName: (value: string) => void;
    onChangePhone: (value: string) => void;
    onChangeEmail: (value: string) => void;
    onChangeAddress: (value: string) => void;
    onChangePassword: (value: string) => void;
    onChangeRePassword: (value: string) => void;
    onToggleAgree: () => void;
    onRegisterPress: () => void;
};

function RequiredLabel({ label }: { label: string }) {
    return (
        <Text style={styles.label}>
            {label} <Text style={styles.requiredStar}>*</Text>
        </Text>
    );
}

type FormInputProps = {
    label: string;
    placeholder: string;
    value: string;
    onChangeText: (value: string) => void;
    secureTextEntry?: boolean;
    keyboardType?: "default" | "phone-pad" | "email-address";
};

function FormInput({
    label,
    placeholder,
    value,
    onChangeText,
    secureTextEntry = false,
    keyboardType = "default",
}: FormInputProps) {
    return (
        <View style={styles.inputBlock}>
            <RequiredLabel label={label} />

            <TextInput
                style={styles.input}
                placeholder={placeholder}
                placeholderTextColor="#C7C7C7"
                value={value}
                onChangeText={onChangeText}
                secureTextEntry={secureTextEntry}
                keyboardType={keyboardType}
                autoCapitalize={keyboardType === "email-address" ? "none" : "sentences"}
            />
        </View>
    );
}

function PasswordInput({
    label,
    placeholder,
    value,
    onChangeText,
}: {
    label: string;
    placeholder: string;
    value: string;
    onChangeText: (value: string) => void;
}) {
    const [visible, setVisible] = useState(false);

    return (
        <View style={styles.inputBlock}>
            <RequiredLabel label={label} />

            <View style={styles.passwordBox}>
                <TextInput
                    style={styles.passwordInput}
                    placeholder={placeholder}
                    placeholderTextColor="#C7C7C7"
                    value={value}
                    onChangeText={onChangeText}
                    secureTextEntry={!visible}
                />

                <TouchableOpacity
                    activeOpacity={0.75}
                    style={styles.eyeButton}
                    onPress={() => setVisible((prev) => !prev)}
                >
                    <MaterialCommunityIcons
                        name={visible ? "eye-off-outline" : "eye-outline"}
                        size={22}
                        color="#777777"
                    />
                </TouchableOpacity>
            </View>
        </View>
    );
}

export default function RegisterForm({
    storeName,
    phone,
    email,
    address,
    password,
    rePassword,
    agree,
    loading = false,
    onChangeStoreName,
    onChangePhone,
    onChangeEmail,
    onChangeAddress,
    onChangePassword,
    onChangeRePassword,
    onToggleAgree,
    onRegisterPress,
}: Props) {
    const isDisabled =
        loading ||
        storeName.trim() === "" ||
        phone.trim() === "" ||
        email.trim() === "" ||
        address.trim() === "" ||
        password.trim() === "" ||
        rePassword.trim() === "" ||
        agree === false;

    return (
        <View style={styles.form}>
            <FormInput
                label="Tên cửa hàng"
                placeholder="Nhập tên cửa hàng"
                value={storeName}
                onChangeText={onChangeStoreName}
            />

            <FormInput
                label="Số điện thoại"
                placeholder="Nhập số điện thoại"
                value={phone}
                onChangeText={(text) => {
                    const onlyNumber = text.replace(/\D/g, "").slice(0, 10);
                    onChangePhone(onlyNumber);
                }}
                keyboardType="phone-pad"
            />

            <FormInput
                label="Email"
                placeholder="Nhập địa chỉ email"
                value={email}
                onChangeText={onChangeEmail}
                keyboardType="email-address"
            />

            <FormInput
                label="Địa chỉ lấy hàng"
                placeholder="Nhập địa chỉ lấy hàng"
                value={address}
                onChangeText={onChangeAddress}
            />

            <PasswordInput
                label="Mật khẩu"
                placeholder="Nhập mật khẩu"
                value={password}
                onChangeText={onChangePassword}
            />

            <Text style={styles.passwordHint}>
                Mật khẩu gồm chữ hoa, chữ thường, số và ký tự đặc biệt
            </Text>

            <PasswordInput
                label="Xác nhận mật khẩu"
                placeholder="Nhập lại mật khẩu"
                value={rePassword}
                onChangeText={onChangeRePassword}
            />

            <TouchableOpacity
                activeOpacity={0.85}
                style={styles.agreeRow}
                onPress={onToggleAgree}
            >
                <View style={[styles.checkbox, agree && styles.checkboxActive]}>
                    {agree && <Text style={styles.checkboxTick}>✓</Text>}
                </View>

                <Text style={styles.agreeText}>
                    Tôi đã đọc và đồng ý với Điều khoản & Quy định và Chính sách bảo mật
                </Text>
            </TouchableOpacity>

            <TouchableOpacity
                activeOpacity={0.85}
                style={[
                    styles.registerButton,
                    isDisabled && styles.registerButtonDisabled,
                ]}
                disabled={isDisabled}
                onPress={onRegisterPress}
            >
                <Text style={styles.registerButtonText}>
                    {loading ? "Đang đăng ký..." : "Đăng ký"}
                </Text>
            </TouchableOpacity>

            <Text style={styles.supportText}>
                💬 Chat để được hỗ trợ hoặc Để lại SĐT để được hỗ trợ
            </Text>
        </View>
    );
}

const styles = StyleSheet.create({
    form: {
        flex: 1,
        backgroundColor: "#FFFFFF",
        paddingHorizontal: 28,
        paddingTop: 26,
    },

    inputBlock: {
        marginBottom: 10,
    },

    label: {
        fontSize: 15,
        fontWeight: "700",
        color: "#5F5F5F",
        marginBottom: 5,
    },

    requiredStar: {
        color: "#E53935",
    },

    input: {
        height: 36,
        borderBottomWidth: 1,
        borderBottomColor: "#D6D6D6",
        fontSize: 16,
        color: "#111111",
        paddingVertical: 0,
    },

    passwordBox: {
        height: 36,
        borderBottomWidth: 1,
        borderBottomColor: "#D6D6D6",
        flexDirection: "row",
        alignItems: "center",
    },

    passwordInput: {
        flex: 1,
        height: 36,
        fontSize: 16,
        color: "#111111",
        paddingVertical: 0,
    },

    eyeButton: {
        width: 42,
        height: 36,
        alignItems: "center",
        justifyContent: "center",
    },

    passwordHint: {
        fontSize: 11,
        color: "#8A8A8A",
        marginTop: -5,
        marginBottom: 8,
    },

    agreeRow: {
        flexDirection: "row",
        alignItems: "flex-start",
        marginTop: 12,
        marginBottom: 14,
    },

    checkbox: {
        width: 16,
        height: 16,
        borderWidth: 1,
        borderColor: "#CFCFCF",
        backgroundColor: "#F5F5F5",
        marginRight: 10,
        marginTop: 2,
        alignItems: "center",
        justifyContent: "center",
    },

    checkboxActive: {
        backgroundColor: "#16B94E",
        borderColor: "#16B94E",
    },

    checkboxTick: {
        fontSize: 11,
        fontWeight: "900",
        color: "#FFFFFF",
        lineHeight: 12,
    },

    agreeText: {
        flex: 1,
        fontSize: 12,
        lineHeight: 17,
        color: "#9D9D9D",
    },

    registerButton: {
        height: 56,
        borderRadius: 6,
        backgroundColor: "#16B94E",
        justifyContent: "center",
        alignItems: "center",
    },

    registerButtonDisabled: {
        backgroundColor: "#DDDDDD",
    },

    registerButtonText: {
        fontSize: 21,
        fontWeight: "800",
        color: "#FFFFFF",
    },

    supportText: {
        textAlign: "center",
        marginTop: 14,
        fontSize: 13,
        fontWeight: "800",
        color: "#16B94E",
    },
});