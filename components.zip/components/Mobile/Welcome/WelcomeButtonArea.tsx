import React from "react";
import { View, Text, TouchableOpacity, StyleSheet } from "react-native";

type Props = {
    onLoginPress: () => void;
    onRegisterPress: () => void;
    onBusinessRegisterPress: () => void;
};

export default function WelcomeButtonArea({
    onLoginPress,
    onRegisterPress,
    onBusinessRegisterPress,
}: Props) {
    return (
        <View style={styles.buttonArea}>
            <TouchableOpacity
                activeOpacity={0.85}
                style={styles.whiteButton}
                onPress={onLoginPress}
            >
                <Text style={styles.whiteButtonText}>Đăng nhập</Text>
            </TouchableOpacity>

            <TouchableOpacity
                activeOpacity={0.85}
                style={styles.whiteButton}
                onPress={onRegisterPress}
            >
                <Text style={styles.whiteButtonText}>Đăng ký</Text>
            </TouchableOpacity>

            <TouchableOpacity
                activeOpacity={0.85}
                style={styles.greenButton}
                onPress={onBusinessRegisterPress}
            >
                <Text style={styles.greenButtonText}>
                    Đăng ký tài khoản doanh nghiệp
                </Text>
            </TouchableOpacity>

            <Text style={styles.supportText}>💬 Chat để được hỗ trợ</Text>
        </View>
    );
}

const styles = StyleSheet.create({
    buttonArea: {
        width: "100%",
        paddingHorizontal: 28,
        paddingBottom: 34,
    },

    whiteButton: {
        width: "100%",
        height: 54,
        borderRadius: 7,
        backgroundColor: "#FFF3F4",
        justifyContent: "center",
        alignItems: "center",
        marginBottom: 14,
    },

    whiteButtonText: {
        fontSize: 19,
        fontWeight: "800",
        color: "#111111",
    },

    greenButton: {
        width: "100%",
        height: 54,
        borderRadius: 7,
        backgroundColor: "#16B94E",
        justifyContent: "center",
        alignItems: "center",
        marginBottom: 15,
    },

    greenButtonText: {
        fontSize: 18,
        fontWeight: "800",
        color: "#111111",
    },

    supportText: {
        textAlign: "center",
        fontSize: 13,
        fontWeight: "700",
        color: "#FFFFFF",
    },
});