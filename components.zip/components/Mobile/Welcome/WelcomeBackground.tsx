import React from "react";
import { View, StyleSheet } from "react-native";
import { Image } from "expo-image";

type Props = {
    children: React.ReactNode;
};

export default function WelcomeBackground({ children }: Props) {
    return (
        <View style={styles.container}>
            <Image
                source={require("../../../assets/warehouse.jpg")}
                style={styles.image}
                contentFit="cover"
                cachePolicy="memory-disk"
                transition={0}
            />

            <View style={styles.overlay} />

            <View style={styles.content}>{children}</View>
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: "#000000",
    },

    image: {
        ...StyleSheet.absoluteFillObject,
    },

    overlay: {
        ...StyleSheet.absoluteFillObject,
        backgroundColor: "rgba(0,0,0,0.24)",
    },

    content: {
        flex: 1,
        justifyContent: "flex-end",
    },
});