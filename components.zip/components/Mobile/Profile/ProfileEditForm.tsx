import React, { useState } from "react";
import {
    View,
    Text,
    TextInput,
    TouchableOpacity,
    StyleSheet,
    ActivityIndicator,
    Alert,
} from "react-native";
import { MaterialCommunityIcons } from "@expo/vector-icons";
import { CustomerProfile, updateProfile } from "../../../services/customerApi";

type Props = {
    profile: CustomerProfile;
    onUpdated: (updated: CustomerProfile) => void;
    onCancel: () => void;
};

export default function ProfileEditForm({ profile, onUpdated, onCancel }: Props) {
    const [fullName, setFullName] = useState(profile.full_name || "");
    const [phone, setPhone]       = useState(profile.phone    || "");
    const [address, setAddress]   = useState(profile.address  || "");
    const [loading, setLoading]   = useState(false);
    const [error, setError]       = useState("");

    const handleSave = async () => {
        setError("");
        setLoading(true);
        try {
            const updated = await updateProfile({ full_name: fullName, phone, address });
            onUpdated(updated);
            Alert.alert("Thành công", "Đã cập nhật thông tin tài khoản");
        } catch (e: any) {
            setError(e.message || "Cập nhật thất bại");
        } finally {
            setLoading(false);
        }
    };

    return (
        <View style={styles.container}>
            <Text style={styles.sectionTitle}>Chỉnh sửa thông tin</Text>

            <InputField
                icon="account-outline"
                label="Họ và tên"
                value={fullName}
                onChangeText={setFullName}
                placeholder="Nhập họ và tên"
            />
            <InputField
                icon="phone-outline"
                label="Số điện thoại"
                value={phone}
                onChangeText={setPhone}
                placeholder="Nhập số điện thoại"
                keyboardType="phone-pad"
            />
            <InputField
                icon="map-marker-outline"
                label="Địa chỉ"
                value={address}
                onChangeText={setAddress}
                placeholder="Nhập địa chỉ"
                multiline
            />

            {error ? <Text style={styles.errorText}>{error}</Text> : null}

            <View style={styles.btnRow}>
                <TouchableOpacity
                    style={styles.btnCancel}
                    onPress={onCancel}
                    disabled={loading}
                    activeOpacity={0.8}
                >
                    <Text style={styles.btnCancelText}>Hủy</Text>
                </TouchableOpacity>

                <TouchableOpacity
                    style={styles.btnSave}
                    onPress={handleSave}
                    disabled={loading}
                    activeOpacity={0.8}
                >
                    {loading ? (
                        <ActivityIndicator size="small" color="#fff" />
                    ) : (
                        <>
                            <MaterialCommunityIcons name="check" size={18} color="#fff" />
                            <Text style={styles.btnSaveText}>Lưu</Text>
                        </>
                    )}
                </TouchableOpacity>
            </View>
        </View>
    );
}

function InputField({
    icon,
    label,
    value,
    onChangeText,
    placeholder,
    keyboardType,
    multiline,
}: {
    icon: any;
    label: string;
    value: string;
    onChangeText: (t: string) => void;
    placeholder?: string;
    keyboardType?: any;
    multiline?: boolean;
}) {
    return (
        <View style={styles.inputGroup}>
            <Text style={styles.inputLabel}>
                <MaterialCommunityIcons name={icon} size={13} color="#4E9858" />
                {"  "}{label}
            </Text>
            <TextInput
                style={[styles.input, multiline && styles.inputMulti]}
                value={value}
                onChangeText={onChangeText}
                placeholder={placeholder}
                placeholderTextColor="#BDBDBD"
                keyboardType={keyboardType}
                multiline={multiline}
            />
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        backgroundColor: "#FFFFFF",
        borderRadius: 16,
        padding: 20,
        marginHorizontal: 16,
        marginTop: 12,
        shadowColor: "#000",
        shadowOpacity: 0.07,
        shadowRadius: 8,
        elevation: 2,
    },
    sectionTitle: {
        fontSize: 15,
        fontWeight: "700",
        color: "#111111",
        marginBottom: 16,
    },
    inputGroup: {
        marginBottom: 16,
    },
    inputLabel: {
        fontSize: 12,
        color: "#666666",
        fontWeight: "600",
        marginBottom: 6,
    },
    input: {
        borderWidth: 1.5,
        borderColor: "#E0E0E0",
        borderRadius: 10,
        paddingHorizontal: 14,
        paddingVertical: 11,
        fontSize: 15,
        color: "#111111",
        backgroundColor: "#FAFAFA",
    },
    inputMulti: {
        minHeight: 72,
        textAlignVertical: "top",
    },
    errorText: {
        color: "#E53935",
        fontSize: 13,
        marginBottom: 12,
    },
    btnRow: {
        flexDirection: "row",
        gap: 10,
        marginTop: 4,
    },
    btnCancel: {
        flex: 1,
        borderWidth: 1.5,
        borderColor: "#CCCCCC",
        borderRadius: 10,
        paddingVertical: 13,
        justifyContent: "center",
        alignItems: "center",
    },
    btnCancelText: {
        color: "#555555",
        fontSize: 15,
        fontWeight: "600",
    },
    btnSave: {
        flex: 2,
        backgroundColor: "#4E9858",
        borderRadius: 10,
        paddingVertical: 13,
        flexDirection: "row",
        justifyContent: "center",
        alignItems: "center",
        gap: 6,
    },
    btnSaveText: {
        color: "#FFFFFF",
        fontSize: 15,
        fontWeight: "600",
    },
});
