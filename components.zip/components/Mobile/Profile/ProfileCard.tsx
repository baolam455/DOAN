import React from "react";
import { View, Text, StyleSheet } from "react-native";
import { MaterialCommunityIcons } from "@expo/vector-icons";
import { CustomerProfile } from "../../../services/customerApi";

type Props = {
    profile: CustomerProfile;
};

const ROLE_LABEL: Record<string, string> = {
    customer: "Khách hàng",
    shipper: "Shipper",
    admin: "Quản trị viên",
};

export default function ProfileCard({ profile }: Props) {
    const joinDate = profile.created_at
        ? new Date(profile.created_at).toLocaleDateString("vi-VN")
        : "—";

    return (
        <View style={styles.card}>
            {/* Avatar */}
            <View style={styles.avatarRow}>
                <View style={styles.avatarCircle}>
                    <Text style={styles.avatarText}>
                        {(profile.full_name || "?")[0].toUpperCase()}
                    </Text>
                </View>
                <View style={styles.avatarInfo}>
                    <Text style={styles.nameText}>{profile.full_name || "—"}</Text>
                    <View style={styles.roleBadge}>
                        <Text style={styles.roleText}>
                            {ROLE_LABEL[profile.role] || profile.role}
                        </Text>
                    </View>
                </View>
            </View>

            <View style={styles.divider} />

            <InfoRow icon="phone-outline"      label="Số điện thoại" value={profile.phone   || "Chưa cập nhật"} />
            <InfoRow icon="map-marker-outline" label="Địa chỉ"       value={profile.address || "Chưa cập nhật"} />
            <InfoRow icon="calendar-outline"   label="Ngày tham gia" value={joinDate} />
        </View>
    );
}

function InfoRow({
    icon,
    label,
    value,
}: {
    icon: any;
    label: string;
    value: string;
}) {
    return (
        <View style={styles.row}>
            <View style={styles.iconBox}>
                <MaterialCommunityIcons name={icon} size={18} color="#4E9858" />
            </View>
            <View style={styles.rowContent}>
                <Text style={styles.rowLabel}>{label}</Text>
                <Text style={styles.rowValue}>{value}</Text>
            </View>
        </View>
    );
}

const styles = StyleSheet.create({
    card: {
        backgroundColor: "#FFFFFF",
        borderRadius: 16,
        padding: 20,
        marginHorizontal: 16,
        marginTop: 8,
        shadowColor: "#000",
        shadowOpacity: 0.07,
        shadowRadius: 8,
        elevation: 2,
    },
    avatarRow: {
        flexDirection: "row",
        alignItems: "center",
        gap: 14,
        marginBottom: 16,
    },
    avatarCircle: {
        width: 60,
        height: 60,
        borderRadius: 30,
        backgroundColor: "#4E9858",
        justifyContent: "center",
        alignItems: "center",
    },
    avatarText: {
        color: "#FFFFFF",
        fontSize: 24,
        fontWeight: "700",
    },
    avatarInfo: {
        flex: 1,
    },
    nameText: {
        fontSize: 17,
        fontWeight: "700",
        color: "#111111",
        marginBottom: 4,
    },
    roleBadge: {
        backgroundColor: "#E8F6EA",
        borderRadius: 6,
        paddingHorizontal: 10,
        paddingVertical: 2,
        alignSelf: "flex-start",
    },
    roleText: {
        fontSize: 12,
        color: "#4E9858",
        fontWeight: "600",
    },
    divider: {
        height: 1,
        backgroundColor: "#F0F0F0",
        marginBottom: 14,
    },
    row: {
        flexDirection: "row",
        alignItems: "flex-start",
        gap: 12,
        marginBottom: 14,
    },
    iconBox: {
        width: 32,
        height: 32,
        borderRadius: 8,
        backgroundColor: "#F5F5F5",
        justifyContent: "center",
        alignItems: "center",
        marginTop: 1,
    },
    rowContent: {
        flex: 1,
    },
    rowLabel: {
        fontSize: 11,
        color: "#9E9E9E",
        fontWeight: "500",
        textTransform: "uppercase",
        letterSpacing: 0.4,
        marginBottom: 2,
    },
    rowValue: {
        fontSize: 15,
        color: "#222222",
        fontWeight: "500",
    },
});
