import React from "react";
import {
    ScrollView,
    View,
    Text,
    TouchableOpacity,
    StyleSheet,
} from "react-native";
import { MaterialCommunityIcons } from "@expo/vector-icons";

type Props = {
    name: string;
    email: string;
    initials: string;
    onLogout: () => void;
};

function Chevron() {
    return (
        <MaterialCommunityIcons name="chevron-right" size={24} color="#111111" />
    );
}

function MiniLineChart() {
    return (
        <View style={styles.lineChart}>
            <View style={[styles.lineBar, { width: "38%", bottom: 42 }]} />
            <View style={[styles.lineBar, { width: "62%", bottom: 58 }]} />
            <View style={[styles.lineBar, { width: "86%", bottom: 76 }]} />

            <View style={[styles.lineBarLight, { width: "38%", bottom: 28 }]} />
            <View style={[styles.lineBarLight, { width: "62%", bottom: 42 }]} />
            <View style={[styles.lineBarLight, { width: "86%", bottom: 60 }]} />
        </View>
    );
}

function CashChart() {
    return (
        <View style={styles.cashChart}>
            <View style={[styles.cashLine, { width: 48, bottom: 18 }]} />
            <View style={[styles.cashLine, { width: 85, bottom: 32 }]} />
            <View style={[styles.cashLine, { width: 122, bottom: 28 }]} />
            <View style={[styles.cashLine, { width: 158, bottom: 46 }]} />

            <View style={[styles.cashLineLight, { width: 48, bottom: 10 }]} />
            <View style={[styles.cashLineLight, { width: 85, bottom: 20 }]} />
            <View style={[styles.cashLineLight, { width: 122, bottom: 19 }]} />
            <View style={[styles.cashLineLight, { width: 158, bottom: 36 }]} />
        </View>
    );
}

function ProductBars() {
    return (
        <View style={styles.productBars}>
            <View style={[styles.productBar, styles.productBarLight, { width: 90 }]} />
            <View style={[styles.productBar, { width: 66 }]} />
            <View style={[styles.productBar, styles.productBarDark, { width: 132 }]} />
        </View>
    );
}

function MenuRow({
    icon,
    title,
    highlight,
}: {
    icon: any;
    title: string;
    highlight?: string;
}) {
    return (
        <TouchableOpacity activeOpacity={0.85} style={styles.menuRow}>
            <MaterialCommunityIcons name={icon} size={23} color="#111111" />

            <View style={styles.menuTitleWrap}>
                <Text style={styles.menuTitle}>
                    {title}
                    {highlight && <Text style={styles.greenText}> {highlight}</Text>}
                </Text>
            </View>

            <Chevron />
        </TouchableOpacity>
    );
}

export default function MobileAccountTab({
    name,
    email,
    initials,
    onLogout,
}: Props) {
    return (
        <ScrollView
            style={styles.screen}
            contentContainerStyle={styles.content}
            showsVerticalScrollIndicator={false}
        >
            <View style={styles.profileRow}>
                <View style={styles.avatar}>
                    <Text style={styles.avatarText}>{initials}</Text>
                </View>

                <TouchableOpacity activeOpacity={0.85} style={styles.profileNameWrap}>
                    <Text style={styles.profileName}>{name}</Text>
                    <MaterialCommunityIcons name="chevron-right" size={22} color="#555555" />
                </TouchableOpacity>

                <TouchableOpacity activeOpacity={0.85} style={styles.switchIcon}>
                    <MaterialCommunityIcons
                        name="account-switch-outline"
                        size={25}
                        color="#111111"
                    />
                </TouchableOpacity>
            </View>

            <View style={styles.operationCard}>
                <View style={styles.cardHeader}>
                    <Text style={styles.sectionTitle}>Vận hành</Text>
                    <Chevron />
                </View>

                <View style={styles.operationStats}>
                    <View>
                        <Text style={styles.bigNumber}>0 / 0 ĐH</Text>
                        <Text style={styles.grayText}>Doanh thu / Lợi nhuận</Text>
                    </View>

                    <View>
                        <Text style={styles.bigNumber}>0 ĐH</Text>
                        <Text style={styles.grayText}>Đã giao</Text>
                    </View>
                </View>

                <MiniLineChart />
            </View>

            <View style={styles.twoCardsRow}>
                <View style={styles.smallCard}>
                    <View style={styles.cardHeader}>
                        <Text style={styles.sectionTitle}>Dòng tiền</Text>
                        <Chevron />
                    </View>

                    <Text style={styles.bigNumber}>0 đ</Text>
                    <Text style={styles.grayText}>Phí dịch vụ</Text>

                    <Text style={[styles.bigNumber, styles.moneySecond]}>0 đ</Text>
                    <Text style={styles.grayText}>Tiền về</Text>

                    <CashChart />
                </View>

                <View style={styles.smallCard}>
                    <View style={styles.cardHeader}>
                        <Text style={styles.sectionTitle}>Sản phẩm</Text>
                        <Chevron />
                    </View>

                    <View style={styles.productStats}>
                        <View>
                            <Text style={styles.bigNumber}>0 ĐH</Text>
                            <Text style={styles.grayText}>Đặt mua</Text>
                        </View>

                        <View>
                            <Text style={styles.bigNumber}>0 ĐH</Text>
                            <Text style={styles.grayText}>Đã bán</Text>
                        </View>
                    </View>

                    <Text style={[styles.bigNumber, styles.stockNumber]}>0 ĐH</Text>
                    <Text style={styles.grayText}>Tồn kho</Text>

                    <ProductBars />
                </View>
            </View>

            <TouchableOpacity activeOpacity={0.85} style={styles.walletCard}>
                <Text style={styles.walletTitle}>Ví GHTKPay</Text>

                <View style={styles.walletRight}>
                    <Text style={styles.activateText}>Kích hoạt ví</Text>
                    <Chevron />
                </View>
            </TouchableOpacity>

            <View style={styles.menuCard}>
                <MenuRow icon="archive-outline" title="Quản lý sản phẩm" />
                <MenuRow icon="cash" title="Quản lý tiền & đối soát" />
                <MenuRow icon="warehouse" title="Quản lý kho hàng & trả hàng" />
                <MenuRow icon="receipt-text-outline" title="Quản lý hoá đơn VAT" />
                <MenuRow icon="account-group-outline" title="Quản lý nhóm tài khoản" />
                <MenuRow icon="link-variant" title="Quản lý liên kết" />
                <MenuRow icon="cellphone-link" title="Quản lý thiết bị" highlight="Kích hoạt" />
                <MenuRow icon="file-document-edit-outline" title="Quản lý mẫu xuất báo cáo" />
                <MenuRow icon="cog-sync-outline" title="Cấu hình vận hành" />
                <MenuRow icon="cog-outline" title="Cài đặt" />
                <MenuRow icon="chat-processing-outline" title="Công cụ hỗ trợ chat" />
                <MenuRow icon="shield-account-outline" title="Quản lý quyền riêng tư" />
            </View>

            <View style={styles.menuCard}>
                <MenuRow icon="magnify" title="Tra cứu bưu cục" />
                <MenuRow icon="file-document-outline" title="Điều khoản và quy định" />
            </View>

            <TouchableOpacity
                activeOpacity={0.85}
                style={styles.logoutCard}
                onPress={onLogout}
            >
                <View style={styles.logoutLeft}>
                    <MaterialCommunityIcons name="logout" size={24} color="#F04A3A" />
                    <Text style={styles.logoutText}>Đăng xuất</Text>
                </View>

                <Text style={styles.versionText}>Version 2.1.03</Text>
            </TouchableOpacity>

            <Text style={styles.hiddenEmail}>{email}</Text>
        </ScrollView>
    );
}

const styles = StyleSheet.create({
    screen: {
        flex: 1,
        backgroundColor: "#F4F4F4",
    },

    content: {
        paddingHorizontal: 14,
        paddingTop: 18,
        paddingBottom: 88,
    },

    profileRow: {
        flexDirection: "row",
        alignItems: "center",
        marginBottom: 22,
        paddingHorizontal: 8,
    },

    avatar: {
        width: 68,
        height: 68,
        borderRadius: 34,
        backgroundColor: "#00A650",
        alignItems: "center",
        justifyContent: "center",
        marginRight: 14,
    },

    avatarText: {
        fontSize: 22,
        fontWeight: "700",
        color: "#FFFFFF",
    },

    profileNameWrap: {
        flexDirection: "row",
        alignItems: "center",
        flex: 1,
    },

    profileName: {
        fontSize: 20,
        fontWeight: "700",
        color: "#111111",
    },

    switchIcon: {
        padding: 6,
    },

    operationCard: {
        backgroundColor: "#FFFFFF",
        borderRadius: 12,
        padding: 18,
        marginBottom: 12,
    },

    cardHeader: {
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "space-between",
    },

    sectionTitle: {
        fontSize: 18,
        fontWeight: "800",
        color: "#111111",
    },

    operationStats: {
        flexDirection: "row",
        justifyContent: "space-between",
        marginTop: 14,
    },

    bigNumber: {
        fontSize: 16,
        fontWeight: "600",
        color: "#111111",
    },

    grayText: {
        fontSize: 13,
        color: "#9A9A9A",
        marginTop: 2,
    },

    lineChart: {
        height: 120,
        marginTop: 20,
        backgroundColor: "#EDF8EE",
        overflow: "hidden",
    },

    lineBar: {
        position: "absolute",
        left: 0,
        height: 3,
        backgroundColor: "#1FC567",
    },

    lineBarLight: {
        position: "absolute",
        left: 0,
        height: 3,
        backgroundColor: "#6FE19B",
    },

    twoCardsRow: {
        flexDirection: "row",
        gap: 10,
        marginBottom: 12,
    },

    smallCard: {
        flex: 1,
        minHeight: 224,
        backgroundColor: "#FFFFFF",
        borderRadius: 12,
        padding: 16,
    },

    moneySecond: {
        marginTop: 14,
    },

    cashChart: {
        height: 62,
        marginTop: 14,
        borderTopWidth: 1,
        borderBottomWidth: 1,
        borderColor: "#E8E8E8",
    },

    cashLine: {
        position: "absolute",
        left: 0,
        height: 3,
        backgroundColor: "#1FC567",
    },

    cashLineLight: {
        position: "absolute",
        left: 0,
        height: 3,
        backgroundColor: "#75DFA0",
    },

    productStats: {
        flexDirection: "row",
        justifyContent: "space-between",
        marginTop: 14,
    },

    stockNumber: {
        marginTop: 14,
    },

    productBars: {
        marginTop: 18,
    },

    productBar: {
        height: 10,
        backgroundColor: "#39C96D",
        marginBottom: 6,
    },

    productBarLight: {
        backgroundColor: "#E5F5EA",
    },

    productBarDark: {
        backgroundColor: "#4FA574",
    },

    walletCard: {
        height: 66,
        borderRadius: 12,
        backgroundColor: "#FFFFFF",
        paddingHorizontal: 18,
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "space-between",
        marginBottom: 12,
    },

    walletTitle: {
        fontSize: 18,
        color: "#111111",
        fontWeight: "600",
    },

    walletRight: {
        flexDirection: "row",
        alignItems: "center",
    },

    activateText: {
        fontSize: 16,
        color: "#00A650",
        fontWeight: "700",
        marginRight: 4,
    },

    menuCard: {
        backgroundColor: "#FFFFFF",
        borderRadius: 12,
        paddingHorizontal: 18,
        marginBottom: 12,
    },

    menuRow: {
        minHeight: 58,
        borderBottomWidth: 1,
        borderBottomColor: "#E7E7E7",
        flexDirection: "row",
        alignItems: "center",
    },

    menuTitleWrap: {
        flex: 1,
        marginLeft: 14,
    },

    menuTitle: {
        fontSize: 15,
        color: "#111111",
    },

    greenText: {
        color: "#00A650",
        fontWeight: "700",
    },

    logoutCard: {
        height: 66,
        backgroundColor: "#FFFFFF",
        borderRadius: 12,
        paddingHorizontal: 18,
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "space-between",
    },

    logoutLeft: {
        flexDirection: "row",
        alignItems: "center",
    },

    logoutText: {
        fontSize: 16,
        color: "#F04A3A",
        marginLeft: 10,
        fontWeight: "600",
    },

    versionText: {
        fontSize: 13,
        color: "#8A8A8A",
    },

    hiddenEmail: {
        height: 0,
        opacity: 0,
    },
});