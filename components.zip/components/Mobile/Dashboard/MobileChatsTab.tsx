import React from "react";
import { View, Text, StyleSheet } from "react-native";

export default function MobileChatsTab() {
    return (
        <View style={styles.screen}>
            <Text style={styles.title}>Chats</Text>

            <View style={styles.emptyBox}>
                <Text style={styles.emptyText}>Chưa có tin nhắn</Text>
            </View>
        </View>
    );
}

const styles = StyleSheet.create({
    screen: {
        flex: 1,
        backgroundColor: "#F4F4F4",
        paddingHorizontal: 24,
        paddingTop: 32,
    },

    title: {
        fontSize: 34,
        fontWeight: "800",
        color: "#111111",
    },

    emptyBox: {
        flex: 1,
        alignItems: "center",
        justifyContent: "center",
    },

    emptyText: {
        fontSize: 22,
        color: "#9A9A9A",
    },
});