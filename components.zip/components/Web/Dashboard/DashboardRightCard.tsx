import React from "react";
import { View, Text, TouchableOpacity, StyleSheet } from "react-native";

type Props = {
    title: string;
    onPress?: () => void;
};

function SmallTabs() {
    return (
        <View style={styles.tabs}>
            <TouchableOpacity style={[styles.tabItem, styles.tabActive]}>
                <Text style={[styles.tabText, styles.tabTextActive]}>Bán chạy</Text>
            </TouchableOpacity>

            <TouchableOpacity style={styles.tabItem}>
                <Text style={styles.tabText}>Hoàn cao</Text>
            </TouchableOpacity>
        </View>
    );
}

export default function DashboardRightCard({ title, onPress }: Props) {
    return (
        <TouchableOpacity
            activeOpacity={0.9}
            style={styles.rightCard}
            onPress={onPress}
        >
            <View style={styles.rightCardHeader}>
                <Text style={styles.rightTitle}>{title}</Text>
                <SmallTabs />
            </View>

            <View style={styles.emptyBox}>
                <Text style={styles.emptyText}>Đang cập nhật dữ liệu</Text>
            </View>
        </TouchableOpacity>
    );
}

const styles = StyleSheet.create({
    rightCard: {
        height: 360,
        backgroundColor: "#FFFFFF",
        borderRadius: 8,
        padding: 22,
        marginBottom: 14,
    },

    rightCardHeader: {
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "space-between",
    },

    rightTitle: {
        fontSize: 17,
        fontWeight: "600",
        color: "#111111",
    },

    tabs: {
        height: 34,
        backgroundColor: "#F7F7F7",
        borderRadius: 7,
        flexDirection: "row",
        padding: 2,
    },

    tabItem: {
        height: 30,
        paddingHorizontal: 17,
        borderRadius: 6,
        justifyContent: "center",
        alignItems: "center",
    },

    tabActive: {
        backgroundColor: "#FFFFFF",
    },

    tabText: {
        fontSize: 14,
        color: "#111111",
        fontWeight: "600",
    },

    tabTextActive: {
        color: "#2E9E4F",
    },

    emptyBox: {
        flex: 1,
        alignItems: "center",
        justifyContent: "center",
    },

    emptyText: {
        fontSize: 16,
        fontWeight: "400",
        color: "#111111",
    },
});