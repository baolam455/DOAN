import React from "react";
import { View, Text, TouchableOpacity, StyleSheet } from "react-native";

type Props = {
    onPress?: () => void;
};

export default function DashboardTrendChart({ onPress }: Props) {
    return (
        <TouchableOpacity
            activeOpacity={0.9}
            style={styles.bigCard}
            onPress={onPress}
        >
            <View style={styles.chartHeader}>
                <Text style={styles.cardTitle}>Xu hướng hàng - tiền</Text>

                <View style={styles.chartTabs}>
                    <TouchableOpacity style={styles.chartTab}>
                        <Text style={styles.chartTabText}>Dòng tiền</Text>
                    </TouchableOpacity>

                    <TouchableOpacity style={[styles.chartTab, styles.chartTabActive]}>
                        <Text style={[styles.chartTabText, styles.chartTabTextActive]}>
                            ĐH & SP
                        </Text>
                    </TouchableOpacity>
                </View>
            </View>

            <View style={styles.chartBox}>
                {[5, 4, 3, 2, 1, 0].map((item) => (
                    <View key={item} style={styles.chartLineRow}>
                        <Text style={styles.chartNumber}>{item}</Text>
                        <View style={styles.chartLine} />
                        <Text style={styles.chartPercent}>{item}%</Text>
                    </View>
                ))}

                <View style={styles.legendRow}>
                    <View style={styles.legendItem}>
                        <View style={styles.legendDash} />
                        <Text style={styles.legendText}>Tỷ lệ hoàn</Text>
                    </View>

                    <View style={styles.legendItem}>
                        <View style={styles.legendDash} />
                        <Text style={styles.legendText}>Đơn hàng</Text>
                    </View>

                    <View style={styles.legendItem}>
                        <View style={styles.legendDash} />
                        <Text style={styles.legendText}>Sản phẩm</Text>
                    </View>
                </View>
            </View>
        </TouchableOpacity>
    );
}

const styles = StyleSheet.create({
    bigCard: {
        backgroundColor: "#FFFFFF",
        borderRadius: 8,
        padding: 22,
        marginBottom: 14,
    },

    cardTitle: {
        fontSize: 17,
        fontWeight: "600",
        color: "#111111",
    },

    chartHeader: {
        flexDirection: "row",
        justifyContent: "space-between",
        alignItems: "center",
    },

    chartTabs: {
        height: 36,
        backgroundColor: "#F7F7F7",
        borderRadius: 7,
        flexDirection: "row",
        padding: 2,
    },

    chartTab: {
        height: 32,
        paddingHorizontal: 18,
        borderRadius: 6,
        justifyContent: "center",
    },

    chartTabActive: {
        backgroundColor: "#FFFFFF",
    },

    chartTabText: {
        fontSize: 14,
        color: "#111111",
        fontWeight: "600",
    },

    chartTabTextActive: {
        color: "#2E9E4F",
    },

    chartBox: {
        height: 430,
        marginTop: 28,
        paddingBottom: 16,
    },

    chartLineRow: {
        flexDirection: "row",
        alignItems: "center",
        height: 56,
    },

    chartNumber: {
        width: 25,
        fontSize: 13,
        color: "#999999",
    },

    chartLine: {
        flex: 1,
        height: 1,
        borderTopWidth: 1,
        borderTopColor: "#DDDDDD",
        borderStyle: "dashed",
    },

    chartPercent: {
        width: 35,
        fontSize: 13,
        color: "#999999",
        textAlign: "right",
    },

    legendRow: {
        flexDirection: "row",
        alignItems: "center",
        marginTop: 16,
        paddingLeft: 25,
    },

    legendItem: {
        flexDirection: "row",
        alignItems: "center",
        marginRight: 30,
    },

    legendDash: {
        width: 22,
        height: 2,
        backgroundColor: "#57B765",
        marginRight: 8,
    },

    legendText: {
        fontSize: 14,
        color: "#222222",
    },
});