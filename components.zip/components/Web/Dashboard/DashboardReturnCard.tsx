import React from "react";
import { View, Text, StyleSheet, TouchableOpacity } from "react-native";
import { MaterialCommunityIcons } from "@expo/vector-icons";

type Props = {
    onPressReason?: (reason: string) => void;
};

function ReturnReason({
    label,
    onPress,
}: {
    label: string;
    onPress?: () => void;
}) {
    return (
        <TouchableOpacity
            activeOpacity={0.85}
            style={styles.reasonRow}
            onPress={onPress}
        >
            <Text style={styles.reasonLabel}>{label}</Text>

            <View style={styles.reasonRight}>
                <Text style={styles.reasonNumber}>0</Text>
                <Text style={styles.reasonPercent}>0%</Text>

                <MaterialCommunityIcons
                    name="chevron-right"
                    size={20}
                    color="#444444"
                />
            </View>
        </TouchableOpacity>
    );
}

export default function DashboardReturnCard({ onPressReason }: Props) {
    const returnReasons = [
        "Đơn shop hủy",
        "Không liên hệ được",
        "KH từ chối nhận",
        "Hoàn vì lý do khác",
        "Giao lại, Giao KH mới",
    ];

    return (
        <View style={styles.bigCard}>
            <Text style={styles.cardTitle}>Đơn hoàn</Text>

            <View style={styles.returnBody}>
                <View style={styles.donutWrap}>
                    <View style={styles.donutOuter}>
                        <View style={styles.donutInner}>
                            <Text style={styles.donutLabel}>Đơn hàng</Text>
                            <Text style={styles.donutValue}>0</Text>

                            <Text style={styles.donutLabel}>Tỷ lệ hoàn</Text>
                            <Text style={styles.donutValue}>0</Text>
                        </View>
                    </View>
                </View>

                <View style={styles.reasonList}>
                    {returnReasons.map((item) => (
                        <ReturnReason
                            key={item}
                            label={item}
                            onPress={() => onPressReason?.(item)}
                        />
                    ))}
                </View>
            </View>
        </View>
    );
}

const styles = StyleSheet.create({
    bigCard: {
        backgroundColor: "#FFFFFF",
        borderRadius: 8,
        padding: 22,
        marginBottom: 14,
    },

    cardTitle: {
        fontSize: 17,
        fontWeight: "600",
        color: "#111111",
    },

    returnBody: {
        marginTop: 26,
        flexDirection: "row",
        alignItems: "center",
    },

    donutWrap: {
        width: 390,
        alignItems: "center",
        justifyContent: "center",
    },

    donutOuter: {
        width: 300,
        height: 300,
        borderRadius: 150,
        borderWidth: 52,
        borderColor: "#A9E5AD",
        alignItems: "center",
        justifyContent: "center",
    },

    donutInner: {
        width: 150,
        height: 150,
        borderRadius: 75,
        backgroundColor: "#FFFFFF",
        alignItems: "center",
        justifyContent: "center",
    },

    donutLabel: {
        fontSize: 15,
        color: "#555555",
        marginBottom: 4,
    },

    donutValue: {
        fontSize: 17,
        color: "#111111",
        fontWeight: "600",
        marginBottom: 10,
    },

    reasonList: {
        flex: 1,
        paddingLeft: 28,
    },

    reasonRow: {
        height: 56,
        borderBottomWidth: 8,
        borderBottomColor: "#F2F2F2",
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "space-between",
    },

    reasonLabel: {
        fontSize: 16,
        color: "#555555",
        fontWeight: "400",
    },

    reasonRight: {
        flexDirection: "row",
        alignItems: "center",
    },

    reasonNumber: {
        fontSize: 16,
        fontWeight: "600",
        color: "#111111",
        marginRight: 16,
    },

    reasonPercent: {
        fontSize: 16,
        fontWeight: "600",
        color: "#4C9656",
        marginRight: 8,
    },
});