import React from "react";
import { View, Text, TouchableOpacity, StyleSheet } from "react-native";
import { MaterialCommunityIcons } from "@expo/vector-icons";

type Props = {
    name?: string;
    role?: string;
    onPressProfile?: () => void;
    onPressLogout?: () => void;
    onLogout?: () => void; // backward compat
    onClose?: () => void;
};

export default function DashboardQuickMenu({
    name,
    role,
    onPressProfile,
    onPressLogout,
    onLogout,
    onClose,
}: Props) {
    const handleLogout = onPressLogout || onLogout;

    return (
        <TouchableOpacity
            style={styles.overlay}
            activeOpacity={1}
            onPress={onClose}
        >
            <View style={styles.quickMenu}>
                {/* User info */}
                {name ? (
                    <View style={styles.userInfo}>
                        <Text style={styles.userName} numberOfLines={1}>{name}</Text>
                        {role ? <Text style={styles.userRole}>{role}</Text> : null}
                    </View>
                ) : null}

                <View style={styles.divider} />

                <TouchableOpacity
                    activeOpacity={0.8}
                    style={styles.quickMenuItem}
                    onPress={() => { onClose?.(); onPressProfile?.(); }}
                >
                    <View style={styles.quickMenuIcon}>
                        <MaterialCommunityIcons name="account-outline" size={22} color="#111111" />
                    </View>
                    <Text style={styles.quickMenuText}>Thông tin tài khoản</Text>
                </TouchableOpacity>

                <TouchableOpacity activeOpacity={0.8} style={styles.quickMenuItem}>
                    <View style={styles.quickMenuIcon}>
                        <MaterialCommunityIcons name="help-circle-outline" size={22} color="#111111" />
                    </View>
                    <Text style={styles.quickMenuText}>Hỗ trợ</Text>
                </TouchableOpacity>

                <TouchableOpacity
                    activeOpacity={0.8}
                    style={styles.quickMenuItem}
                    onPress={handleLogout}
                >
                    <View style={[styles.quickMenuIcon, styles.logoutIconBg]}>
                        <MaterialCommunityIcons name="logout" size={22} color="#F04A3A" />
                    </View>
                    <Text style={styles.logoutText}>Đăng xuất</Text>
                </TouchableOpacity>
            </View>
        </TouchableOpacity>
    );
}

const styles = StyleSheet.create({
    overlay: {
        position: "absolute",
        top: 0, left: 0, right: 0, bottom: 0,
        zIndex: 20,
    },
    quickMenu: {
        position: "absolute",
        left: 12,
        bottom: 68,
        width: 250,
        backgroundColor: "#FFFFFF",
        borderRadius: 8,
        paddingVertical: 8,
        paddingHorizontal: 10,
        zIndex: 30,
        shadowColor: "#000000",
        shadowOffset: { width: 0, height: 6 },
        shadowOpacity: 0.14,
        shadowRadius: 14,
        elevation: 10,
    },
    userInfo: {
        paddingHorizontal: 4,
        paddingVertical: 8,
    },
    userName: {
        fontSize: 14,
        fontWeight: "700",
        color: "#111111",
    },
    userRole: {
        fontSize: 12,
        color: "#888888",
        marginTop: 2,
    },
    divider: {
        height: 1,
        backgroundColor: "#F0F0F0",
        marginVertical: 4,
    },
    quickMenuItem: {
        height: 50,
        flexDirection: "row",
        alignItems: "center",
    },
    quickMenuIcon: {
        width: 38,
        height: 38,
        borderRadius: 19,
        backgroundColor: "#F5F5F5",
        alignItems: "center",
        justifyContent: "center",
        marginRight: 12,
    },
    quickMenuText: {
        fontSize: 15,
        fontWeight: "600",
        color: "#111111",
    },
    logoutIconBg: {
        backgroundColor: "#FFF3F1",
    },
    logoutText: {
        fontSize: 15,
        fontWeight: "700",
        color: "#F04A3A",
    },
});
