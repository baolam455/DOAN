import React from "react";
import { View, Text, TouchableOpacity, StyleSheet } from "react-native";
import { MaterialCommunityIcons } from "@expo/vector-icons";

export type DateFilter = "all" | "today" | "7days" | "30days";

type Props = {
    activeFilter?: DateFilter;
    onPressToday?: () => void;
    onPressSevenDays?: () => void;
    onPressThirtyDays?: () => void;
    onPressCustom?: () => void;
    onPressNotice?: () => void;
};

export default function DashboardFilterBar({
    activeFilter = "all",
    onPressToday,
    onPressSevenDays,
    onPressThirtyDays,
    onPressCustom,
    onPressNotice,
}: Props) {
    return (
        <View style={styles.filterBar}>
            <View style={styles.dateTabs}>
                <TouchableOpacity
                    activeOpacity={0.8}
                    style={[styles.dateTab, activeFilter === "today" && styles.dateTabActive]}
                    onPress={onPressToday}
                >
                    <Text style={[styles.dateTabText, activeFilter === "today" && styles.dateTabTextActive]}>
                        Hôm nay
                    </Text>
                </TouchableOpacity>

                <TouchableOpacity
                    activeOpacity={0.8}
                    style={[styles.dateTab, activeFilter === "7days" && styles.dateTabActive]}
                    onPress={onPressSevenDays}
                >
                    <Text style={[styles.dateTabText, activeFilter === "7days" && styles.dateTabTextActive]}>
                        7 ngày trước
                    </Text>
                </TouchableOpacity>

                <TouchableOpacity
                    activeOpacity={0.8}
                    style={[styles.dateTab, activeFilter === "30days" && styles.dateTabActive]}
                    onPress={onPressThirtyDays}
                >
                    <Text style={[styles.dateTabText, activeFilter === "30days" && styles.dateTabTextActive]}>
                        30 ngày trước
                    </Text>
                </TouchableOpacity>

                <TouchableOpacity
                    activeOpacity={0.8}
                    style={styles.dateTab}
                    onPress={onPressCustom}
                >
                    <Text style={styles.dateTabText}>Tùy chọn</Text>

                    <MaterialCommunityIcons
                        name="chevron-down"
                        size={22}
                        color="#111111"
                        style={styles.dateArrow}
                    />
                </TouchableOpacity>
            </View>

            <TouchableOpacity
                activeOpacity={0.8}
                style={styles.noticePill}
                onPress={onPressNotice}
            >
                <View style={styles.redDot} />

                <Text style={styles.noticeText}>
                    <Text style={styles.noticeBold}>Thông báo:</Text> Không có
                </Text>

                <MaterialCommunityIcons name="chevron-right" size={22} color="#111111" />
            </TouchableOpacity>
        </View>
    );
}

const styles = StyleSheet.create({
    filterBar: {
        flexDirection: "row",
        alignItems: "center",
        marginBottom: 24,
    },

    dateTabs: {
        height: 48,
        backgroundColor: "#F7F7F7",
        borderRadius: 7,
        flexDirection: "row",
        alignItems: "center",
        marginRight: 18,
    },

    dateTab: {
        height: 48,
        paddingHorizontal: 18,
        borderRadius: 7,
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "center",
    },

    dateTabActive: {
        backgroundColor: "#FFFFFF",
        shadowColor: "#000000",
        shadowOffset: { width: 0, height: 1 },
        shadowOpacity: 0.12,
        shadowRadius: 4,
        elevation: 2,
    },

    dateTabText: {
        fontSize: 16,
        fontWeight: "600",
        color: "#111111",
    },

    dateTabTextActive: {
        color: "#3F9650",
    },

    dateArrow: {
        marginLeft: 4,
    },

    noticePill: {
        height: 48,
        minWidth: 300,
        backgroundColor: "#FFFFFF",
        borderRadius: 7,
        paddingHorizontal: 18,
        flexDirection: "row",
        alignItems: "center",
        shadowColor: "#000000",
        shadowOffset: { width: 0, height: 1 },
        shadowOpacity: 0.06,
        shadowRadius: 3,
        elevation: 1,
    },

    redDot: {
        width: 8,
        height: 8,
        borderRadius: 4,
        backgroundColor: "#E83E2F",
        marginRight: 12,
    },

    noticeText: {
        flex: 1,
        fontSize: 16,
        color: "#111111",
    },

    noticeBold: {
        fontWeight: "700",
    },
});
