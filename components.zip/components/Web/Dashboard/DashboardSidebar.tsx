import React from "react";
import { View, Text, TouchableOpacity, StyleSheet } from "react-native";
import { MaterialCommunityIcons } from "@expo/vector-icons";

type ActivePage = "overview" | "orders" | "report" | "money" | "chat";

type Props = {
    initials: string;
    activePage?: ActivePage;
    onToggleQuickMenu: () => void;
    onPressOverview?: () => void;
    onPressOrders?: () => void;
    onPressReport?: () => void;
    onPressMoney?: () => void;
    onPressChat?: () => void;
    onPressWallet?: () => void;
    onPressHelp?: () => void;
};

function SidebarButton({
    icon,
    active = false,
    onPress,
}: {
    icon: any;
    active?: boolean;
    onPress?: () => void;
}) {
    return (
        <TouchableOpacity
            activeOpacity={0.75}
            onPress={onPress}
            style={[styles.sidebarButton, active && styles.sidebarButtonActive]}
        >
            <MaterialCommunityIcons
                name={icon}
                size={23}
                color={active ? "#3F9650" : "#111111"}
            />
        </TouchableOpacity>
    );
}

export default function DashboardSidebar({
    initials,
    activePage = "overview",
    onToggleQuickMenu,
    onPressOverview,
    onPressOrders,
    onPressReport,
    onPressMoney,
    onPressChat,
    onPressWallet,
    onPressHelp,
}: Props) {
    return (
        <View style={styles.sidebar}>
            <View style={styles.sidebarTop}>
                <TouchableOpacity activeOpacity={0.8} onPress={onToggleQuickMenu}>
                    <View style={styles.avatarCircle}>
                        <Text style={styles.avatarText}>{initials}</Text>
                    </View>
                </TouchableOpacity>

                <View style={styles.menuGroup}>
                    <SidebarButton
                        icon="view-dashboard-outline"
                        active={activePage === "overview"}
                        onPress={onPressOverview}
                    />

                    <SidebarButton
                        icon="clipboard-list-outline"
                        active={activePage === "orders"}
                        onPress={onPressOrders}
                    />

                    <SidebarButton
                        icon="chart-line"
                        active={activePage === "report"}
                        onPress={onPressReport}
                    />

                    <SidebarButton
                        icon="cash"
                        active={activePage === "money"}
                        onPress={onPressMoney}
                    />

                    <SidebarButton
                        icon="message-processing-outline"
                        active={activePage === "chat"}
                        onPress={onPressChat}
                    />
                </View>
            </View>

            <View style={styles.sidebarBottom}>
                <SidebarButton
                    icon="wallet-outline"
                    onPress={onPressWallet}
                />

                <SidebarButton
                    icon="help-circle-outline"
                    onPress={onPressHelp}
                />

                <SidebarButton
                    icon="logout-variant"
                    onPress={onToggleQuickMenu}
                />
            </View>
        </View>
    );
}

const styles = StyleSheet.create({
    sidebar: {
        width: 72,
        backgroundColor: "#FFFFFF",
        borderRightWidth: 1,
        borderRightColor: "#E6E6E6",
        justifyContent: "space-between",
        alignItems: "center",
        paddingTop: 16,
        paddingBottom: 14,
        zIndex: 10,
    },

    sidebarTop: {
        alignItems: "center",
    },

    sidebarBottom: {
        alignItems: "center",
    },

    avatarCircle: {
        width: 44,
        height: 44,
        borderRadius: 22,
        backgroundColor: "#4E9858",
        justifyContent: "center",
        alignItems: "center",
        marginBottom: 18,
    },

    avatarText: {
        color: "#FFFFFF",
        fontSize: 18,
        fontWeight: "700",
    },

    menuGroup: {
        alignItems: "center",
    },

    sidebarButton: {
        width: 46,
        height: 46,
        borderRadius: 10,
        justifyContent: "center",
        alignItems: "center",
        marginBottom: 14,
    },

    sidebarButtonActive: {
        backgroundColor: "#E8F6EA",
    },
});
