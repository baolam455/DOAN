import React from "react";
import {
    View,
    Text,
    StyleSheet,
    TouchableOpacity,
} from "react-native";
import { DashboardStats } from "../../../services/orderApi";

type Props = {
    stats?: DashboardStats;
    onPressGenerated?: () => void;
    onPressSuccess?: () => void;
    onPressDelivering?: () => void;
    onPressShippingFee?: () => void;
};

function MetricCard({
    title,
    children,
    onPress,
}: {
    title: string;
    children: React.ReactNode;
    onPress?: () => void;
}) {
    return (
        <TouchableOpacity
            activeOpacity={0.85}
            onPress={onPress}
            style={styles.metricCard}
        >
            <Text style={styles.metricTitle}>{title}</Text>
            {children}
        </TouchableOpacity>
    );
}

function MetricText({
    value,
    label,
}: {
    value: string;
    label: string;
}) {
    return (
        <View style={styles.metricItem}>
            <Text style={styles.metricValue}>{value}</Text>
            <Text style={styles.metricLabel}>{label}</Text>
        </View>
    );
}

function formatMoneyShort(amount: number): string {
    if (amount >= 1_000_000_000) return `${(amount / 1_000_000_000).toFixed(1)}tỷ`;
    if (amount >= 1_000_000) return `${(amount / 1_000_000).toFixed(1)}tr`;
    if (amount >= 1_000) return `${(amount / 1_000).toFixed(0)}k`;
    return `${amount}`;
}

export default function DashboardMetricGrid({
    stats,
    onPressGenerated,
    onPressSuccess,
    onPressDelivering,
    onPressShippingFee,
}: Props) {
    const total = stats?.total ?? 0;
    const totalQty = stats?.totalQuantity ?? 0;
    const totalCod = stats?.totalCod ?? 0;

    const delivered = stats?.delivered ?? 0;
    const deliveredQty = stats?.deliveredQuantity ?? 0;

    const delivering = stats?.delivering ?? 0;
    const deliveringQty = stats?.deliveringQuantity ?? 0;

    const shippingFeeDeliver = stats?.totalShippingFee ?? 0;

    return (
        <View style={styles.metricGrid}>
            <MetricCard title="Phát sinh" onPress={onPressGenerated}>
                <View style={styles.metricRow}>
                    <MetricText value={String(total)} label="ĐH" />
                    <MetricText value={String(totalQty)} label="SP" />
                    <MetricText value={`${formatMoneyShort(totalCod)}đ`} label="CoD" />
                </View>
            </MetricCard>

            <MetricCard title="Thành công" onPress={onPressSuccess}>
                <View style={styles.metricRow}>
                    <MetricText value={String(delivered)} label="ĐH" />
                    <MetricText value={String(deliveredQty)} label="SP" />
                    <MetricText value={`${formatMoneyShort(totalCod)}đ`} label="CoD" />
                </View>
            </MetricCard>

            <MetricCard title="Đang giao" onPress={onPressDelivering}>
                <View style={styles.metricRow}>
                    <MetricText value={String(delivering)} label="ĐH" />
                    <MetricText value={String(deliveringQty)} label="SP" />
                    <MetricText value="0đ" label="CoD" />
                </View>
            </MetricCard>

            <MetricCard title="Phí vận chuyển" onPress={onPressShippingFee}>
                <View style={styles.feeRow}>
                    <Text style={styles.feeText}>{formatMoneyShort(shippingFeeDeliver)}đ Giao</Text>
                    <Text style={styles.feeText}>0đ Hoàn</Text>
                </View>
            </MetricCard>
        </View>
    );
}

const styles = StyleSheet.create({
    metricGrid: {
        flexDirection: "row",
        flexWrap: "wrap",
        justifyContent: "space-between",
        backgroundColor: "#FFFFFF",
        borderRadius: 8,
        padding: 22,
        marginBottom: 14,
    },

    metricCard: {
        width: "49.2%",
        minHeight: 106,
        backgroundColor: "#F7F7F7",
        borderRadius: 7,
        paddingHorizontal: 22,
        paddingTop: 18,
        marginBottom: 14,
    },

    metricTitle: {
        fontSize: 16,
        color: "#626262",
        fontWeight: "400",
        marginBottom: 16,
    },

    metricRow: {
        flexDirection: "row",
        alignItems: "center",
    },

    metricItem: {
        flexDirection: "row",
        alignItems: "center",
        marginRight: 36,
    },

    metricValue: {
        fontSize: 16,
        color: "#111111",
        fontWeight: "600",
        marginRight: 4,
    },

    metricLabel: {
        fontSize: 16,
        color: "#111111",
        fontWeight: "600",
    },

    feeRow: {
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "space-between",
    },

    feeText: {
        fontSize: 16,
        color: "#111111",
        fontWeight: "600",
    },
});
