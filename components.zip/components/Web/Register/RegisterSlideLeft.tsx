import React from "react";
import {
  Animated,
  ImageBackground,
  StyleSheet,
  Text,
  View,
} from "react-native";

type SlideItem = {
  image: { uri: string } | number;
  top: string;
  title: string;
  desc: string;
};

type Props = {
  slide: SlideItem;
  fadeAnim: Animated.Value;
};

export default function RegisterSlideLeft({ slide, fadeAnim }: Props) {
  return (
    <Animated.View style={[styles.leftSection, { opacity: fadeAnim }]}>
      <ImageBackground
        source={slide.image}
        resizeMode="cover"
        style={styles.leftBackground}
      >
        <View style={styles.leftOverlay} />

        <View style={styles.leftContent}>
          <Text style={styles.leftTop}>{slide.top}</Text>
          <Text style={styles.leftTitle}>{slide.title}</Text>
          <Text style={styles.leftDesc}>{slide.desc}</Text>
        </View>
      </ImageBackground>
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  leftSection: {
    flex: 1,
  },

  leftBackground: {
    flex: 1,
    justifyContent: "flex-end",
  },

  leftOverlay: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: "rgba(0, 88, 44, 0.45)",
  },

  leftContent: {
    paddingHorizontal: 35,
    paddingBottom: 170,
  },

  leftTop: {
    fontSize: 18,
    lineHeight: 18,
    fontWeight: "600",
    color: "#E8FFF1",
    marginBottom: 15,
  },

  leftTitle: {
    width: 560,
    fontSize: 45,
    lineHeight: 45,
    fontWeight: "700",
    color: "#FFFFFF",
  },

  leftDesc: {
    marginTop: 12,
    width: 560,
    fontSize: 14,
    lineHeight: 20,
    fontWeight: "500",
    color: "#E8FFF1",
  },
});
