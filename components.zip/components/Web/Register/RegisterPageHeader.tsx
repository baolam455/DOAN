import React from "react";
import { View, Text, StyleSheet, TouchableOpacity } from "react-native";

type Props = {
  onHomePress: () => void;
};

export default function RegisterPageHeader({ onHomePress }: Props) {
  return (
    <View style={styles.header}>
      <TouchableOpacity onPress={onHomePress}>
        <Text style={styles.logo}>GHTK</Text>
      </TouchableOpacity>

      <View style={styles.menu}>
        <TouchableOpacity onPress={onHomePress}>
          <Text style={styles.menuActive}>Trang chủ</Text>
        </TouchableOpacity>

        <Text style={styles.menuItem}>Về chúng tôi</Text>
        <Text style={styles.menuItem}>For Business</Text>
        <Text style={styles.menuItem}>For E-Commerce</Text>
        <Text style={styles.menuItem}>Tuyển dụng</Text>
        <Text style={styles.menuItem}>Tin tức</Text>
        <Text style={styles.menuItem}>Hỏi đáp</Text>
        <Text style={styles.menuItem}>Liên hệ</Text>
      </View>

      <TouchableOpacity style={styles.consultBtn}>
        <Text style={styles.consultText}>Tư vấn Doanh nghiệp</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  header: {
    height: 76,
    backgroundColor: "#FFFFFF",
    paddingHorizontal: 24,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    borderBottomWidth: 1,
    borderBottomColor: "#EAEAEA",
  },

  logo: {
    fontSize: 28,
    fontWeight: "800",
    color: "#00B14F",
  },

  menu: {
    flexDirection: "row",
    alignItems: "center",
    gap: 18,
  },

  menuActive: {
    color: "#222222",
    fontSize: 16,
    fontWeight: "500",
  },

  menuItem: {
    color: "#222222",
    fontSize: 15,
    fontWeight: "500",
  },

  consultBtn: {
    backgroundColor: "#F15A24",
    paddingHorizontal: 18,
    paddingVertical: 12,
    borderRadius: 6,
  },

  consultText: {
    color: "#FFFFFF",
    fontSize: 14,
    fontWeight: "700",
  },
});
