import React, { useState } from "react";
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
} from "react-native";
import { Ionicons } from "@expo/vector-icons";

type RegisterErrors = {
  storeName?: string;
  phone?: string;
  email?: string;
  address?: string;
  password?: string;
  rePassword?: string;
  agree?: string;
};

type Props = {
  storeName: string;
  phone: string;
  email: string;
  address: string;
  password: string;
  rePassword: string;
  agree: boolean;
  errors?: RegisterErrors;
  loading?: boolean;
  onChangeStoreName: (value: string) => void;
  onChangePhone: (value: string) => void;
  onChangeEmail: (value: string) => void;
  onChangeAddress: (value: string) => void;
  onChangePassword: (value: string) => void;
  onChangeRePassword: (value: string) => void;
  onToggleAgree: () => void;
  onRegisterPress?: () => void;
};

function RequiredLabel({ label }: { label: string }) {
  return (
    <Text style={styles.label}>
      {label} <Text style={styles.requiredStar}>*</Text>
    </Text>
  );
}

function ErrorText({ message }: { message?: string }) {
  if (!message) {
    return null;
  }

  return <Text style={styles.errorText}>{message}</Text>;
}

export default function RegisterForm({
  storeName,
  phone,
  email,
  address,
  password,
  rePassword,
  agree,
  errors,
  loading = false,
  onChangeStoreName,
  onChangePhone,
  onChangeEmail,
  onChangeAddress,
  onChangePassword,
  onChangeRePassword,
  onToggleAgree,
  onRegisterPress,
}: Props) {
  const [showPassword, setShowPassword] = useState(false);
  const [showRePassword, setShowRePassword] = useState(false);

  return (
    <View style={styles.formWrap}>
      <View style={styles.inputGroup}>
        <RequiredLabel label="Tên cửa hàng" />

        <TextInput
          style={[styles.input, errors?.storeName && styles.inputError]}
          placeholder="Tên cửa hàng"
          placeholderTextColor="#C2C2C2"
          value={storeName}
          onChangeText={onChangeStoreName}
        />

        <ErrorText message={errors?.storeName} />
      </View>

      <View style={styles.inputGroup}>
        <RequiredLabel label="Điện thoại liên hệ" />

        <TextInput
          style={[styles.input, errors?.phone && styles.inputError]}
          placeholder="Điện thoại liên hệ"
          placeholderTextColor="#C2C2C2"
          value={phone}
          keyboardType="phone-pad"
          maxLength={10}
          onChangeText={(text) => {
            const onlyNumber = text.replace(/\D/g, "").slice(0, 10);
            onChangePhone(onlyNumber);
          }}
        />

        <ErrorText message={errors?.phone} />
      </View>

      <View style={styles.inputGroup}>
        <RequiredLabel label="Email" />

        <TextInput
          style={[styles.input, errors?.email && styles.inputError]}
          placeholder="Email"
          placeholderTextColor="#C2C2C2"
          value={email}
          keyboardType="email-address"
          autoCapitalize="none"
          onChangeText={onChangeEmail}
        />

        <ErrorText message={errors?.email} />
      </View>

      <View style={styles.inputGroup}>
        <RequiredLabel label="Địa chỉ lấy hàng" />

        <TextInput
          style={[styles.input, errors?.address && styles.inputError]}
          placeholder="Nhập địa chỉ"
          placeholderTextColor="#C2C2C2"
          value={address}
          onChangeText={onChangeAddress}
        />

        <ErrorText message={errors?.address} />
      </View>

      <View style={styles.inputGroup}>
        <RequiredLabel label="Mật khẩu" />

        <View
          style={[styles.passwordBox, errors?.password && styles.inputError]}
        >
          <TextInput
            style={styles.passwordInput}
            placeholder="Mật khẩu"
            placeholderTextColor="#C2C2C2"
            secureTextEntry={!showPassword}
            value={password}
            onChangeText={onChangePassword}
          />

          <TouchableOpacity
            style={styles.eyeButton}
            activeOpacity={0.7}
            onPress={() => setShowPassword((prev) => !prev)}
          >
            <Ionicons
              name={showPassword ? "eye-off-outline" : "eye-outline"}
              size={20}
              color="#777777"
            />
          </TouchableOpacity>
        </View>

        <Text style={styles.passwordHint}>
          Mật khẩu gồm chữ hoa, chữ thường, số và ký tự đặc biệt
        </Text>

        <ErrorText message={errors?.password} />
      </View>

      <View style={styles.inputGroup}>
        <RequiredLabel label="Nhập lại mật khẩu" />

        <View
          style={[styles.passwordBox, errors?.rePassword && styles.inputError]}
        >
          <TextInput
            style={styles.passwordInput}
            placeholder="Nhập lại mật khẩu"
            placeholderTextColor="#C2C2C2"
            secureTextEntry={!showRePassword}
            value={rePassword}
            onChangeText={onChangeRePassword}
          />

          <TouchableOpacity
            style={styles.eyeButton}
            activeOpacity={0.7}
            onPress={() => setShowRePassword((prev) => !prev)}
          >
            <Ionicons
              name={showRePassword ? "eye-off-outline" : "eye-outline"}
              size={20}
              color="#777777"
            />
          </TouchableOpacity>
        </View>

        <ErrorText message={errors?.rePassword} />
      </View>

      <View style={styles.supportRow}>
        <Text style={styles.supportText}>Bạn đang gặp khó khăn? </Text>

        <TouchableOpacity activeOpacity={0.8}>
          <Text style={styles.supportLink}>Để lại SĐT để tư vấn</Text>
        </TouchableOpacity>
      </View>

      <TouchableOpacity
        style={styles.agreeRow}
        activeOpacity={0.8}
        onPress={onToggleAgree}
      >
        <View style={[styles.checkbox, agree && styles.checkboxActive]}>
          {agree && <Text style={styles.checkboxTick}>✓</Text>}
        </View>

        <Text style={styles.agreeText}>
          Tôi đã đọc và đồng ý với Điều khoản & Quy định và Chính sách bảo mật
        </Text>
      </TouchableOpacity>

      <ErrorText message={errors?.agree} />

      <TouchableOpacity
        style={[
          styles.registerButton,
          loading && styles.registerButtonDisabled,
        ]}
        disabled={loading}
        activeOpacity={0.85}
        onPress={onRegisterPress}
      >
        <Text style={styles.registerButtonText}>
          {loading ? "Đang đăng ký..." : "Đăng ký"}
        </Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  formWrap: {
    width: 520,
  },

  inputGroup: {
    marginBottom: 8,
  },

  label: {
    fontSize: 13,
    fontWeight: "700",
    color: "#333333",
    marginBottom: 5,
  },

  requiredStar: {
    color: "#E53935",
  },

  input: {
    width: 520,
    height: 42,
    borderWidth: 1,
    borderColor: "#DDDDDD",
    borderRadius: 2,
    backgroundColor: "#FFFFFF",
    paddingHorizontal: 14,
    fontSize: 14,
    color: "#111111",
  },

  inputError: {
    borderColor: "#E53935",
  },

  errorText: {
    fontSize: 12,
    color: "#E53935",
    marginTop: 4,
  },

  passwordBox: {
    width: 520,
    height: 42,
    borderWidth: 1,
    borderColor: "#DDDDDD",
    borderRadius: 2,
    backgroundColor: "#FFFFFF",
    flexDirection: "row",
    alignItems: "center",
  },

  passwordInput: {
    flex: 1,
    height: 40,
    paddingHorizontal: 14,
    paddingRight: 8,
    fontSize: 14,
    color: "#111111",
  },

  eyeButton: {
    width: 42,
    height: 42,
    alignItems: "center",
    justifyContent: "center",
  },

  passwordHint: {
    fontSize: 12,
    color: "#8A8A8A",
    marginTop: 4,
  },

  supportRow: {
    flexDirection: "row",
    flexWrap: "wrap",
    marginTop: 2,
    marginBottom: 10,
  },

  supportText: {
    fontSize: 14,
    fontWeight: "600",
    color: "#111111",
  },

  supportLink: {
    fontSize: 14,
    fontWeight: "700",
    color: "#00B14F",
  },

  agreeRow: {
    flexDirection: "row",
    alignItems: "flex-start",
    marginBottom: 6,
  },

  checkbox: {
    width: 15,
    height: 15,
    borderWidth: 1,
    borderColor: "#D6D6D6",
    borderRadius: 2,
    backgroundColor: "#F2F2F2",
    marginTop: 2,
    marginRight: 8,
    alignItems: "center",
    justifyContent: "center",
  },

  checkboxActive: {
    backgroundColor: "#00B14F",
    borderColor: "#00B14F",
  },

  checkboxTick: {
    fontSize: 11,
    fontWeight: "900",
    color: "#FFFFFF",
    lineHeight: 12,
  },

  agreeText: {
    flex: 1,
    fontSize: 12,
    lineHeight: 17,
    color: "#A1A1A1",
  },

  registerButton: {
    width: 520,
    height: 42,
    borderRadius: 2,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#00B14F",
    marginTop: 10,
  },

  registerButtonDisabled: {
    backgroundColor: "#BEBEBE",
  },

  registerButtonText: {
    fontSize: 15,
    fontWeight: "800",
    color: "#FFFFFF",
  },
});
