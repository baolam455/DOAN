import React, { useState, useEffect } from "react";
import {
    View,
    Text,
    TextInput,
    TouchableOpacity,
    StyleSheet,
    ActivityIndicator,
    Alert,
} from "react-native";
import { MaterialCommunityIcons } from "@expo/vector-icons";
import { CustomerProfile, updateProfile } from "../../../services/customerApi";

type Props = {
    profile: CustomerProfile;
    onUpdated: (updated: CustomerProfile) => void;
};

const ROLE_LABEL: Record<string, string> = {
    customer: "Khách hàng",
    shipper: "Shipper",
    admin: "Quản trị viên",
};

export default function ProfileForm({ profile, onUpdated }: Props) {
    const [isEditing, setIsEditing] = useState(false);
    const [loading, setLoading] = useState(false);

    const [fullName, setFullName] = useState(profile.full_name || "");
    const [phone, setPhone]       = useState(profile.phone    || "");
    const [address, setAddress]   = useState(profile.address  || "");
    const [error, setError]       = useState("");

    useEffect(() => {
        setFullName(profile.full_name || "");
        setPhone(profile.phone    || "");
        setAddress(profile.address  || "");
    }, [profile]);

    const handleCancel = () => {
        setFullName(profile.full_name || "");
        setPhone(profile.phone    || "");
        setAddress(profile.address  || "");
        setError("");
        setIsEditing(false);
    };

    const handleSave = async () => {
        setError("");
        setLoading(true);
        try {
            const updated = await updateProfile({ full_name: fullName, phone, address });
            onUpdated(updated);
            setIsEditing(false);
            Alert.alert("Thành công", "Đã cập nhật thông tin tài khoản");
        } catch (e: any) {
            setError(e.message || "Cập nhật thất bại");
        } finally {
            setLoading(false);
        }
    };

    const joinDate = profile.created_at
        ? new Date(profile.created_at).toLocaleDateString("vi-VN")
        : "—";

    return (
        <View style={styles.card}>
            {/* Avatar + tên */}
            <View style={styles.avatarRow}>
                <View style={styles.avatarCircle}>
                    <Text style={styles.avatarText}>
                        {(profile.full_name || "?")[0].toUpperCase()}
                    </Text>
                </View>
                <View>
                    <Text style={styles.nameText}>{profile.full_name || "—"}</Text>
                    <View style={styles.roleBadge}>
                        <Text style={styles.roleText}>
                            {ROLE_LABEL[profile.role] || profile.role}
                        </Text>
                    </View>
                </View>
            </View>

            <View style={styles.divider} />

            {/* Trường không sửa được */}
            <FieldReadOnly
                icon="email-outline"
                label="Email"
                value={profile.id || "—"}
            />
            <FieldReadOnly
                icon="calendar-outline"
                label="Ngày tham gia"
                value={joinDate}
            />

            <View style={styles.divider} />

            {/* Trường có thể sửa */}
            <FieldEditable
                icon="account-outline"
                label="Họ và tên"
                value={fullName}
                editable={isEditing}
                onChangeText={setFullName}
                placeholder="Nhập họ và tên"
            />
            <FieldEditable
                icon="phone-outline"
                label="Số điện thoại"
                value={phone}
                editable={isEditing}
                onChangeText={setPhone}
                placeholder="Nhập số điện thoại"
                keyboardType="phone-pad"
            />
            <FieldEditable
                icon="map-marker-outline"
                label="Địa chỉ"
                value={address}
                editable={isEditing}
                onChangeText={setAddress}
                placeholder="Nhập địa chỉ"
                multiline
            />

            {error ? <Text style={styles.errorText}>{error}</Text> : null}

            {/* Buttons */}
            {!isEditing ? (
                <TouchableOpacity
                    style={styles.btnEdit}
                    onPress={() => setIsEditing(true)}
                    activeOpacity={0.8}
                >
                    <MaterialCommunityIcons name="pencil-outline" size={18} color="#fff" />
                    <Text style={styles.btnEditText}>Chỉnh sửa</Text>
                </TouchableOpacity>
            ) : (
                <View style={styles.btnRow}>
                    <TouchableOpacity
                        style={styles.btnCancel}
                        onPress={handleCancel}
                        activeOpacity={0.8}
                        disabled={loading}
                    >
                        <Text style={styles.btnCancelText}>Hủy</Text>
                    </TouchableOpacity>
                    <TouchableOpacity
                        style={styles.btnSave}
                        onPress={handleSave}
                        activeOpacity={0.8}
                        disabled={loading}
                    >
                        {loading ? (
                            <ActivityIndicator size="small" color="#fff" />
                        ) : (
                            <>
                                <MaterialCommunityIcons name="check" size={18} color="#fff" />
                                <Text style={styles.btnSaveText}>Lưu thay đổi</Text>
                            </>
                        )}
                    </TouchableOpacity>
                </View>
            )}
        </View>
    );
}

// ─── Sub-components ───────────────────────────────────────────

function FieldReadOnly({
    icon,
    label,
    value,
}: {
    icon: any;
    label: string;
    value: string;
}) {
    return (
        <View style={styles.fieldRow}>
            <View style={styles.fieldIconBox}>
                <MaterialCommunityIcons name={icon} size={18} color="#4E9858" />
            </View>
            <View style={styles.fieldContent}>
                <Text style={styles.fieldLabel}>{label}</Text>
                <Text style={styles.fieldValueReadOnly}>{value}</Text>
            </View>
        </View>
    );
}

function FieldEditable({
    icon,
    label,
    value,
    editable,
    onChangeText,
    placeholder,
    keyboardType,
    multiline,
}: {
    icon: any;
    label: string;
    value: string;
    editable: boolean;
    onChangeText: (t: string) => void;
    placeholder?: string;
    keyboardType?: any;
    multiline?: boolean;
}) {
    return (
        <View style={styles.fieldRow}>
            <View style={styles.fieldIconBox}>
                <MaterialCommunityIcons name={icon} size={18} color={editable ? "#4E9858" : "#999"} />
            </View>
            <View style={styles.fieldContent}>
                <Text style={styles.fieldLabel}>{label}</Text>
                {editable ? (
                    <TextInput
                        style={[styles.fieldInput, multiline && styles.fieldInputMulti]}
                        value={value}
                        onChangeText={onChangeText}
                        placeholder={placeholder}
                        placeholderTextColor="#BDBDBD"
                        keyboardType={keyboardType}
                        multiline={multiline}
                    />
                ) : (
                    <Text style={styles.fieldValue}>{value || "—"}</Text>
                )}
            </View>
        </View>
    );
}

// ─── Styles ───────────────────────────────────────────────────

const styles = StyleSheet.create({
    card: {
        backgroundColor: "#FFFFFF",
        borderRadius: 14,
        padding: 28,
        shadowColor: "#000",
        shadowOpacity: 0.06,
        shadowRadius: 10,
        elevation: 2,
        maxWidth: 560,
        width: "100%",
        alignSelf: "flex-start",
    },
    avatarRow: {
        flexDirection: "row",
        alignItems: "center",
        gap: 16,
        marginBottom: 20,
    },
    avatarCircle: {
        width: 64,
        height: 64,
        borderRadius: 32,
        backgroundColor: "#4E9858",
        justifyContent: "center",
        alignItems: "center",
    },
    avatarText: {
        color: "#FFFFFF",
        fontSize: 26,
        fontWeight: "700",
    },
    nameText: {
        fontSize: 18,
        fontWeight: "700",
        color: "#111111",
        marginBottom: 4,
    },
    roleBadge: {
        backgroundColor: "#E8F6EA",
        borderRadius: 6,
        paddingHorizontal: 10,
        paddingVertical: 2,
        alignSelf: "flex-start",
    },
    roleText: {
        fontSize: 12,
        color: "#4E9858",
        fontWeight: "600",
    },
    divider: {
        height: 1,
        backgroundColor: "#F0F0F0",
        marginVertical: 16,
    },
    fieldRow: {
        flexDirection: "row",
        alignItems: "flex-start",
        marginBottom: 16,
        gap: 12,
    },
    fieldIconBox: {
        width: 32,
        height: 32,
        borderRadius: 8,
        backgroundColor: "#F5F5F5",
        justifyContent: "center",
        alignItems: "center",
        marginTop: 2,
    },
    fieldContent: {
        flex: 1,
    },
    fieldLabel: {
        fontSize: 11,
        color: "#9E9E9E",
        fontWeight: "500",
        marginBottom: 3,
        textTransform: "uppercase",
        letterSpacing: 0.5,
    },
    fieldValue: {
        fontSize: 15,
        color: "#111111",
        fontWeight: "500",
    },
    fieldValueReadOnly: {
        fontSize: 15,
        color: "#555555",
    },
    fieldInput: {
        fontSize: 15,
        color: "#111111",
        borderBottomWidth: 1.5,
        borderBottomColor: "#4E9858",
        paddingBottom: 4,
        paddingTop: 0,
    },
    fieldInputMulti: {
        minHeight: 48,
    },
    errorText: {
        color: "#E53935",
        fontSize: 13,
        marginBottom: 12,
        marginTop: -4,
    },
    btnEdit: {
        marginTop: 8,
        backgroundColor: "#4E9858",
        borderRadius: 10,
        paddingVertical: 12,
        flexDirection: "row",
        justifyContent: "center",
        alignItems: "center",
        gap: 8,
    },
    btnEditText: {
        color: "#FFFFFF",
        fontSize: 15,
        fontWeight: "600",
    },
    btnRow: {
        flexDirection: "row",
        gap: 12,
        marginTop: 8,
    },
    btnCancel: {
        flex: 1,
        borderRadius: 10,
        paddingVertical: 12,
        borderWidth: 1.5,
        borderColor: "#CCCCCC",
        justifyContent: "center",
        alignItems: "center",
    },
    btnCancelText: {
        color: "#555555",
        fontSize: 15,
        fontWeight: "600",
    },
    btnSave: {
        flex: 2,
        backgroundColor: "#4E9858",
        borderRadius: 10,
        paddingVertical: 12,
        flexDirection: "row",
        justifyContent: "center",
        alignItems: "center",
        gap: 8,
    },
    btnSaveText: {
        color: "#FFFFFF",
        fontSize: 15,
        fontWeight: "600",
    },
});
