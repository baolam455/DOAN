import React from "react";
import { View, Text, StyleSheet } from "react-native";
import { MaterialCommunityIcons } from "@expo/vector-icons";

type Props = {
    isEditing: boolean;
};

export default function ProfileHeader({ isEditing }: Props) {
    return (
        <View style={styles.container}>
            <View style={styles.left}>
                <MaterialCommunityIcons
                    name="account-circle-outline"
                    size={22}
                    color="#4E9858"
                />
                <Text style={styles.title}>
                    {isEditing ? "Chỉnh sửa thông tin" : "Thông tin tài khoản"}
                </Text>
            </View>
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        height: 56,
        backgroundColor: "#FFFFFF",
        borderBottomWidth: 1,
        borderBottomColor: "#E6E6E6",
        flexDirection: "row",
        alignItems: "center",
        paddingHorizontal: 24,
    },
    left: {
        flexDirection: "row",
        alignItems: "center",
        gap: 10,
    },
    title: {
        fontSize: 16,
        fontWeight: "600",
        color: "#111111",
    },
});
