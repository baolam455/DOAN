import React, { useState } from "react";
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
} from "react-native";
import { Ionicons } from "@expo/vector-icons";

type LoginErrors = {
  account?: string;
  password?: string;
};

type Props = {
  account: string;
  password: string;
  errors?: LoginErrors;
  loading?: boolean;
  onChangeAccount: (value: string) => void;
  onChangePassword: (value: string) => void;
  onLoginPress?: () => void;
};

function RequiredLabel({ label }: { label: string }) {
  return (
    <Text style={styles.label}>
      {label} <Text style={styles.requiredStar}>*</Text>
    </Text>
  );
}

function ErrorText({ message }: { message?: string }) {
  if (!message) {
    return null;
  }

  return <Text style={styles.errorText}>{message}</Text>;
}

export default function LoginForm({
  account,
  password,
  errors,
  loading = false,
  onChangeAccount,
  onChangePassword,
  onLoginPress,
}: Props) {
  const [showPassword, setShowPassword] = useState(false);

  return (
    <View style={styles.formWrap}>
      <View style={styles.inputGroup}>
        <RequiredLabel label="Số điện thoại / Email" />

        <TextInput
          style={[styles.input, errors?.account && styles.inputError]}
          placeholder="Nhập số điện thoại hoặc email"
          placeholderTextColor="#C2C2C2"
          value={account}
          autoCapitalize="none"
          keyboardType="email-address"
          onChangeText={onChangeAccount}
        />

        <ErrorText message={errors?.account} />
      </View>

      <View style={styles.inputGroup}>
        <RequiredLabel label="Mật khẩu" />

        <View
          style={[styles.passwordBox, errors?.password && styles.inputError]}
        >
          <TextInput
            style={styles.passwordInput}
            placeholder="Nhập mật khẩu"
            placeholderTextColor="#C2C2C2"
            secureTextEntry={!showPassword}
            value={password}
            onChangeText={onChangePassword}
          />

          <TouchableOpacity
            style={styles.eyeButton}
            activeOpacity={0.7}
            onPress={() => setShowPassword((prev) => !prev)}
          >
            <Ionicons
              name={showPassword ? "eye-off-outline" : "eye-outline"}
              size={20}
              color="#777777"
            />
          </TouchableOpacity>
        </View>

        <ErrorText message={errors?.password} />
      </View>

      <TouchableOpacity activeOpacity={0.8} style={styles.forgotRow}>
        <Text style={styles.forgotText}>Quên mật khẩu?</Text>
      </TouchableOpacity>

      <TouchableOpacity
        style={[styles.loginButton, loading && styles.loginButtonDisabled]}
        disabled={loading}
        activeOpacity={0.85}
        onPress={onLoginPress}
      >
        <Text style={styles.loginButtonText}>
          {loading ? "Đang đăng nhập..." : "Đăng nhập"}
        </Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  formWrap: {
    width: 520,
  },

  inputGroup: {
    marginBottom: 12,
  },

  label: {
    fontSize: 13,
    fontWeight: "700",
    color: "#333333",
    marginBottom: 5,
  },

  requiredStar: {
    color: "#E53935",
  },

  input: {
    width: 520,
    height: 42,
    borderWidth: 1,
    borderColor: "#DDDDDD",
    borderRadius: 2,
    backgroundColor: "#FFFFFF",
    paddingHorizontal: 14,
    fontSize: 14,
    color: "#111111",
  },

  inputError: {
    borderColor: "#E53935",
  },

  errorText: {
    fontSize: 12,
    color: "#E53935",
    marginTop: 4,
  },

  passwordBox: {
    width: 520,
    height: 42,
    borderWidth: 1,
    borderColor: "#DDDDDD",
    borderRadius: 2,
    backgroundColor: "#FFFFFF",
    flexDirection: "row",
    alignItems: "center",
  },

  passwordInput: {
    flex: 1,
    height: 40,
    paddingHorizontal: 14,
    paddingRight: 8,
    fontSize: 14,
    color: "#111111",
  },

  eyeButton: {
    width: 42,
    height: 42,
    alignItems: "center",
    justifyContent: "center",
  },

  forgotRow: {
    alignSelf: "flex-end",
    marginTop: 2,
    marginBottom: 18,
  },

  forgotText: {
    fontSize: 14,
    fontWeight: "700",
    color: "#00B14F",
  },

  loginButton: {
    width: 520,
    height: 42,
    borderRadius: 2,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#00B14F",
  },

  loginButtonDisabled: {
    backgroundColor: "#BEBEBE",
  },

  loginButtonText: {
    fontSize: 15,
    fontWeight: "800",
    color: "#FFFFFF",
  },
});
