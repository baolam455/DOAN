import React from "react";
import { View, Text, TouchableOpacity, StyleSheet } from "react-native";

type Props = {
  onRegisterPress: () => void;
};

export default function LoginHeaderBlock({ onRegisterPress }: Props) {
  return (
    <View style={styles.loginHeader}>
      <Text style={styles.loginTitle}>Đăng nhập</Text>

      <View style={styles.subRow}>
        <Text style={styles.subText}>Bạn chưa có tài khoản? </Text>
        <TouchableOpacity onPress={onRegisterPress}>
          <Text style={styles.linkText}>Đăng ký</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  loginHeader: {
    marginBottom: 18,
  },

  loginTitle: {
    fontSize: 28,
    fontWeight: "500",
    color: "#111111",
    marginBottom: 8,
  },

  subRow: {
    flexDirection: "row",
    alignItems: "center",
    flexWrap: "wrap",
  },

  subText: {
    fontSize: 15,
    color: "#505050",
  },

  linkText: {
    fontSize: 15,
    fontWeight: "700",
    color: "#00B14F",
  },
});