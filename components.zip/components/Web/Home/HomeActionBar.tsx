import React from "react";
import { View, Text, StyleSheet, TouchableOpacity } from "react-native";

type Props = {
  onLoginPress: () => void;
};

export default function HomeActionBar({ onLoginPress }: Props) {
  const actions = [
    { label: "Đăng ký / Đăng nhập", onPress: onLoginPress },
    { label: "Tra cứu bưu cục", onPress: () => {} },
    { label: "Tra cứu đơn hàng", onPress: () => {} },
    { label: "Tra cứu cước phí", onPress: () => {} },
  ];

  return (
    <View style={styles.actionBar}>
      {actions.map((item, index) => {
        const isLast = index === actions.length - 1;

        return (
          <TouchableOpacity
            key={item.label}
            style={[styles.actionItem, isLast && styles.actionItemLast]}
            onPress={item.onPress}
          >
            <Text style={styles.actionText}>{item.label}</Text>
            <Text style={styles.arrow}>›</Text>
          </TouchableOpacity>
        );
      })}
    </View>
  );
}

const styles = StyleSheet.create({
  actionBar: {
    height: 92,
    flexDirection: "row",
  },

  actionItem: {
    flex: 1,
    backgroundColor: "#00C73C",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 28,
    borderRightWidth: 1,
    borderRightColor: "#12B246",
  },

  actionItemLast: {
    backgroundColor: "#53E56E",
  },

  actionText: {
    color: "#111111",
    fontSize: 16,
    fontWeight: "700",
  },

  arrow: {
    color: "#111111",
    fontSize: 24,
    fontWeight: "700",
  },
});