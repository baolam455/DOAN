import React from "react";
import { View, Text, StyleSheet, TouchableOpacity } from "react-native";

export default function HomeHeader() {
  const menuItems = [
    "Về chúng tôi",
    "For Business",
    "For E-Commerce",
    "Tuyển dụng",
    "Tin tức",
    "Hỏi đáp",
    "Liên hệ",
  ];

  return (
    <View style={styles.header}>
      <Text style={styles.logo}>GHTK</Text>

      <View style={styles.menu}>
        <Text style={styles.menuActive}>Trang chủ</Text>

        {menuItems.map((item) => (
          <Text key={item} style={styles.menuItem}>
            {item}
          </Text>
        ))}
      </View>

      <TouchableOpacity style={styles.consultBtn}>
        <Text style={styles.consultText}>Tư vấn Doanh nghiệp</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  header: {
    height: 76,
    backgroundColor: "#FFFFFF",
    paddingHorizontal: 24,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    borderBottomWidth: 1,
    borderBottomColor: "#EAEAEA",
  },

  logo: {
    fontSize: 28,
    fontWeight: "800",
    color: "#00B14F",
  },

  menu: {
    flexDirection: "row",
    alignItems: "center",
  },

  menuActive: {
    color: "#00B14F",
    fontSize: 16,
    fontWeight: "700",
    marginRight: 18,
  },

  menuItem: {
    color: "#222222",
    fontSize: 15,
    fontWeight: "500",
    marginRight: 18,
  },

  consultBtn: {
    backgroundColor: "#F15A24",
    paddingHorizontal: 18,
    paddingVertical: 12,
    borderRadius: 6,
  },

  consultText: {
    color: "#FFFFFF",
    fontSize: 14,
    fontWeight: "700",
  },
});